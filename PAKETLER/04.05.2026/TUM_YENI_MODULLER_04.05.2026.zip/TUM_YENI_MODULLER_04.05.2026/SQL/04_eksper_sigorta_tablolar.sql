-- ═══════════════════════════════════════════════════════════════
-- MR HASAR — EKSPER FİRMALARI + SİGORTA ŞİRKETLERİ TANIMLARI
-- 04.05.2026 — Mail entegrasyonu için altyapı
-- ═══════════════════════════════════════════════════════════════

-- 1) EKSPER FİRMALARI tablosu
CREATE TABLE IF NOT EXISTS eksper_firmalari (
    id INT AUTO_INCREMENT PRIMARY KEY,
    firma_adi VARCHAR(150) NOT NULL,
    eksper_adi VARCHAR(150) NOT NULL,
    eksper_cep VARCHAR(20) DEFAULT NULL,
    sabit_telefon VARCHAR(20) DEFAULT NULL,
    ofis_cep VARCHAR(20) DEFAULT NULL,
    eposta VARCHAR(150) DEFAULT NULL,
    durum ENUM('aktif','pasif') NOT NULL DEFAULT 'aktif',
    notlar TEXT DEFAULT NULL,
    created_by INT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_firma_eksper (firma_adi, eksper_adi),
    INDEX idx_durum (durum),
    INDEX idx_eksper_adi (eksper_adi)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- 2) SİGORTA ŞİRKETLERİ tablosu
CREATE TABLE IF NOT EXISTS sigorta_sirketleri (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sirket_adi VARCHAR(150) NOT NULL,
    iletisim_no VARCHAR(20) DEFAULT NULL,
    hasar_eposta VARCHAR(150) DEFAULT NULL,
    web_portal VARCHAR(255) DEFAULT NULL,
    durum ENUM('aktif','pasif') NOT NULL DEFAULT 'aktif',
    notlar TEXT DEFAULT NULL,
    created_by INT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_sirket_adi (sirket_adi),
    INDEX idx_durum (durum)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- 3) DOSYALAR tablosuna FK kolonlar (text alanlar korunur, ID eklenir)
ALTER TABLE dosyalar ADD COLUMN IF NOT EXISTS eksper_id INT DEFAULT NULL;
ALTER TABLE dosyalar ADD COLUMN IF NOT EXISTS sigorta_id INT DEFAULT NULL;

-- (Index ekle — sadece yoksa)
SET @x := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'dosyalar' AND INDEX_NAME = 'idx_dosya_eksper_id');
SET @sql := IF(@x = 0, 'ALTER TABLE dosyalar ADD INDEX idx_dosya_eksper_id (eksper_id)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @x := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'dosyalar' AND INDEX_NAME = 'idx_dosya_sigorta_id');
SET @sql := IF(@x = 0, 'ALTER TABLE dosyalar ADD INDEX idx_dosya_sigorta_id (sigorta_id)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 4) SİGORTA ŞİRKETLERİ SEED — Türkiye'de aktif sigorta firmaları (ad ile)
INSERT IGNORE INTO sigorta_sirketleri (sirket_adi, durum) VALUES
('AKSİGORTA', 'aktif'),
('ALLIANZ SİGORTA', 'aktif'),
('ANADOLU SİGORTA', 'aktif'),
('AXA SİGORTA', 'aktif'),
('BNP PARIBAS CARDIF SİGORTA', 'aktif'),
('DEMİR HAYAT SİGORTA', 'aktif'),
('DOĞA SİGORTA', 'aktif'),
('DUBAİ STARR SİGORTA', 'aktif'),
('EUREKO SİGORTA', 'aktif'),
('GROUPAMA SİGORTA', 'aktif'),
('GULF SİGORTA', 'aktif'),
('HDI SİGORTA', 'aktif'),
('HEPİYİ SİGORTA', 'aktif'),
('KORU SİGORTA', 'aktif'),
('MAGDEBURGER SİGORTA', 'aktif'),
('MAPFRE SİGORTA', 'aktif'),
('NEOVA SİGORTA', 'aktif'),
('ORIENT SİGORTA', 'aktif'),
('QUICK SİGORTA', 'aktif'),
('RAY SİGORTA', 'aktif'),
('SOMPO SİGORTA', 'aktif'),
('TÜRKİYE SİGORTA', 'aktif'),
('UNICO SİGORTA', 'aktif'),
('ZÜRICH SİGORTA', 'aktif');

-- 5) Yetki kayıtları (admin'lere otomatik)
INSERT INTO yetkiler (kullanici_id, modul, islem, izin)
SELECT u.id, 'paydas', 'eksper-yonet', 1 FROM users u
WHERE u.rol = 'admin'
  AND NOT EXISTS (SELECT 1 FROM yetkiler y WHERE y.kullanici_id = u.id AND y.modul = 'paydas' AND y.islem = 'eksper-yonet');

INSERT INTO yetkiler (kullanici_id, modul, islem, izin)
SELECT u.id, 'paydas', 'sigorta-yonet', 1 FROM users u
WHERE u.rol = 'admin'
  AND NOT EXISTS (SELECT 1 FROM yetkiler y WHERE y.kullanici_id = u.id AND y.modul = 'paydas' AND y.islem = 'sigorta-yonet');

-- ═══════════════════════════════════════════════════════════════
-- BİTTİ. Mail entegrasyonu için altyapı hazır (eposta alanları dolu).
-- ═══════════════════════════════════════════════════════════════
