const MR = window.MR || (window.MR = {});
const {useState, useEffect, useCallback, useRef} = React;

/* ════════════════════════════════════════════════════════════════
   MR HASAR DANIŞMANLIK - SİSTEM YÖNETİMİ SAYFASI
   KULLANICI YÖNETİMİ | YETKİ YÖNETİMİ | FİRMA AYARLARI | LOG KAYITLARI
   ════════════════════════════════════════════════════════════════ */

/* ─── ROL RENK HARİTASI ─── */
const ROL_RENK = {
  admin:    MR.C.danger,
  avukat:   MR.C.purple,
  uzman:    MR.C.accent,
  personel: MR.C.cyan,
  muhasebe: MR.C.success,
  portal:   MR.C.warning
};

const ROL_LABEL = {
  admin:    'ADMİN',
  avukat:   'AVUKAT',
  uzman:    'UZMAN',
  personel: 'PERSONEL',
  muhasebe: 'MUHASEBE',
  portal:   'PORTAL'
};

/* ─── LOG İŞLEM RENK HARİTASI ─── */
const LOG_ISLEM_RENK = (islem) => {
  if (!islem) return MR.C.textSec;
  const s = islem.toUpperCase();
  if (s.includes('SİL') || s.includes('DELETE') || s.includes('KALDIR')) return MR.C.danger;
  if (s.includes('OLUŞTUR') || s.includes('CREATE') || s.includes('EKLE') || s.includes('YENİ')) return MR.C.success;
  if (s.includes('GÜNCELLE') || s.includes('UPDATE') || s.includes('DÜZENLE')) return MR.C.warning;
  if (s.includes('GİRİŞ') || s.includes('LOGIN')) return MR.C.accent;
  if (s.includes('ÇIKIŞ') || s.includes('LOGOUT')) return MR.C.purple;
  return MR.C.cyan;
};

/* ─── YETKİ MODÜL HARİTASI ─── */
/* ─── YETKİ MODÜL HARİTASI (ALT MODÜL BAZLI) ─── */
/* Her modülün islemleri = menü alt öğeleri (sub-items) */
const MODUL_YETKILERI = [
  {modul: 'dosya', label: 'DOSYA İŞLEMLERİ', icon: 'FolderOpen', islemler: [
    {key: 'dosya-liste', label: 'DOSYA LİSTESİ'},
    {key: 'dosya-yeni', label: 'YENİ DOSYA'}
  ]},
  {modul: 'crm', label: 'CRM / SAHA', icon: 'Users', islemler: [
    {key: 'crm-liste', label: 'CRM LİSTESİ'},
    {key: 'crm-yeni', label: 'YENİ KAYIT'},
    {key: 'crm-arama', label: 'ARAMA LİSTESİ'},
    {key: 'saha-liste', label: 'SAHA DOSYALARI'},
    {key: 'saha-yeni', label: 'YENİ SAHA KAYDI'}
  ]},
  {modul: 'hesaplamalar', label: 'HESAPLAMALAR', icon: 'Calculator', islemler: [
    {key: 'hesap-adk', label: 'ARAÇ DEĞER KAYBI'},
    {key: 'hesap-bh', label: 'BEDENİ HASAR'}
  ]},
  {modul: 'paydaslar', label: 'PAYDAŞLAR', icon: 'Handshake', islemler: [
    {key: 'ortaklar-ortaklar', label: 'İŞ ORTAKLARI'},
    {key: 'ortaklar-paydaslar', label: 'İŞ PAYDAŞLARI'},
    {key: 'servis-liste', label: 'SERVİS LİSTESİ'},
    {key: 'servis-yeni', label: 'YENİ SERVİS'},
    {key: 'servis-rapor', label: 'SERVİS RAPORLARI'}
  ]},
  {modul: 'police', label: 'POLİÇE', icon: 'FileCheck', islemler: [
    {key: 'police-liste', label: 'POLİÇE LİSTESİ'},
    {key: 'police-yeni', label: 'YENİ POLİÇE'},
    {key: 'police-yenileme', label: 'YENİLEME TAKİBİ'},
    {key: 'police-tahsilat', label: 'TAHSİLAT / CARİ'},
    {key: 'police-rapor', label: 'RAPORLAR'},
    {key: 'police-kazanc', label: 'KAZANÇ'}
  ]},
  {modul: 'muhasebe', label: 'MUHASEBE', icon: 'Landmark', islemler: [
    {key: 'muhasebe-gelir', label: 'GELİR YÖNETİMİ'},
    {key: 'muhasebe-gider', label: 'GİDER YÖNETİMİ'},
    {key: 'muhasebe-komisyon', label: 'KOMİSYON / PRİM'},
    {key: 'muhasebe-kasa', label: 'KASA / BANKA'},
    {key: 'muhasebe-maliyet', label: 'MALİYET ANALİZİ'},
    {key: 'muhasebe-rapor', label: 'FİNANSAL RAPORLAR'},
    {key: 'personel-liste', label: 'PERSONEL LİSTESİ'},
    {key: 'personel-yeni', label: 'YENİ PERSONEL'},
    {key: 'personel-hakedis', label: 'HAKEDİŞ TAKİBİ'}
  ]},
  {modul: 'ajanda', label: 'AJANDA', icon: 'Calendar', islemler: [
    {key: 'goruntule', label: 'AJANDA GÖRÜNTÜLE'}
  ]},
  {modul: 'sistem', label: 'SİSTEM', icon: 'Shield', islemler: [
    {key: 'sistem-kullanici', label: 'KULLANICI YÖNETİMİ'},
    {key: 'sistem-yetki', label: 'YETKİ YÖNETİMİ'},
    {key: 'sistem-ayarlar', label: 'FİRMA AYARLARI'},
    {key: 'sistem-sms', label: 'SMS BİLDİRİM'},
    {key: 'sistem-portal', label: 'PORTAL AYARLARI'},
    {key: 'sistem-netsantral', label: 'NETSANTRAL'},
    {key: 'sistem-log', label: 'LOG KAYITLARI'},
    {key: 'mesajlar-sistem', label: 'SİSTEM BİLDİRİMLERİ'},
    {key: 'tanimlamalar-dosya', label: 'DOSYA TANIMLAMALARI'},
    {key: 'tanimlamalar-evrak', label: 'EVRAK TANIMLAMALARI'},
    {key: 'tanimlamalar-finansal', label: 'FİNANSAL TANIMLAMALAR'},
    {key: 'tanimlamalar-sablon', label: 'MATBU EVRAK / SÖZLEŞME'},
    {key: 'tanimlamalar-genel', label: 'GENEL TANIMLAMALAR'}
  ]},
  {modul: 'netsantral', label: 'NETSANTRAL (GİDEN ARAMA)', icon: 'Phone', islemler: [
    {key: 'goruntule', label: 'ARAMA PANELİ GÖRÜNTÜLE'},
    {key: 'arama_yap', label: 'GİDEN ARAMA YAP'},
    {key: 'transfer', label: 'ÇAĞRI TRANSFER'},
    {key: 'ayarlar', label: 'AYARLARI DÜZENLE'}
  ]},
  {modul: 'netsipp', label: 'ÇAĞRI BİLDİRİM', icon: 'PhoneCall', islemler: [
    {key: 'goruntule', label: 'ÇAĞRI PANELİ GÖRÜNTÜLE'},
    {key: 'gelen_cagri', label: 'GELEN ÇAĞRI BİLDİRİMİ'},
    {key: 'giden_cagri', label: 'GİDEN ÇAĞRI LOGU'}
  ]}
];

/* ════════════════════════════════════════════════════════════════
   TAB 1 - KULLANICI YÖNETİMİ
   ════════════════════════════════════════════════════════════════ */
const KullaniciTab = () => {
  const {C, S, LIcon, Badge, StatCard, Loading, EmptyState, Modal, FormGroup, Confirm, api} = MR;
  const [kullanicilar, setKullanicilar] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editUser, setEditUser] = useState(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [confirmState, setConfirmState] = useState({open: false, id: null, msg: ''});

  const bos = {ad_soyad: '', email: '', sifre: '', telefon: '', rol: 'personel'};
  const [form, setForm] = useState({...bos});

  const up = (k, v) => setForm(p => ({...p, [k]: v}));

  const load = async () => {
    setLoading(true);
    const r = await api.kullaniciList();
    if (r?.success) {
      const items = r.data?.items || r.data || [];
      setKullanicilar(Array.isArray(items) ? items : []);
    } else {
      setKullanicilar([]);
    }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const toplam = kullanicilar.length;
  const aktifSayi = kullanicilar.filter(u => u.aktif !== 0 && u.aktif !== false).length;
  const pasifSayi = toplam - aktifSayi;

  const yeniKullanici = () => {
    setEditUser(null);
    setForm({...bos});
    setError('');
    setModalOpen(true);
  };

  const duzenle = (user) => {
    setEditUser(user);
    setForm({
      ad_soyad: user.ad_soyad || '',
      email: user.email || '',
      sifre: '',
      telefon: user.telefon || '',
      rol: user.rol || 'personel'
    });
    setError('');
    setModalOpen(true);
  };

  const kaydet = async () => {
    if (!form.ad_soyad.trim() || !form.email.trim()) {
      setError('AD SOYAD VE E-POSTA ZORUNLU ALANLARDIR');
      return;
    }
    if (!editUser && !form.sifre) {
      setError('YENİ KULLANICI İÇİN ŞİFRE ZORUNLUDUR');
      return;
    }
    setSaving(true);
    setError('');

    let r;
    if (editUser) {
      const payload = {
        id: editUser.id,
        ad_soyad: form.ad_soyad.trim(),
        email: form.email.trim(),
        telefon: form.telefon.trim(),
        rol: form.rol
      };
      if (form.sifre) payload.sifre = form.sifre;
      r = await api.kullaniciUpdate(payload);
    } else {
      r = await api.kullaniciCreate({
        ad_soyad: form.ad_soyad.trim(),
        email: form.email.trim(),
        sifre: form.sifre,
        telefon: form.telefon.trim(),
        rol: form.rol
      });
    }

    if (r?.success) {
      setModalOpen(false);
      setForm({...bos});
      setEditUser(null);
      await load();
    } else {
      setError(r?.error || 'BİR HATA OLUŞTU');
    }
    setSaving(false);
  };

  const toggleAktif = (user) => {
    const yeniDurum = user.aktif !== 0 && user.aktif !== false ? 0 : 1;
    const msg = yeniDurum === 0
      ? `"${user.ad_soyad}" KULLANICISINI PASİF YAPMAK İSTEDİĞİNİZDEN EMİN MİSİNİZ?`
      : `"${user.ad_soyad}" KULLANICISINI AKTİF YAPMAK İSTEDİĞİNİZDEN EMİN MİSİNİZ?`;
    setConfirmState({open: true, id: user.id, msg, action: 'toggle', aktif: yeniDurum});
  };

  const silKullanici = (user) => {
    setConfirmState({
      open: true, id: user.id,
      msg: `"${user.ad_soyad}" KULLANICISINI KALICI OLARAK SİLMEK İSTEDİĞİNİZDEN EMİN MİSİNİZ? BU İŞLEM GERİ ALINAMAZ!`,
      action: 'delete'
    });
  };

  const confirmAction = async () => {
    if (!confirmState.id) return;
    if (confirmState.action === 'toggle') {
      await api.kullaniciUpdate({id: confirmState.id, aktif: confirmState.aktif});
    } else if (confirmState.action === 'delete') {
      /* KALICI SİLME - mode=hard */
      await api.req('/sistem/kullanici-delete.php?id=' + confirmState.id + '&mode=hard', {method: 'DELETE'});
    }
    setConfirmState({open: false, id: null, msg: ''});
    await load();
  };

  return (
    <div>
      {/* İSTATİSTİKLER */}
      <div style={{display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12, marginBottom:20}}>
        <StatCard icon="Users" label="TOPLAM KULLANICI" value={toplam} color={C.accent}/>
        <StatCard icon="UserCheck" label="AKTİF" value={aktifSayi} color={C.success}/>
        <StatCard icon="User" label="PASİF" value={pasifSayi} color={C.danger}/>
      </div>

      {/* KULLANICI LİSTESİ */}
      <div style={S.card}>
        <div style={{...S.cardHead, justifyContent:'space-between'}}>
          <div style={{display:'flex', alignItems:'center', gap:10}}>
            <LIcon name="Users" size={14} color={C.accent}/>
            <span style={{fontSize:13, fontWeight:700}}>KULLANICI YÖNETİMİ</span>
            <Badge text={`${toplam} KULLANICI`} color={C.accent}/>
          </div>
          <button style={{...S.btn, ...S.btnP, fontSize:11, padding:'8px 16px'}} onClick={yeniKullanici}>
            <LIcon name="UserPlus" size={14} color="#fff"/> YENİ KULLANICI
          </button>
        </div>

        {loading ? <Loading/> : kullanicilar.length === 0 ? (
          <EmptyState icon="Users" title="KULLANICI BULUNAMADI" desc="SİSTEMDE KAYITLI KULLANICI YOK"/>
        ) : (
          <div style={{overflowX:'auto'}}>
            <table style={{width:'100%', borderCollapse:'collapse', fontSize:11, minWidth:800}}>
              <thead>
                <tr style={{background:C.bgHover}}>
                  {['AD SOYAD', 'E-POSTA', 'TELEFON', 'ROL', 'DURUM', 'İŞLEMLER'].map(h =>
                    <th key={h} style={{padding:'10px 12px', textAlign:'left', color:C.textMuted, fontWeight:600, fontSize:9, borderBottom:`1px solid ${C.border}`}}>{h}</th>
                  )}
                </tr>
              </thead>
              <tbody>
                {kullanicilar.map((u, i) => {
                  const aktif = u.aktif !== 0 && u.aktif !== false;
                  const rolRenk = ROL_RENK[u.rol] || C.textSec;
                  return (
                    <tr key={u.id || i} style={{borderBottom:`1px solid ${C.border}`}}
                      onMouseEnter={e => e.currentTarget.style.background = C.bgHover}
                      onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                      <td style={{padding:'12px', fontWeight:600}}>
                        <div style={{display:'flex', alignItems:'center', gap:10}}>
                          <div style={{width:32, height:32, borderRadius:8, background:`${rolRenk}22`,
                            display:'flex', alignItems:'center', justifyContent:'center', fontSize:12, fontWeight:800, color:rolRenk}}>
                            {(u.ad_soyad || '?')[0].toUpperCase()}
                          </div>
                          {u.ad_soyad}
                        </div>
                      </td>
                      <td style={{padding:'12px', color:C.textSec}}>{u.email}</td>
                      <td style={{padding:'12px', color:C.textSec}}>{u.telefon || '-'}</td>
                      <td style={{padding:'12px'}}>
                        <Badge text={ROL_LABEL[u.rol] || (u.rol || '').toUpperCase()} color={rolRenk}/>
                      </td>
                      <td style={{padding:'12px'}}>
                        <Badge text={aktif ? 'AKTİF' : 'PASİF'} color={aktif ? C.success : C.danger}/>
                      </td>
                      <td style={{padding:'12px'}}>
                        <div style={{display:'flex', gap:6}}>
                          <div onClick={() => duzenle(u)} style={{cursor:'pointer', padding:6, borderRadius:6, transition:'all .2s'}}
                            onMouseEnter={e => e.currentTarget.style.background = `${C.accent}22`}
                            onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                            title="DÜZENLE">
                            <LIcon name="Edit" size={14} color={C.accent}/>
                          </div>
                          <div onClick={() => toggleAktif(u)} style={{cursor:'pointer', padding:6, borderRadius:6, transition:'all .2s'}}
                            onMouseEnter={e => e.currentTarget.style.background = `${C.warning}22`}
                            onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                            title={aktif ? 'PASİF YAP' : 'AKTİF YAP'}>
                            <LIcon name={aktif ? 'XCircle' : 'CheckSquare'} size={14} color={aktif ? C.warning : C.success}/>
                          </div>
                          <div onClick={() => silKullanici(u)} style={{cursor:'pointer', padding:6, borderRadius:6, transition:'all .2s'}}
                            onMouseEnter={e => e.currentTarget.style.background = `${C.danger}22`}
                            onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                            title="SİL">
                            <LIcon name="Trash2" size={14} color={C.danger}/>
                          </div>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* KULLANICI EKLEME / DÜZENLEME MODAL */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)}
        title={editUser ? 'KULLANICI DÜZENLE' : 'YENİ KULLANICI OLUŞTUR'} width="520px">
        <div>
          {error && (
            <div style={{padding:'10px 14px', background:`${C.danger}22`, border:`1px solid ${C.danger}44`,
              borderRadius:8, marginBottom:16, fontSize:12, color:C.danger}}>
              {error}
            </div>
          )}
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:16}}>
            <FormGroup label="AD SOYAD *">
              <input style={S.input} value={form.ad_soyad} onChange={e => up('ad_soyad', e.target.value)} placeholder="AD SOYAD"/>
            </FormGroup>
            <FormGroup label="E-POSTA *">
              <input style={S.input} type="email" value={form.email} onChange={e => up('email', e.target.value)} placeholder="E-POSTA ADRESİ"/>
            </FormGroup>
            <FormGroup label={editUser ? 'ŞİFRE (OPSIYONEL)' : 'ŞİFRE *'}>
              <input style={S.input} type="password" value={form.sifre} onChange={e => up('sifre', e.target.value)}
                placeholder={editUser ? 'BOŞSA DEĞİŞMEZ' : 'ŞİFRE GİRİNİZ'}/>
            </FormGroup>
            <FormGroup label="TELEFON">
              <input style={S.input} type="tel" value={form.telefon} onChange={e => up('telefon', e.target.value)} placeholder="05XX XXX XXXX"/>
            </FormGroup>
            <FormGroup label="ROL *" full>
              <select style={S.select} value={form.rol} onChange={e => up('rol', e.target.value)}>
                <option value="admin">ADMİN</option>
                <option value="avukat">AVUKAT</option>
                <option value="uzman">UZMAN</option>
                <option value="personel">PERSONEL</option>
                <option value="muhasebe">MUHASEBE</option>
                <option value="portal">PORTAL</option>
              </select>
            </FormGroup>
          </div>
          <div style={{marginTop:24, display:'flex', gap:8, justifyContent:'flex-end'}}>
            <button style={{...S.btn, ...S.btnG, fontSize:12}} onClick={() => setModalOpen(false)}>İPTAL</button>
            <button style={{...S.btn, ...S.btnS, fontSize:12, opacity:saving ? 0.7 : 1}} onClick={kaydet} disabled={saving}>
              <LIcon name="Save" size={14} color="#fff"/> {saving ? 'KAYDEDİLİYOR...' : 'KAYDET'}
            </button>
          </div>
        </div>
      </Modal>

      {/* SİLME / DURUM DEĞİŞTİRME ONAYI */}
      <Confirm open={confirmState.open}
        message={confirmState.msg}
        onConfirm={confirmAction}
        onCancel={() => setConfirmState({open: false, id: null, msg: ''})}/>
    </div>
  );
};

/* ════════════════════════════════════════════════════════════════
   TAB 2 - YETKİ YÖNETİMİ
   ════════════════════════════════════════════════════════════════ */
const YetkiTab = () => {
  const {C, S, LIcon, Badge, Loading, EmptyState, api} = MR;
  const [kullanicilar, setKullanicilar] = useState([]);
  const [seciliKullanici, setSeciliKullanici] = useState('');
  const [yetkiler, setYetkiler] = useState({});
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [mesaj, setMesaj] = useState({type: '', text: ''});
  const [kullaniciLoading, setKullaniciLoading] = useState(true);

  /* KULLANICI LİSTESİ YÜKLE */
  useEffect(() => {
    (async () => {
      setKullaniciLoading(true);
      const r = await api.kullaniciList();
      if (r?.success) {
        const items = r.data?.items || r.data || [];
        setKullanicilar(Array.isArray(items) ? items : []);
      }
      setKullaniciLoading(false);
    })();
  }, []);

  /* SEÇİLİ KULLANICI DEĞİŞTİĞİNDE YETKİLERİ YÜKLE */
  useEffect(() => {
    if (!seciliKullanici) {
      setYetkiler({});
      return;
    }
    (async () => {
      setLoading(true);
      setMesaj({type: '', text: ''});
      const r = await api.yetkiList({kullanici_id: seciliKullanici});
      if (r?.success) {
        const items = r.data?.items || r.data || [];
        const yMap = {};
        if (Array.isArray(items)) {
          items.forEach(y => {
            const key = `${y.modul}_${y.islem}`;
            yMap[key] = y.izin === 1 || y.izin === true || y.izin === '1';
          });
        }
        setYetkiler(yMap);
      } else {
        setYetkiler({});
      }
      setLoading(false);
    })();
  }, [seciliKullanici]);

  /* TEK YETKİ TOGGLE */
  const toggleYetki = (modul, islem) => {
    const key = `${modul}_${islem}`;
    setYetkiler(p => ({...p, [key]: !p[key]}));
  };

  /* MODÜL BAZLI TÜMÜNÜ SEÇ/KALDIR */
  const toggleModul = (modul, islemler) => {
    const hepsiSecili = islemler.every(i => yetkiler[`${modul}_${i.key}`]);
    const yeni = {...yetkiler};
    islemler.forEach(i => {
      yeni[`${modul}_${i.key}`] = !hepsiSecili;
    });
    setYetkiler(yeni);
  };

  /* MASTER TÜMÜNÜ SEÇ/KALDIR */
  const toggleHepsi = () => {
    let toplamIslem = 0;
    let seciliIslem = 0;
    MODUL_YETKILERI.forEach(m => {
      m.islemler.forEach(i => {
        toplamIslem++;
        if (yetkiler[`${m.modul}_${i.key}`]) seciliIslem++;
      });
    });
    const hepsiSecili = toplamIslem === seciliIslem;
    const yeni = {};
    MODUL_YETKILERI.forEach(m => {
      m.islemler.forEach(i => {
        yeni[`${m.modul}_${i.key}`] = !hepsiSecili;
      });
    });
    setYetkiler(yeni);
  };

  /* KAYDET */
  const kaydet = async () => {
    if (!seciliKullanici) return;
    setSaving(true);
    setMesaj({type: '', text: ''});

    const yetkiArr = [];
    MODUL_YETKILERI.forEach(m => {
      m.islemler.forEach(i => {
        yetkiArr.push({
          modul: m.modul,
          islem: i.key,
          izin: yetkiler[`${m.modul}_${i.key}`] ? 1 : 0
        });
      });
    });

    const r = await api.yetkiGuncelle({
      kullanici_id: seciliKullanici,
      yetkiler: yetkiArr
    });

    if (r?.success) {
      setMesaj({type: 'success', text: 'YETKİLER BAŞARIYLA KAYDEDİLDİ'});
    } else {
      setMesaj({type: 'error', text: r?.error || 'YETKİLER KAYDEDİLİRKEN HATA OLUŞTU'});
    }
    setSaving(false);
    setTimeout(() => setMesaj({type: '', text: ''}), 4000);
  };

  /* SEÇİLİ KULLANICI BİLGİSİ */
  const seciliUser = kullanicilar.find(u => String(u.id) === String(seciliKullanici));

  /* İSTATİSTİKLER */
  let toplamIslem = 0;
  let seciliIslem = 0;
  MODUL_YETKILERI.forEach(m => {
    m.islemler.forEach(i => {
      toplamIslem++;
      if (yetkiler[`${m.modul}_${i.key}`]) seciliIslem++;
    });
  });

  /* CHECKBOX BİLEŞENİ */
  const Checkbox = ({checked, onChange, label}) => (
    <div onClick={() => onChange(!checked)} style={{
      display: 'flex', alignItems: 'center', gap: 8, padding: '6px 0', cursor: 'pointer'
    }}>
      <div style={{
        width: 20, height: 20, borderRadius: 4, border: `2px solid ${checked ? C.accent : C.borderLight}`,
        background: checked ? C.accent : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center',
        transition: 'all .2s', flexShrink: 0
      }}>
        {checked && <LIcon name="Check" size={14} color="#fff"/>}
      </div>
      <span style={{fontSize: 12, fontWeight: 500, color: checked ? C.text : C.textMuted}}>{label}</span>
    </div>
  );

  return (
    <div>
      {/* KULLANICI SEÇİCİ */}
      <div style={{...S.card, marginBottom: 16}}>
        <div style={{...S.cardHead, padding: '12px 16px'}}>
          <LIcon name="KeyRound" size={14} color={C.accent}/>
          <span style={{fontSize: 12, fontWeight: 700}}>KULLANICI SEÇİN</span>
        </div>
        <div style={{padding: 16}}>
          {kullaniciLoading ? <Loading/> : (
            <div style={{display: 'flex', alignItems: 'center', gap: 16}}>
              <select style={{...S.select, flex: 1, maxWidth: 400}}
                value={seciliKullanici}
                onChange={e => setSeciliKullanici(e.target.value)}>
                <option value="">-- KULLANICI SEÇİNİZ --</option>
                {kullanicilar.map(u => (
                  <option key={u.id} value={u.id}>
                    {u.ad_soyad} ({ROL_LABEL[u.rol] || (u.rol || '').toUpperCase()})
                  </option>
                ))}
              </select>
              {seciliUser && (
                <div style={{display: 'flex', alignItems: 'center', gap: 10}}>
                  <div style={{
                    width: 36, height: 36, borderRadius: 8,
                    background: `${ROL_RENK[seciliUser.rol] || C.accent}22`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 14, fontWeight: 800, color: ROL_RENK[seciliUser.rol] || C.accent
                  }}>
                    {(seciliUser.ad_soyad || '?')[0].toUpperCase()}
                  </div>
                  <div>
                    <div style={{fontSize: 13, fontWeight: 700}}>{seciliUser.ad_soyad}</div>
                    <div style={{fontSize: 10, color: C.textMuted}}>{seciliUser.email}</div>
                  </div>
                  <Badge text={ROL_LABEL[seciliUser.rol] || (seciliUser.rol || '').toUpperCase()}
                    color={ROL_RENK[seciliUser.rol] || C.accent}/>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* MESAJ */}
      {mesaj.text && (
        <div style={{
          padding: '12px 16px', borderRadius: 8, marginBottom: 16, fontSize: 12, fontWeight: 600,
          background: mesaj.type === 'success' ? `${C.success}22` : `${C.danger}22`,
          border: `1px solid ${mesaj.type === 'success' ? C.success + '44' : C.danger + '44'}`,
          color: mesaj.type === 'success' ? C.success : C.danger,
          display: 'flex', alignItems: 'center', gap: 8
        }}>
          <LIcon name={mesaj.type === 'success' ? 'CheckCircle' : 'AlertCircle'} size={16}
            color={mesaj.type === 'success' ? C.success : C.danger}/>
          {mesaj.text}
        </div>
      )}

      {!seciliKullanici ? (
        <EmptyState icon="KeyRound" title="KULLANICI SEÇİN"
          desc="YETKİLERİ DÜZENLEMEK İÇİN YUKARIDAKI LİSTEDEN BİR KULLANICI SEÇİNİZ"/>
      ) : loading ? <Loading/> : (
        <div>
          {/* BİLGİ BANNER */}
          <div style={{
            padding: '12px 16px', borderRadius: 8, marginBottom: 16,
            background: `${C.accent}11`, border: `1px solid ${C.accent}22`,
            display: 'flex', alignItems: 'center', justifyContent: 'space-between'
          }}>
            <div style={{display: 'flex', alignItems: 'center', gap: 10}}>
              <LIcon name="Info" size={16} color={C.accent}/>
              <span style={{fontSize: 12, color: C.textSec}}>
                <strong style={{color: C.text}}>{seciliUser?.ad_soyad}</strong> İÇİN YETKİLERİ DÜZENLİYORSUNUZ
                &nbsp;&middot;&nbsp; <strong style={{color: C.accent}}>{seciliIslem}</strong> / {toplamIslem} İZİN AKTİF
              </span>
            </div>
            <Checkbox checked={toplamIslem === seciliIslem && toplamIslem > 0}
              onChange={toggleHepsi} label="TÜMÜNÜ SEÇ"/>
          </div>

          {/* MODÜL KARTLARI */}
          <div style={{display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12, marginBottom: 20}}>
            {MODUL_YETKILERI.map(m => {
              const hepsiSecili = m.islemler.every(i => yetkiler[`${m.modul}_${i.key}`]);
              const birkacSecili = m.islemler.some(i => yetkiler[`${m.modul}_${i.key}`]) && !hepsiSecili;
              const seciliSay = m.islemler.filter(i => yetkiler[`${m.modul}_${i.key}`]).length;

              return (
                <div key={m.modul} style={{
                  ...S.card, overflow: 'hidden',
                  border: hepsiSecili ? `1px solid ${C.accent}44` :
                    birkacSecili ? `1px solid ${C.warning}44` : `1px solid ${C.border}`
                }}>
                  {/* MODÜL BAŞLIĞI */}
                  <div style={{
                    padding: '12px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                    background: hepsiSecili ? `${C.accent}11` : birkacSecili ? `${C.warning}08` : C.bgHover,
                    borderBottom: `1px solid ${C.border}`
                  }}>
                    <div style={{display: 'flex', alignItems: 'center', gap: 10}}>
                      <div style={{
                        width: 32, height: 32, borderRadius: 8,
                        background: hepsiSecili ? `${C.accent}22` : `${C.textMuted}15`,
                        display: 'flex', alignItems: 'center', justifyContent: 'center'
                      }}>
                        <LIcon name={m.icon} size={16} color={hepsiSecili ? C.accent : C.textMuted}/>
                      </div>
                      <div>
                        <div style={{fontSize: 12, fontWeight: 700, color: hepsiSecili ? C.accent : C.text}}>
                          {m.label}
                        </div>
                        <div style={{fontSize: 10, color: C.textMuted}}>
                          {seciliSay} / {m.islemler.length} İZİN AKTİF
                        </div>
                      </div>
                    </div>
                    <div onClick={() => toggleModul(m.modul, m.islemler)} style={{
                      cursor: 'pointer', padding: '4px 10px', borderRadius: 6, fontSize: 10, fontWeight: 700,
                      background: hepsiSecili ? `${C.danger}22` : `${C.accent}22`,
                      color: hepsiSecili ? C.danger : C.accent,
                      border: `1px solid ${hepsiSecili ? C.danger + '33' : C.accent + '33'}`,
                      transition: 'all .2s'
                    }}>
                      {hepsiSecili ? 'TÜMÜNÜ KALDIR' : 'TÜMÜNÜ SEÇ'}
                    </div>
                  </div>

                  {/* İŞLEM CHECKBOX'LARI */}
                  <div style={{padding: '8px 16px 12px'}}>
                    {m.islemler.map(i => (
                      <Checkbox key={i.key}
                        checked={!!yetkiler[`${m.modul}_${i.key}`]}
                        onChange={() => toggleYetki(m.modul, i.key)}
                        label={i.label}/>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>

          {/* KAYDET BUTONU */}
          <div style={{
            ...S.card, padding: '16px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between'
          }}>
            <div style={{fontSize: 12, color: C.textMuted}}>
              <LIcon name="Info" size={14} color={C.textMuted} style={{verticalAlign: 'middle'}}/>{' '}
              DEĞİŞİKLİKLERİ KAYDETMEK İÇİN AŞAĞIDAKI BUTONA BASIN
            </div>
            <button style={{
              ...S.btn, ...S.btnP, fontSize: 13, padding: '12px 32px', fontWeight: 700,
              opacity: saving ? 0.7 : 1
            }} onClick={kaydet} disabled={saving}>
              <LIcon name="Save" size={16} color="#fff"/>
              {saving ? 'KAYDEDİLİYOR...' : 'YETKİLERİ KAYDET'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

/* ════════════════════════════════════════════════════════════════
   TAB 3 - FİRMA AYARLARI
   ════════════════════════════════════════════════════════════════ */
const AyarlarTab = () => {
  const {C, S, LIcon, Badge, Loading, api} = MR;
  const [ayarlar, setAyarlar] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [mesaj, setMesaj] = useState({type: '', text: ''});
  const [logoFile, setLogoFile] = useState(null);
  const [logoPreview, setLogoPreview] = useState('');
  const [logoUploading, setLogoUploading] = useState(false);
  const fileInputRef = useRef(null);
  const [apiTest, setApiTest] = useState({testing: false, sonuc: null});

  /* AYARLAR YÜKLE */
  useEffect(() => {
    (async () => {
      setLoading(true);
      const r = await api.ayarlarList();
      if (r?.success) {
        const data = r.data || {};
        setAyarlar(data);
        if (data.logo_url) setLogoPreview(data.logo_url);
      }
      setLoading(false);
    })();
  }, []);

  const up = (k, v) => setAyarlar(p => ({...p, [k]: v}));

  /* GEMİNİ API TESTİ */
  const geminiTestEt = async (key) => {
    setApiTest({testing: true, sonuc: null});
    try {
      const r = await api.geminiTest(key ? {api_key: key} : {});
      if (r?.success && r.data) {
        setApiTest({testing: false, sonuc: r.data});
      } else {
        setApiTest({testing: false, sonuc: {basarili: false, ozet: r?.error || 'TEST SIRASINDA HATA OLUŞTU', hata_detay: r?.error || 'BİLİNMEYEN HATA'}});
      }
    } catch(e) {
      setApiTest({testing: false, sonuc: {basarili: false, ozet: 'BAĞLANTI HATASI - SUNUCUYA ULAŞILAMIYOR', hata_detay: 'SUNUCUYA BAĞLANTI KURULAMADI'}});
    }
  };

  /* AYARLARI KAYDET */
  const kaydet = async () => {
    setSaving(true);
    setMesaj({type: '', text: ''});
    const r = await api.ayarlarGuncelle(ayarlar);
    if (r?.success) {
      setMesaj({type: 'success', text: 'AYARLAR BAŞARIYLA KAYDEDİLDİ'});
      // KAYDETME SONRASI GEMİNİ API TESTİ YAP
      geminiTestEt(ayarlar.gemini_api_key);
    } else {
      setMesaj({type: 'error', text: r?.error || 'AYARLAR KAYDEDİLİRKEN HATA OLUŞTU'});
    }
    setSaving(false);
    setTimeout(() => setMesaj({type: '', text: ''}), 6000);
  };

  /* LOGO DOSYA SEÇ */
  const handleLogoSelect = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    /* DOSYA TİPİ KONTROL */
    const validTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/svg+xml'];
    if (!validTypes.includes(file.type)) {
      setMesaj({type: 'error', text: 'GEÇERSİZ DOSYA TİPİ. SADECE PNG, JPG VEYA SVG KABUL EDİLİR'});
      setTimeout(() => setMesaj({type: '', text: ''}), 4000);
      return;
    }

    /* BOYUT KONTROL (MAX 2MB) */
    if (file.size > 2 * 1024 * 1024) {
      setMesaj({type: 'error', text: 'DOSYA BOYUTU ÇOK BÜYÜK. MAKSİMUM 2MB KABUL EDİLİR'});
      setTimeout(() => setMesaj({type: '', text: ''}), 4000);
      return;
    }

    setLogoFile(file);
    const reader = new FileReader();
    reader.onload = (ev) => setLogoPreview(ev.target.result);
    reader.readAsDataURL(file);
  };

  /* LOGO YÜKLE */
  const logoYukle = async () => {
    if (!logoFile) return;
    setLogoUploading(true);
    setMesaj({type: '', text: ''});
    const r = await api.logoYukle(logoFile);
    if (r?.success) {
      setMesaj({type: 'success', text: 'LOGO BAŞARIYLA YÜKLENDİ'});
      setLogoFile(null);
      if (r.data?.logo_url) {
        setLogoPreview(r.data.logo_url);
        up('logo_url', r.data.logo_url);
      }
    } else {
      setMesaj({type: 'error', text: r?.error || 'LOGO YÜKLENİRKEN HATA OLUŞTU'});
    }
    setLogoUploading(false);
    setTimeout(() => setMesaj({type: '', text: ''}), 4000);
  };

  /* LOGO KALDIR */
  const logoKaldir = () => {
    setLogoPreview('');
    setLogoFile(null);
    up('logo_url', '');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  if (loading) return <Loading/>;

  /* GÖRÜNÜM AYARLARI VARSAYILAN DEĞERLER */
  const baslikFontBoyut = parseInt(ayarlar.baslik_font_boyut) || 22;
  const baslikRenk = ayarlar.baslik_renk || '#ffffff';
  const sloganFontBoyut = parseInt(ayarlar.slogan_font_boyut) || 10;
  const sloganRenk = ayarlar.slogan_renk || '#94a3b8';

  return (
    <div>
      {/* MESAJ */}
      {mesaj.text && (
        <div style={{
          padding: '12px 16px', borderRadius: 8, marginBottom: 16, fontSize: 12, fontWeight: 600,
          background: mesaj.type === 'success' ? `${C.success}22` : `${C.danger}22`,
          border: `1px solid ${mesaj.type === 'success' ? C.success + '44' : C.danger + '44'}`,
          color: mesaj.type === 'success' ? C.success : C.danger,
          display: 'flex', alignItems: 'center', gap: 8
        }}>
          <LIcon name={mesaj.type === 'success' ? 'CheckCircle' : 'AlertCircle'} size={16}
            color={mesaj.type === 'success' ? C.success : C.danger}/>
          {mesaj.text}
        </div>
      )}

      <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16}}>
        {/* ─── BÖLÜM 1: FİRMA BİLGİLERİ ─── */}
        <div style={{...S.card, gridColumn: '1 / -1'}}>
          <div style={{...S.cardHead, padding: '12px 16px'}}>
            <LIcon name="Building2" size={14} color={C.accent}/>
            <span style={{fontSize: 12, fontWeight: 700}}>FİRMA BİLGİLERİ</span>
          </div>
          <div style={{padding: 16}}>
            <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16}}>
              <div>
                <label style={S.label}>FİRMA ADI</label>
                <input style={S.input} value={ayarlar.firma_adi || ''}
                  onChange={e => up('firma_adi', e.target.value)} placeholder="FİRMA ADI GİRİNİZ"/>
              </div>
              <div>
                <label style={S.label}>SLOGAN</label>
                <input style={S.input} value={ayarlar.slogan || ''}
                  onChange={e => up('slogan', e.target.value)} placeholder="FİRMA SLOGANI"/>
              </div>
              <div>
                <label style={S.label}>TELEFON</label>
                <input style={S.input} type="tel" value={ayarlar.firma_telefon || ''}
                  onChange={e => up('firma_telefon', e.target.value)} placeholder="0XXX XXX XXXX"/>
              </div>
              <div>
                <label style={S.label}>E-POSTA</label>
                <input style={S.input} type="email" value={ayarlar.firma_email || ''}
                  onChange={e => up('firma_email', e.target.value)} placeholder="INFO@FIRMA.COM"/>
              </div>
              <div style={{gridColumn: '1 / -1'}}>
                <label style={S.label}>ADRES</label>
                <textarea style={{...S.input, minHeight: 60, resize: 'vertical'}} value={ayarlar.firma_adres || ''}
                  onChange={e => up('firma_adres', e.target.value)} placeholder="FİRMA ADRESİ GİRİNİZ"/>
              </div>
              <div>
                <label style={S.label}>İL</label>
                <select style={S.select} value={ayarlar.firma_il || ''}
                  onChange={e => up('firma_il', e.target.value)}>
                  <option value="">İL SEÇİNİZ</option>
                  {(MR.ILLER || []).map(il => <option key={il} value={il}>{il}</option>)}
                </select>
              </div>
              <div>
                <label style={S.label}>VERGİ DAİRESİ</label>
                <input style={S.input} value={ayarlar.vergi_dairesi || ''}
                  onChange={e => up('vergi_dairesi', e.target.value)} placeholder="VERGİ DAİRESİ"/>
              </div>
              <div>
                <label style={S.label}>VERGİ NO</label>
                <input style={S.input} value={ayarlar.vergi_no || ''}
                  onChange={e => up('vergi_no', e.target.value)} placeholder="VERGİ NUMARASI"/>
              </div>
            </div>
          </div>
        </div>

        {/* ─── BÖLÜM 2: LOGO YÖNETİMİ ─── */}
        <div style={S.card}>
          <div style={{...S.cardHead, padding: '12px 16px'}}>
            <LIcon name="Image" size={14} color={C.accent}/>
            <span style={{fontSize: 12, fontWeight: 700}}>LOGO YÖNETİMİ</span>
          </div>
          <div style={{padding: 16}}>
            {/* LOGO ÖNİZLEME */}
            <div style={{
              width: '100%', minHeight: 120, borderRadius: 8,
              border: `2px dashed ${C.borderLight}`, background: C.bgHover,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              marginBottom: 16, overflow: 'hidden'
            }}>
              {logoPreview ? (
                <img src={logoPreview} alt="LOGO" style={{maxWidth: '100%', maxHeight: 120, objectFit: 'contain'}}/>
              ) : (
                <div style={{textAlign: 'center', padding: 20}}>
                  <LIcon name="Image" size={32} color={C.textMuted}/>
                  <div style={{fontSize: 11, color: C.textMuted, marginTop: 8}}>LOGO YÜKLENMEMİŞ</div>
                </div>
              )}
            </div>

            <div style={{fontSize: 10, color: C.textMuted, marginBottom: 12}}>
              KABUL EDİLEN FORMATLAR: PNG, JPG, SVG &middot; MAKSİMUM 2MB
            </div>

            <input type="file" ref={fileInputRef} accept="image/png,image/jpeg,image/jpg,image/svg+xml"
              style={{display: 'none'}} onChange={handleLogoSelect}/>

            <div style={{display: 'flex', gap: 8}}>
              <button style={{...S.btn, ...S.btnP, fontSize: 11, padding: '8px 16px', flex: 1}}
                onClick={() => fileInputRef.current?.click()}>
                <LIcon name="Upload" size={14} color="#fff"/> LOGO SEÇ
              </button>
              {logoFile && (
                <button style={{...S.btn, ...S.btnS, fontSize: 11, padding: '8px 16px', flex: 1,
                  opacity: logoUploading ? 0.7 : 1}}
                  onClick={logoYukle} disabled={logoUploading}>
                  <LIcon name="Save" size={14} color="#fff"/>
                  {logoUploading ? 'YÜKLENİYOR...' : 'LOGOYU YÜKLE'}
                </button>
              )}
              {logoPreview && (
                <button style={{...S.btn, ...S.btnG, fontSize: 11, padding: '8px 16px',
                  color: C.danger, borderColor: C.danger + '33'}}
                  onClick={logoKaldir}>
                  <LIcon name="Trash2" size={14} color={C.danger}/> KALDIR
                </button>
              )}
            </div>
          </div>
        </div>

        {/* ─── BÖLÜM 3: GÖRÜNÜM AYARLARI ─── */}
        <div style={S.card}>
          <div style={{...S.cardHead, padding: '12px 16px'}}>
            <LIcon name="Palette" size={14} color={C.accent}/>
            <span style={{fontSize: 12, fontWeight: 700}}>GÖRÜNÜM AYARLARI</span>
          </div>
          <div style={{padding: 16}}>
            {/* CANLI ÖNİZLEME */}
            <div style={{
              background: '#0f172a', borderRadius: 8, padding: '16px 20px', marginBottom: 16,
              display: 'flex', alignItems: 'center', gap: 12
            }}>
              {logoPreview && (
                <img src={logoPreview} alt="LOGO" style={{width: 36, height: 36, objectFit: 'contain', borderRadius: 4}}/>
              )}
              <div>
                <div style={{
                  fontSize: baslikFontBoyut, fontWeight: 800, color: baslikRenk,
                  lineHeight: 1.2, letterSpacing: '-0.5px'
                }}>
                  {ayarlar.firma_adi || 'MR HASAR'}
                </div>
                <div style={{
                  fontSize: sloganFontBoyut, fontWeight: 500, color: sloganRenk,
                  letterSpacing: '1px', marginTop: 2
                }}>
                  {ayarlar.slogan || 'DANIŞMANLIK'}
                </div>
              </div>
            </div>

            {/* BAŞLIK FONT BOYUTU */}
            <div style={{marginBottom: 16}}>
              <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6}}>
                <label style={{...S.label, margin: 0}}>BAŞLIK FONT BOYUTU</label>
                <span style={{fontSize: 11, fontWeight: 700, color: C.accent}}>{baslikFontBoyut}PX</span>
              </div>
              <input type="range" min="14" max="30" value={baslikFontBoyut}
                onChange={e => up('baslik_font_boyut', e.target.value)}
                style={{width: '100%', accentColor: C.accent}}/>
            </div>

            {/* BAŞLIK RENGİ */}
            <div style={{marginBottom: 16}}>
              <label style={S.label}>BAŞLIK RENGİ</label>
              <div style={{display: 'flex', alignItems: 'center', gap: 10}}>
                <input type="color" value={baslikRenk}
                  onChange={e => up('baslik_renk', e.target.value)}
                  style={{width: 40, height: 32, border: 'none', borderRadius: 4, cursor: 'pointer', padding: 0}}/>
                <input style={{...S.input, flex: 1, fontFamily: 'monospace', fontSize: 11}} value={baslikRenk}
                  onChange={e => up('baslik_renk', e.target.value)} placeholder="#FFFFFF"/>
              </div>
            </div>

            {/* SLOGAN FONT BOYUTU */}
            <div style={{marginBottom: 16}}>
              <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6}}>
                <label style={{...S.label, margin: 0}}>SLOGAN FONT BOYUTU</label>
                <span style={{fontSize: 11, fontWeight: 700, color: C.accent}}>{sloganFontBoyut}PX</span>
              </div>
              <input type="range" min="8" max="16" value={sloganFontBoyut}
                onChange={e => up('slogan_font_boyut', e.target.value)}
                style={{width: '100%', accentColor: C.accent}}/>
            </div>

            {/* SLOGAN RENGİ */}
            <div>
              <label style={S.label}>SLOGAN RENGİ</label>
              <div style={{display: 'flex', alignItems: 'center', gap: 10}}>
                <input type="color" value={sloganRenk}
                  onChange={e => up('slogan_renk', e.target.value)}
                  style={{width: 40, height: 32, border: 'none', borderRadius: 4, cursor: 'pointer', padding: 0}}/>
                <input style={{...S.input, flex: 1, fontFamily: 'monospace', fontSize: 11}} value={sloganRenk}
                  onChange={e => up('slogan_renk', e.target.value)} placeholder="#94A3B8"/>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ─── BÖLÜM 4: GOOGLE GEMİNİ API AYARLARI ─── */}
      <div style={{...S.card, marginBottom: 16}}>
        <div style={{...S.cardHead, padding: '12px 16px'}}>
          <LIcon name="Sparkles" size={14} color={C.warning}/>
          <span style={{fontSize: 12, fontWeight: 700}}>GOOGLE GEMİNİ AI AYARLARI</span>
          <span style={{...S.badge(C.warning), marginLeft: 8, fontSize: 9}}>MOTİVASYON SÖZLERİ</span>
          {apiTest.sonuc && (
            <span style={{
              ...S.badge(apiTest.sonuc.basarili ? C.success : C.danger),
              marginLeft: 8, fontSize: 9
            }}>
              {apiTest.sonuc.basarili ? 'API AKTİF' : 'API HATALI'}
            </span>
          )}
        </div>
        <div style={{padding: 16}}>
          <div style={{
            padding: '10px 14px', background: `${C.accent}10`, borderRadius: 8,
            border: `1px solid ${C.accent}20`, marginBottom: 16, fontSize: 11, color: C.textSec, lineHeight: 1.6
          }}>
            <LIcon name="Info" size={13} color={C.accent} style={{verticalAlign: 'middle'}}/>{' '}
            HER SAYFA GEÇİŞİNDE GOOGLE GEMİNİ AI İLE MOTİVE EDİCİ SÖZLER GÖSTERİLİR.
            API ANAHTARI LİMİTİ DOLDUĞUNDA BURADAN YENİ ANAHTAR GİREBİLİRSİNİZ.
            BOŞ BIRAKIRSANIZ VARSAYILAN ANAHTAR KULLANILIR.
            API ÇALIŞMAZSA YEDEK SÖZLER OTOMATİK GÖSTERİLİR.
          </div>
          <div style={{display: 'grid', gap: 16}}>
            <div>
              <label style={S.label}>GOOGLE GEMİNİ API ANAHTARI</label>
              <div style={{display: 'flex', gap: 8, alignItems: 'center'}}>
                <input style={{...S.input, flex: 1, fontFamily: 'monospace', fontSize: 12, letterSpacing: 0.5}}
                  value={ayarlar.gemini_api_key || ''}
                  onChange={e => up('gemini_api_key', e.target.value)}
                  placeholder="AIzaSy... (BOŞ BIRAKIRSANIZ VARSAYILAN KULLANILIR)"/>
                <button style={{
                  ...S.btn, background: C.accent, color: '#fff', fontSize: 11, padding: '10px 16px',
                  fontWeight: 700, whiteSpace: 'nowrap', opacity: apiTest.testing ? 0.7 : 1,
                  borderRadius: 8, display: 'flex', alignItems: 'center', gap: 6
                }} onClick={() => geminiTestEt(ayarlar.gemini_api_key)} disabled={apiTest.testing}>
                  <LIcon name={apiTest.testing ? 'Loader2' : 'Zap'} size={14} color="#fff"/>
                  {apiTest.testing ? 'TEST EDİLİYOR...' : 'API TEST ET'}
                </button>
              </div>
              <div style={{fontSize: 10, color: C.textMuted, marginTop: 6}}>
                GOOGLE AI STUDIO'DAN ÜCRETSİZ API ANAHTARI ALABİLİRSİNİZ: AISTUDIO.GOOGLE.COM
              </div>
            </div>
          </div>

          {/* API TEST SONUCU PANELİ */}
          {apiTest.testing && (
            <div style={{
              marginTop: 16, padding: '14px 16px', borderRadius: 10,
              background: `${C.accent}10`, border: `1px solid ${C.accent}30`,
              display: 'flex', alignItems: 'center', gap: 10
            }}>
              <div style={{
                width: 20, height: 20, border: `2px solid ${C.accent}`,
                borderTopColor: 'transparent', borderRadius: '50%',
                animation: 'spin 1s linear infinite'
              }}/>
              <span style={{fontSize: 12, color: C.textSec, fontWeight: 600}}>
                GEMİNİ API TEST EDİLİYOR... LÜTFEN BEKLEYİN
              </span>
            </div>
          )}

          {apiTest.sonuc && !apiTest.testing && (
            <div style={{
              marginTop: 16, padding: '16px', borderRadius: 10,
              background: apiTest.sonuc.basarili ? `${C.success}10` : `${C.danger}10`,
              border: `1px solid ${apiTest.sonuc.basarili ? C.success : C.danger}30`
            }}>
              {/* BAŞLIK */}
              <div style={{
                display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12
              }}>
                <div style={{
                  width: 32, height: 32, borderRadius: '50%',
                  background: apiTest.sonuc.basarili ? `${C.success}20` : `${C.danger}20`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center'
                }}>
                  <LIcon name={apiTest.sonuc.basarili ? 'CheckCircle' : 'XCircle'} size={18}
                    color={apiTest.sonuc.basarili ? C.success : C.danger}/>
                </div>
                <div>
                  <div style={{fontSize: 13, fontWeight: 700, color: apiTest.sonuc.basarili ? C.success : C.danger}}>
                    {apiTest.sonuc.basarili ? 'API BAŞARIYLA ÇALIŞIYOR!' : 'API ÇALIŞMIYOR!'}
                  </div>
                  <div style={{fontSize: 11, color: C.textSec, marginTop: 2}}>
                    {apiTest.sonuc.key_kaynak || ''}
                    {apiTest.sonuc.key_on_ek ? ` (${apiTest.sonuc.key_on_ek})` : ''}
                  </div>
                </div>
              </div>

              {/* DETAYLAR */}
              <div style={{
                display: 'grid', gap: 8, fontSize: 11, color: C.textSec
              }}>
                {/* GEREKÇE / HATA DETAYI */}
                {apiTest.sonuc.hata_detay && !apiTest.sonuc.basarili && (
                  <div style={{
                    padding: '10px 14px', borderRadius: 8,
                    background: `${C.danger}08`, border: `1px dashed ${C.danger}40`
                  }}>
                    <div style={{fontWeight: 700, color: C.danger, marginBottom: 4, fontSize: 11}}>
                      <LIcon name="AlertTriangle" size={12} color={C.danger} style={{verticalAlign: 'middle'}}/> HATA GEREKÇESİ:
                    </div>
                    <div style={{color: C.text, lineHeight: 1.6, fontWeight: 600}}>
                      {apiTest.sonuc.hata_detay}
                    </div>
                  </div>
                )}

                {/* TEKNİK BİLGİLER */}
                <div style={{
                  display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 6,
                  padding: '10px 14px', borderRadius: 8, background: `${C.bgHover}`
                }}>
                  <div><span style={{color: C.textMuted}}>YÖNTEM:</span> <span style={{fontWeight: 600}}>{apiTest.sonuc.yontem || '-'}</span></div>
                  <div><span style={{color: C.textMuted}}>HTTP KODU:</span> <span style={{fontWeight: 600, color: apiTest.sonuc.http_kodu === 200 ? C.success : C.danger}}>{apiTest.sonuc.http_kodu || '-'}</span></div>
                  <div><span style={{color: C.textMuted}}>cURL:</span> <span style={{fontWeight: 600, color: apiTest.sonuc.curl_destegi ? C.success : C.danger}}>{apiTest.sonuc.curl_destegi ? 'AKTİF' : 'KAPALI'}</span></div>
                  <div><span style={{color: C.textMuted}}>FILE_GET_CONTENTS:</span> <span style={{fontWeight: 600, color: apiTest.sonuc.file_get_contents_destegi ? C.success : C.danger}}>{apiTest.sonuc.file_get_contents_destegi ? 'AKTİF' : 'KAPALI'}</span></div>
                </div>

                {/* BAŞARILI İSE ÖRNEK SÖZ */}
                {apiTest.sonuc.basarili && apiTest.sonuc.soz && (
                  <div style={{
                    padding: '10px 14px', borderRadius: 8,
                    background: `${C.success}08`, border: `1px dashed ${C.success}40`,
                    fontStyle: 'italic', color: C.text, lineHeight: 1.6
                  }}>
                    <div style={{fontWeight: 700, color: C.success, marginBottom: 4, fontSize: 10, fontStyle: 'normal'}}>
                      <LIcon name="Quote" size={12} color={C.success} style={{verticalAlign: 'middle'}}/> ÖRNEK YANIT:
                    </div>
                    "{apiTest.sonuc.soz}"
                  </div>
                )}

                {/* BAŞARISIZ İSE ÇÖZÜM ÖNERİLERİ */}
                {!apiTest.sonuc.basarili && (
                  <div style={{
                    padding: '10px 14px', borderRadius: 8,
                    background: `${C.warning}08`, border: `1px dashed ${C.warning}40`
                  }}>
                    <div style={{fontWeight: 700, color: C.warning, marginBottom: 6, fontSize: 11}}>
                      <LIcon name="Lightbulb" size={12} color={C.warning} style={{verticalAlign: 'middle'}}/> ÇÖZÜM ÖNERİLERİ:
                    </div>
                    <div style={{lineHeight: 1.8, color: C.textSec}}>
                      {apiTest.sonuc.http_kodu === 429 && '• KOTA DOLMUŞ: FARKLI BİR API ANAHTARI GİRİN VEYA 24 SAAT BEKLEYİN\n'}
                      {(apiTest.sonuc.http_kodu === 401 || apiTest.sonuc.http_kodu === 403) && '• AISTUDIO.GOOGLE.COM ADRESINDEN YENİ API ANAHTARI OLUŞTURUN\n'}
                      {apiTest.sonuc.http_kodu === 0 && '• SUNUCUNUZDA DIŞARI ÇIKIŞ (OUTBOUND) BAĞLANTISI KAPALI OLABİLİR - HOSTİNG FİRMANIZLA İLETİŞİME GEÇİN\n'}
                      • BOŞ BIRAKIRSANIZ VARSAYILAN ANAHTAR KULLANILIR<br/>
                      • API ÇALIŞMASA BİLE YEDEK SÖZLER OTOMATİK GÖSTERİLİR<br/>
                      • AISTUDIO.GOOGLE.COM ADRESİNDEN ÜCRETSİZ YENİ ANAHTAR ALABİLİRSİNİZ
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* KAYDET BUTONU */}
      <div style={{
        ...S.card, padding: '16px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between'
      }}>
        <div style={{fontSize: 12, color: C.textMuted}}>
          <LIcon name="Info" size={14} color={C.textMuted} style={{verticalAlign: 'middle'}}/>{' '}
          TÜM AYARLARI KAYDETMEK İÇİN BUTONA BASIN
        </div>
        <button style={{
          ...S.btn, ...S.btnP, fontSize: 13, padding: '12px 32px', fontWeight: 700,
          opacity: saving ? 0.7 : 1
        }} onClick={kaydet} disabled={saving}>
          <LIcon name="Save" size={16} color="#fff"/>
          {saving ? 'KAYDEDİLİYOR...' : 'AYARLARI KAYDET'}
        </button>
      </div>
    </div>
  );
};

/* ════════════════════════════════════════════════════════════════
   TAB 4 - LOG KAYITLARI
   ════════════════════════════════════════════════════════════════ */
const LogTab = () => {
  const {C, S, LIcon, Badge, Loading, EmptyState, api} = MR;
  const [loglar, setLoglar] = useState([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [sayfa, setSayfa] = useState(0);
  const [kullanicilar, setKullanicilar] = useState([]);
  const limit = 25;

  const [filtreler, setFiltreler] = useState({
    islem: '',
    kullanici_id: '',
    modul: '',
    baslangic: '',
    bitis: ''
  });

  const upF = (k, v) => setFiltreler(p => ({...p, [k]: v}));

  /* MODÜL SEÇENEKLERİ */
  const moduller = ['DOSYA', 'CRM', 'MUHASEBE', 'MASRAF', 'EVRAK', 'KULLANICI', 'TANIM', 'BİLDİRİM', 'AJANDA', 'SİSTEM', 'AUTH'];

  /* KULLANICI LİSTESİ (FİLTRE İÇİN) */
  useEffect(() => {
    (async () => {
      const r = await api.kullaniciList();
      if (r?.success) {
        const items = r.data?.items || r.data || [];
        setKullanicilar(Array.isArray(items) ? items : []);
      }
    })();
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    const p = {limit, offset: sayfa * limit};
    if (filtreler.islem) p.islem = filtreler.islem;
    if (filtreler.kullanici_id) p.kullanici_id = filtreler.kullanici_id;
    if (filtreler.modul) p.modul = filtreler.modul;
    if (filtreler.baslangic) p.baslangic = filtreler.baslangic;
    if (filtreler.bitis) p.bitis = filtreler.bitis;

    const r = await api.loglar(p);
    if (r?.success) {
      const items = r.data?.items || r.data || [];
      setLoglar(Array.isArray(items) ? items : []);
      setTotal(r.data?.pagination?.total || r.data?.total || items.length || 0);
    } else {
      setLoglar([]);
      setTotal(0);
    }
    setLoading(false);
  }, [sayfa, filtreler]);

  useEffect(() => { load(); }, [load]);

  /* FİLTRE DEĞİŞTİĞİNDE SAYFAYI SIFIRLA */
  const filtreDegistir = (k, v) => {
    upF(k, v);
    setSayfa(0);
  };

  const toplamSayfa = Math.max(1, Math.ceil(total / limit));

  /* ─── CSV EXPORT ─── */
  const exportCSV = () => {
    if (loglar.length === 0) return;
    const headers = ['TARİH', 'KULLANICI', 'İŞLEM', 'DETAY', 'MODÜL', 'KAYIT ID'];
    const rows = loglar.map(l => [
      l.created_at || l.tarih || '',
      l.kullanici_adi || l.kullanici || '',
      l.islem || '',
      (l.detay || '').replace(/"/g, '""'),
      l.modul || '',
      l.kayit_id || ''
    ]);

    let csv = '\uFEFF'; /* BOM - EXCEL TÜRKÇE UYUMLULUĞU */
    csv += headers.join(';') + '\n';
    rows.forEach(row => {
      csv += row.map(v => `"${v}"`).join(';') + '\n';
    });

    const blob = new Blob([csv], {type: 'text/csv;charset=utf-8;'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `LOG_KAYITLARI_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  /* FİLTRELERİ TEMİZLE */
  const filtreTemizle = () => {
    setFiltreler({islem: '', kullanici_id: '', modul: '', baslangic: '', bitis: ''});
    setSayfa(0);
  };

  const aktifFiltreSayisi = Object.values(filtreler).filter(v => v).length;

  return (
    <div>
      {/* FİLTRE ALANI */}
      <div style={{...S.card, marginBottom:16}}>
        <div style={{...S.cardHead, justifyContent:'space-between', padding:'12px 16px'}}>
          <div style={{display:'flex', alignItems:'center', gap:10}}>
            <LIcon name="Filter" size={14} color={C.accent}/>
            <span style={{fontSize:12, fontWeight:700}}>FİLTRELER</span>
            {aktifFiltreSayisi > 0 && <Badge text={`${aktifFiltreSayisi} FİLTRE AKTİF`} color={C.warning}/>}
          </div>
          <div style={{display:'flex', gap:8}}>
            {aktifFiltreSayisi > 0 && (
              <button style={{...S.btn, ...S.btnG, fontSize:10, padding:'6px 12px'}} onClick={filtreTemizle}>
                <LIcon name="X" size={12} color={C.textSec}/> TEMİZLE
              </button>
            )}
            <button style={{...S.btn, ...S.btnS, fontSize:10, padding:'6px 12px'}} onClick={exportCSV} disabled={loglar.length === 0}>
              <LIcon name="Download" size={12} color="#fff"/> CSV EXPORT
            </button>
          </div>
        </div>
        <div style={{padding:16, display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:12}}>
          <div>
            <label style={S.label}>İŞLEM</label>
            <input style={{...S.input, fontSize:11}} placeholder="İŞLEM ARA..."
              value={filtreler.islem} onChange={e => filtreDegistir('islem', e.target.value)}/>
          </div>
          <div>
            <label style={S.label}>KULLANICI</label>
            <select style={{...S.select, fontSize:11}} value={filtreler.kullanici_id}
              onChange={e => filtreDegistir('kullanici_id', e.target.value)}>
              <option value="">TÜMÜ</option>
              {kullanicilar.map(u => <option key={u.id} value={u.id}>{u.ad_soyad}</option>)}
            </select>
          </div>
          <div>
            <label style={S.label}>MODÜL</label>
            <select style={{...S.select, fontSize:11}} value={filtreler.modul}
              onChange={e => filtreDegistir('modul', e.target.value)}>
              <option value="">TÜMÜ</option>
              {moduller.map(m => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>
          <div>
            <label style={S.label}>BAŞLANGIÇ TARİHİ</label>
            <input type="date" style={{...S.input, fontSize:11}} value={filtreler.baslangic}
              onChange={e => filtreDegistir('baslangic', e.target.value)}/>
          </div>
          <div>
            <label style={S.label}>BİTİŞ TARİHİ</label>
            <input type="date" style={{...S.input, fontSize:11}} value={filtreler.bitis}
              onChange={e => filtreDegistir('bitis', e.target.value)}/>
          </div>
        </div>
      </div>

      {/* LOG TABLOSU */}
      <div style={S.card}>
        <div style={{...S.cardHead, justifyContent:'space-between'}}>
          <div style={{display:'flex', alignItems:'center', gap:10}}>
            <LIcon name="Activity" size={14} color={C.accent}/>
            <span style={{fontSize:13, fontWeight:700}}>LOG KAYITLARI</span>
            <Badge text={`${total} KAYIT`} color={C.accent}/>
          </div>
          <span style={{fontSize:10, color:C.textMuted}}>
            SAYFA {sayfa + 1} / {toplamSayfa}
          </span>
        </div>

        {loading ? <Loading/> : loglar.length === 0 ? (
          <EmptyState icon="Activity" title="LOG KAYDI BULUNAMADI" desc="FİLTRE KRİTERLERİNİZE UYGUN KAYIT BULUNMAMAKTADIR"/>
        ) : (
          <div style={{overflowX:'auto'}}>
            <table style={{width:'100%', borderCollapse:'collapse', fontSize:11, minWidth:900}}>
              <thead>
                <tr style={{background:C.bgHover}}>
                  {['TARİH', 'KULLANICI', 'İŞLEM', 'DETAY', 'MODÜL', 'KAYIT ID'].map(h =>
                    <th key={h} style={{padding:'10px 12px', textAlign:'left', color:C.textMuted, fontWeight:600, fontSize:9, borderBottom:`1px solid ${C.border}`}}>{h}</th>
                  )}
                </tr>
              </thead>
              <tbody>
                {loglar.map((log, i) => {
                  const islemRenk = LOG_ISLEM_RENK(log.islem);
                  return (
                    <tr key={log.id || i} style={{borderBottom:`1px solid ${C.border}`}}
                      onMouseEnter={e => e.currentTarget.style.background = C.bgHover}
                      onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                      <td style={{padding:'10px 12px', color:C.textMuted, fontSize:10, whiteSpace:'nowrap'}}>
                        {log.created_at || log.tarih || '-'}
                      </td>
                      <td style={{padding:'10px 12px', fontWeight:600}}>
                        {log.kullanici_adi || log.kullanici || '-'}
                      </td>
                      <td style={{padding:'10px 12px'}}>
                        <Badge text={log.islem || '-'} color={islemRenk}/>
                      </td>
                      <td style={{padding:'10px 12px', color:C.textSec, maxWidth:300, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap'}}>
                        {log.detay || '-'}
                      </td>
                      <td style={{padding:'10px 12px'}}>
                        <Badge text={log.modul || '-'} color={C.purple}/>
                      </td>
                      <td style={{padding:'10px 12px', color:C.textMuted, fontFamily:'monospace', fontSize:10}}>
                        {log.kayit_id || '-'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* SAYFALAMA */}
        {total > limit && (
          <div style={{padding:'14px 20px', borderTop:`1px solid ${C.border}`, display:'flex', justifyContent:'space-between', alignItems:'center'}}>
            <span style={{fontSize:10, color:C.textMuted}}>
              TOPLAM {total} KAYIT | {sayfa * limit + 1} - {Math.min((sayfa + 1) * limit, total)} ARASI GÖSTERİLİYOR
            </span>
            <div style={{display:'flex', gap:4}}>
              <button onClick={() => setSayfa(0)} disabled={sayfa === 0}
                style={{...S.btn, ...S.btnG, fontSize:10, padding:'6px 10px', opacity: sayfa === 0 ? 0.4 : 1}}>
                <LIcon name="ChevronLeft" size={12} color={C.textSec}/>
                <LIcon name="ChevronLeft" size={12} color={C.textSec}/>
              </button>
              <button onClick={() => setSayfa(p => Math.max(0, p - 1))} disabled={sayfa === 0}
                style={{...S.btn, ...S.btnG, fontSize:10, padding:'6px 10px', opacity: sayfa === 0 ? 0.4 : 1}}>
                <LIcon name="ChevronLeft" size={12} color={C.textSec}/> ÖNCEKİ
              </button>

              {/* SAYFA NUMARALARI */}
              {(() => {
                const pages = [];
                const start = Math.max(0, sayfa - 2);
                const end = Math.min(toplamSayfa - 1, sayfa + 2);
                for (let p = start; p <= end; p++) {
                  pages.push(
                    <button key={p} onClick={() => setSayfa(p)}
                      style={{
                        ...S.btn, fontSize:10, padding:'6px 12px', minWidth:36,
                        background: p === sayfa ? C.accent : C.borderLight,
                        color: p === sayfa ? '#fff' : C.textSec,
                        fontWeight: p === sayfa ? 700 : 400
                      }}>
                      {p + 1}
                    </button>
                  );
                }
                return pages;
              })()}

              <button onClick={() => setSayfa(p => Math.min(toplamSayfa - 1, p + 1))} disabled={sayfa >= toplamSayfa - 1}
                style={{...S.btn, ...S.btnG, fontSize:10, padding:'6px 10px', opacity: sayfa >= toplamSayfa - 1 ? 0.4 : 1}}>
                SONRAKİ <LIcon name="ChevronRight" size={12} color={C.textSec}/>
              </button>
              <button onClick={() => setSayfa(toplamSayfa - 1)} disabled={sayfa >= toplamSayfa - 1}
                style={{...S.btn, ...S.btnG, fontSize:10, padding:'6px 10px', opacity: sayfa >= toplamSayfa - 1 ? 0.4 : 1}}>
                <LIcon name="ChevronRight" size={12} color={C.textSec}/>
                <LIcon name="ChevronRight" size={12} color={C.textSec}/>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

/* ════════════════════════════════════════════════════════════════
   TAB 6 - SMS BİLDİRİM AYARLARI
   DOSYA DURUM DEĞİŞİKLİĞİNDE OTOMATİK SMS GÖNDERİMİ
   ════════════════════════════════════════════════════════════════ */
const SmsTab = () => {
  const {C, S, LIcon, Badge, FormGroup, Loading, api, fmt} = MR;
  const [smsAltTab, setSmsAltTab] = useState('ayarlar');
  const [ayarlar, setAyarlar] = useState({sms_aktif:'0',sms_kullanici:'',sms_sifre:'',sms_baslik:''});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [mesaj, setMesaj] = useState(null);
  const [testTel, setTestTel] = useState('');
  const [testLoading, setTestLoading] = useState(false);
  const [loglar, setLoglar] = useState([]);
  const [logLoading, setLogLoading] = useState(false);
  const [logPage, setLogPage] = useState(1);
  const [logTotal, setLogTotal] = useState(0);
  // GELEN SMS STATE
  const [gelenSmsler, setGelenSmsler] = useState([]);
  const [gelenLoading, setGelenLoading] = useState(false);
  const [gelenPage, setGelenPage] = useState(1);
  const [gelenTotal, setGelenTotal] = useState(0);
  const [gelenOkunmamis, setGelenOkunmamis] = useState(0);
  const [gelenArama, setGelenArama] = useState('');

  useEffect(() => {
    (async () => {
      setLoading(true);
      const r = await api.ayarlarList();
      if (r?.success && r.data) {
        const a = {};
        (Array.isArray(r.data) ? r.data : []).forEach(item => {
          if (item.anahtar && item.anahtar.startsWith('sms_')) a[item.anahtar] = item.deger || '';
        });
        if (Object.keys(a).length === 0 && typeof r.data === 'object' && !Array.isArray(r.data)) {
          Object.keys(r.data).forEach(k => {
            if (k.startsWith('sms_')) a[k] = r.data[k] || '';
          });
        }
        setAyarlar(prev => ({...prev, ...a}));
      }
      setLoading(false);
      smsLoglariYukle(1);
      gelenSmsYukle(1, '');
    })();
  }, []);

  const smsLoglariYukle = async (page) => {
    setLogLoading(true);
    const r = await api.smsLogList({page, limit: 15});
    if (r?.success && r.data) {
      setLoglar(r.data.items || []);
      setLogTotal(r.data.pagination?.total || 0);
      setLogPage(page);
    }
    setLogLoading(false);
  };

  const gelenSmsYukle = async (page, arama) => {
    setGelenLoading(true);
    const p = {page, limit: 20};
    if (arama) p.arama = arama;
    const r = await api.smsGelenList(p);
    if (r?.success && r.data) {
      setGelenSmsler(r.data.items || []);
      setGelenTotal(r.data.pagination?.total || 0);
      setGelenOkunmamis(r.data.okunmamis || 0);
      setGelenPage(page);
    }
    setGelenLoading(false);
  };

  const gelenOkunduYap = async (id) => {
    const r = await api.smsGelenOkundu(id ? {id} : {hepsi: true});
    if (r?.success) gelenSmsYukle(gelenPage, gelenArama);
  };

  const kaydet = async () => {
    setSaving(true); setMesaj(null);
    const r = await api.ayarlarGuncelle(ayarlar);
    if (r?.success) setMesaj({type:'success', text:'SMS AYARLARI KAYDEDİLDİ'});
    else setMesaj({type:'error', text: r?.error || 'KAYIT HATASI'});
    setSaving(false);
  };

  const testGonder = async () => {
    if (!testTel) { setMesaj({type:'error', text:'TEST TELEFON NUMARASI GİRİN'}); return; }
    setTestLoading(true); setMesaj(null);
    const r = await api.smsTest({telefon: testTel});
    if (r?.success && r.data?.basarili) {
      setMesaj({type:'success', text:'TEST SMS GÖNDERİLDİ: ' + testTel});
    } else {
      setMesaj({type:'error', text: r?.data?.mesaj || r?.error || 'SMS GÖNDERİLEMEDİ'});
    }
    setTestLoading(false);
    smsLoglariYukle(1);
  };

  const u = (k,v) => setAyarlar(p => ({...p, [k]: v}));

  const durumRenk = (d) => {
    if (d === 'gonderildi') return C.success;
    if (d === 'hata') return C.danger;
    if (d === 'pasif') return C.warning;
    return C.textMuted;
  };

  if (loading) return <Loading/>;

  return (
    <div style={{display:'flex', flexDirection:'column', gap:16}}>
      {/* SMS ALT TAB NAVİGASYONU */}
      <div style={{display:'flex', gap:4, padding:4, background:C.bgHover, borderRadius:10}}>
        {[
          {id:'ayarlar', label:'SMS AYARLARI', icon:'Settings', color:C.accent},
          {id:'gelen', label:'GELEN SMS', icon:'MessageCircle', color:C.success, badge: gelenOkunmamis},
          {id:'gonderilenler', label:'GÖNDERİLEN SMS', icon:'Send', color:C.warning}
        ].map(t => (
          <div key={t.id} onClick={() => { setSmsAltTab(t.id); if(t.id==='gelen') gelenSmsYukle(1, gelenArama); }}
            style={{flex:1, padding:'10px 16px', borderRadius:8, cursor:'pointer', textAlign:'center',
              background: smsAltTab===t.id ? C.bgCard : 'transparent',
              border: smsAltTab===t.id ? `1px solid ${C.border}` : '1px solid transparent',
              boxShadow: smsAltTab===t.id ? '0 1px 4px rgba(0,0,0,0.1)' : 'none',
              transition:'all .2s', display:'flex', alignItems:'center', justifyContent:'center', gap:8}}>
            <LIcon name={t.icon} size={14} color={smsAltTab===t.id ? t.color : C.textMuted}/>
            <span style={{fontSize:11, fontWeight: smsAltTab===t.id ? 700 : 500,
              color: smsAltTab===t.id ? C.text : C.textMuted}}>{t.label}</span>
            {t.badge > 0 && (
              <span style={{background:C.danger, color:'#fff', fontSize:9, fontWeight:800,
                padding:'2px 7px', borderRadius:10, minWidth:18, textAlign:'center'}}>
                {t.badge}
              </span>
            )}
          </div>
        ))}
      </div>

      {/* ═══ GELEN SMS PANELİ ═══ */}
      {smsAltTab === 'gelen' && (
        <div style={{display:'flex', flexDirection:'column', gap:16}}>
          {/* GELEN SMS BANNER */}
          <div style={{padding:16, background:`${C.success}11`, borderRadius:12, border:`1px solid ${C.success}33`, display:'flex', alignItems:'center', gap:12}}>
            <div style={{width:44, height:44, borderRadius:12, background:`${C.success}22`, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0}}>
              <LIcon name="MessageCircle" size={22} color={C.success}/>
            </div>
            <div style={{flex:1}}>
              <div style={{fontSize:14, fontWeight:800, color:C.success}}>GELEN SMS KUTUSU</div>
              <div style={{fontSize:11, color:C.textSec, marginTop:2}}>
                NETGSM İNTERAKTİF SMS İLE GELEN MESAJLAR OTOMATİK OLARAK BURADA LİSTELENİR.
              </div>
            </div>
            {gelenOkunmamis > 0 && (
              <div style={{textAlign:'center'}}>
                <div style={{fontSize:24, fontWeight:900, color:C.danger}}>{gelenOkunmamis}</div>
                <div style={{fontSize:9, color:C.textMuted}}>OKUNMAMIŞ</div>
              </div>
            )}
          </div>

          {/* ARAMA + İŞLEMLER */}
          <div style={{display:'flex', gap:10, alignItems:'center'}}>
            <div style={{flex:1, position:'relative'}}>
              <LIcon name="Search" size={14} color={C.textMuted} style={{position:'absolute', left:12, top:10}}/>
              <input value={gelenArama} onChange={e => setGelenArama(e.target.value)}
                onKeyDown={e => e.key==='Enter' && gelenSmsYukle(1, gelenArama)}
                placeholder="TELEFON VEYA MESAJ İÇERİĞİNDE ARA..."
                style={{...S.input, paddingLeft:36, fontSize:12}}/>
            </div>
            <button onClick={() => gelenSmsYukle(1, gelenArama)}
              style={{...S.btn, ...S.btnP, fontSize:10, padding:'10px 16px'}}>
              <LIcon name="Search" size={13} color="#fff"/> ARA
            </button>
            {gelenOkunmamis > 0 && (
              <button onClick={() => gelenOkunduYap(null)}
                style={{...S.btn, ...S.btnS, fontSize:10, padding:'10px 16px'}}>
                <LIcon name="CheckCircle" size={13} color="#fff"/> TÜMÜNÜ OKUNDU YAP
              </button>
            )}
            <button onClick={() => gelenSmsYukle(1, gelenArama)}
              style={{...S.btn, ...S.btnG, fontSize:10, padding:'10px 16px'}}>
              <LIcon name="RefreshCw" size={13}/> YENİLE
            </button>
          </div>

          {/* İSTATİSTİKLER */}
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:10}}>
            <div style={{...S.stat, textAlign:'center'}}>
              <div style={{fontSize:20, fontWeight:800, color:C.success}}>{gelenTotal}</div>
              <div style={{fontSize:9, color:C.textMuted, marginTop:2}}>TOPLAM GELEN</div>
            </div>
            <div style={{...S.stat, textAlign:'center'}}>
              <div style={{fontSize:20, fontWeight:800, color:C.danger}}>{gelenOkunmamis}</div>
              <div style={{fontSize:9, color:C.textMuted, marginTop:2}}>OKUNMAMIŞ</div>
            </div>
            <div style={{...S.stat, textAlign:'center'}}>
              <div style={{fontSize:20, fontWeight:800, color:C.accent}}>{gelenTotal - gelenOkunmamis}</div>
              <div style={{fontSize:9, color:C.textMuted, marginTop:2}}>OKUNMUŞ</div>
            </div>
          </div>

          {/* GELEN SMS TABLOSU */}
          <div style={S.card}>
            <div style={{...S.cardHead, justifyContent:'space-between'}}>
              <div style={{display:'flex', alignItems:'center', gap:8}}>
                <LIcon name="Inbox" size={16} color={C.success}/>
                <span style={{fontSize:13, fontWeight:700}}>GELEN MESAJLAR</span>
                <span style={{fontSize:10, color:C.textMuted}}>({gelenTotal} KAYIT)</span>
              </div>
            </div>
            {gelenLoading ? <div style={{padding:30, textAlign:'center'}}><Loading/></div> : (
              gelenSmsler.length > 0 ? (
                <div>
                  {gelenSmsler.map((sms, i) => (
                    <div key={i} onClick={() => { if(!sms.okundu || sms.okundu==='0' || sms.okundu===0) gelenOkunduYap(sms.id); }}
                      style={{padding:'14px 20px', borderBottom:`1px solid ${C.border}22`, cursor:'pointer',
                        background: (!sms.okundu || sms.okundu==='0' || sms.okundu===0) ? `${C.accent}06` : 'transparent',
                        transition:'all .2s'}}>
                      <div style={{display:'flex', alignItems:'center', gap:12, marginBottom:8}}>
                        <div style={{width:36, height:36, borderRadius:18,
                          background: (!sms.okundu || sms.okundu==='0' || sms.okundu===0) ? `${C.success}22` : `${C.textMuted}15`,
                          display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0}}>
                          <LIcon name={(!sms.okundu || sms.okundu==='0' || sms.okundu===0) ? 'Mail' : 'MailOpen'} size={16}
                            color={(!sms.okundu || sms.okundu==='0' || sms.okundu===0) ? C.success : C.textMuted}/>
                        </div>
                        <div style={{flex:1}}>
                          <div style={{display:'flex', alignItems:'center', gap:8}}>
                            <span style={{fontSize:12, fontWeight: (!sms.okundu || sms.okundu==='0' || sms.okundu===0) ? 800 : 600, color:C.text}}>
                              {sms.gonderen_adi || 'BİLİNMEYEN'}
                            </span>
                            <span style={{fontSize:11, fontFamily:'monospace', color:C.textSec}}>{sms.gonderen}</span>
                            {sms.dosya_no && <Badge text={sms.dosya_no} color={C.accent}/>}
                            {(!sms.okundu || sms.okundu==='0' || sms.okundu===0) && (
                              <span style={{width:8, height:8, borderRadius:4, background:C.success, flexShrink:0}}/>
                            )}
                          </div>
                          <div style={{fontSize:10, color:C.textMuted, marginTop:2}}>
                            {sms.mesaj_tarihi ? new Date(sms.mesaj_tarihi).toLocaleString('tr-TR') : (sms.created_at ? new Date(sms.created_at).toLocaleString('tr-TR') : '-')}
                          </div>
                        </div>
                      </div>
                      <div style={{fontSize:12, color: (!sms.okundu || sms.okundu==='0' || sms.okundu===0) ? C.text : C.textSec,
                        lineHeight:1.6, marginLeft:48, fontWeight: (!sms.okundu || sms.okundu==='0' || sms.okundu===0) ? 600 : 400}}>
                        {sms.mesaj}
                      </div>
                    </div>
                  ))}
                  {/* SAYFALAMA */}
                  {gelenTotal > 20 && (
                    <div style={{padding:12, display:'flex', justifyContent:'center', gap:6}}>
                      {Array.from({length: Math.ceil(gelenTotal / 20)}, (_, i) => i + 1).slice(0, 10).map(p => (
                        <div key={p} onClick={() => gelenSmsYukle(p, gelenArama)}
                          style={{width:28, height:28, borderRadius:6, display:'flex', alignItems:'center', justifyContent:'center',
                            fontSize:10, fontWeight: p===gelenPage ? 800 : 500, cursor:'pointer',
                            background: p===gelenPage ? `${C.accent}22` : 'transparent',
                            color: p===gelenPage ? C.accent : C.textMuted,
                            border:`1px solid ${p===gelenPage ? C.accent+'33' : 'transparent'}`}}>
                          {p}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <div style={{padding:40, textAlign:'center'}}>
                  <LIcon name="Inbox" size={36} color={C.textMuted} style={{opacity:0.2}}/>
                  <div style={{fontSize:13, fontWeight:600, color:C.textMuted, marginTop:12}}>HENÜZ GELEN SMS BULUNMUYOR</div>
                  <div style={{fontSize:10, color:C.textMuted, marginTop:4}}>NETGSM İNTERAKTİF SMS WEBHOOK AKTİF EDİLDİĞİNDE GELEN MESAJLAR BURADA GÖRÜNECEK</div>
                </div>
              )
            )}
          </div>

          {/* WEBHOOK BİLGİ */}
          <div style={S.card}>
            <div style={{...S.cardHead, background:`${C.cyan}06`}}>
              <LIcon name="Webhook" size={16} color={C.cyan}/>
              <span style={{fontSize:13, fontWeight:700}}>WEBHOOK KURULUMU</span>
            </div>
            <div style={{padding:20, fontSize:11, color:C.textSec, lineHeight:1.8}}>
              <div style={{marginBottom:12}}>NETGSM PORTALINDAN AŞAĞIDAKİ AYARLARI YAPIN:</div>
              <div style={{display:'flex', gap:8, marginBottom:8}}>
                <div style={{width:24, height:24, borderRadius:12, background:`${C.accent}22`, display:'flex',
                  alignItems:'center', justifyContent:'center', flexShrink:0, fontSize:11, fontWeight:800, color:C.accent}}>1</div>
                <div><strong>PORTAL.NETGSM.COM.TR</strong> > SMS İŞLEMLERİ > İNTERAKTİF SMS > URL YÖNLENDİR</div>
              </div>
              <div style={{display:'flex', gap:8, marginBottom:8}}>
                <div style={{width:24, height:24, borderRadius:12, background:`${C.success}22`, display:'flex',
                  alignItems:'center', justifyContent:'center', flexShrink:0, fontSize:11, fontWeight:800, color:C.success}}>2</div>
                <div>URL ADRESİ: <code style={{background:C.bgHover, padding:'2px 8px', borderRadius:4, fontFamily:'monospace', fontSize:11}}>
                  {(ayarlar.site_url || 'https://sistem.mrhasardanismanlik.com')}/api/v1/sms/webhook.php
                </code></div>
              </div>
              <div style={{display:'flex', gap:8, marginBottom:8}}>
                <div style={{width:24, height:24, borderRadius:12, background:`${C.warning}22`, display:'flex',
                  alignItems:'center', justifyContent:'center', flexShrink:0, fontSize:11, fontWeight:800, color:C.warning}}>3</div>
                <div>HEADERS: <code style={{background:C.bgHover, padding:'2px 8px', borderRadius:4, fontFamily:'monospace', fontSize:11}}>
                  xapi-key:mr_hasar_2026
                </code></div>
              </div>
              <div style={{display:'flex', gap:8}}>
                <div style={{width:24, height:24, borderRadius:12, background:`${C.purple}22`, display:'flex',
                  alignItems:'center', justifyContent:'center', flexShrink:0, fontSize:11, fontWeight:800, color:C.purple}}>4</div>
                <div>BASICAUTH: <strong>BOŞ BIRAKIN</strong> (XAPI-KEY YETERLİ)</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ═══ GÖNDERİLEN SMS PANELİ (MEVCUT LOG) ═══ */}
      {smsAltTab === 'gonderilenler' && (
        <div style={{display:'flex', flexDirection:'column', gap:16}}>
          {/* SMS LOG TABLOSU */}
          <div style={S.card}>
            <div style={{...S.cardHead, justifyContent:'space-between'}}>
              <div style={{display:'flex', alignItems:'center', gap:8}}>
                <LIcon name="List" size={16} color={C.accent}/>
                <span style={{fontSize:13, fontWeight:700}}>SMS GÖNDERİM GEÇMİŞİ</span>
                <span style={{fontSize:10, color:C.textMuted}}>({logTotal} KAYIT)</span>
              </div>
              <button onClick={() => smsLoglariYukle(1)} style={{...S.btn, ...S.btnG, fontSize:10, padding:'5px 12px'}}>
                <LIcon name="RefreshCw" size={12}/> YENİLE
              </button>
            </div>
            {logLoading ? <div style={{padding:30, textAlign:'center'}}><Loading/></div> : (
              loglar.length > 0 ? (
                <div>
                  <table style={{width:'100%', borderCollapse:'collapse', fontSize:11}}>
                    <thead>
                      <tr style={{background:C.bgHover}}>
                        {['TARİH','TELEFON','DOSYA NO','DURUM','MESAJ','KULLANICI'].map(h =>
                          <th key={h} style={{padding:'8px 10px', textAlign:'left', color:C.textMuted, fontWeight:600, fontSize:9, borderBottom:`1px solid ${C.border}`}}>{h}</th>
                        )}
                      </tr>
                    </thead>
                    <tbody>
                      {loglar.map((log, i) => (
                        <tr key={i} style={{borderBottom:`1px solid ${C.border}22`}}>
                          <td style={{padding:'8px 10px', fontSize:10, color:C.textMuted, whiteSpace:'nowrap'}}>
                            {log.created_at ? new Date(log.created_at).toLocaleString('tr-TR') : '-'}
                          </td>
                          <td style={{padding:'8px 10px', fontFamily:'monospace', fontSize:11, fontWeight:600}}>{log.telefon || '-'}</td>
                          <td style={{padding:'8px 10px'}}>
                            {log.dosya_no ? <Badge text={log.dosya_no} color={C.accent}/> : '-'}
                          </td>
                          <td style={{padding:'8px 10px'}}>
                            <Badge text={log.durum === 'gonderildi' ? 'GÖNDERİLDİ' : log.durum === 'hata' ? 'HATA' : (log.durum || '').toUpperCase()} color={durumRenk(log.durum)}/>
                          </td>
                          <td style={{padding:'8px 10px', fontSize:10, color:C.textSec, maxWidth:300, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap'}}>
                            {log.sonuc_mesaj || log.mesaj || '-'}
                          </td>
                          <td style={{padding:'8px 10px', fontSize:10, color:C.textMuted}}>{log.kullanici_adi || '-'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {logTotal > 15 && (
                    <div style={{padding:12, display:'flex', justifyContent:'center', gap:6}}>
                      {Array.from({length: Math.ceil(logTotal / 15)}, (_, i) => i + 1).slice(0, 10).map(p => (
                        <div key={p} onClick={() => smsLoglariYukle(p)}
                          style={{width:28, height:28, borderRadius:6, display:'flex', alignItems:'center', justifyContent:'center',
                            fontSize:10, fontWeight: p===logPage ? 800 : 500, cursor:'pointer',
                            background: p===logPage ? `${C.accent}22` : 'transparent',
                            color: p===logPage ? C.accent : C.textMuted,
                            border:`1px solid ${p===logPage ? C.accent+'33' : 'transparent'}`}}>
                          {p}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <div style={{padding:40, textAlign:'center'}}>
                  <LIcon name="MessageSquare" size={36} color={C.textMuted} style={{opacity:0.2}}/>
                  <div style={{fontSize:13, fontWeight:600, color:C.textMuted, marginTop:12}}>HENÜZ SMS GÖNDERİMİ YAPILMADI</div>
                  <div style={{fontSize:10, color:C.textMuted, marginTop:4}}>DOSYA DURUMU DEĞİŞTİĞİNDE SMS GÖNDERİMLERİ BURADA GÖRÜNECEK</div>
                </div>
              )
            )}
          </div>
        </div>
      )}

      {/* ═══ SMS AYARLARI PANELİ ═══ */}
      {smsAltTab === 'ayarlar' && (
        <div style={{display:'flex', flexDirection:'column', gap:16}}>
      {/* BİLGİ BANNER */}
      <div style={{padding:16, background:`${C.accent}11`, borderRadius:12, border:`1px solid ${C.accent}33`, display:'flex', alignItems:'center', gap:12}}>
        <div style={{width:44, height:44, borderRadius:12, background:`${C.accent}22`, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0}}>
          <LIcon name="MessageSquare" size={22} color={C.accent}/>
        </div>
        <div>
          <div style={{fontSize:14, fontWeight:800, color:C.accent}}>OTOMATİK SMS BİLDİRİM SİSTEMİ</div>
          <div style={{fontSize:11, color:C.textSec, marginTop:2}}>
            DOSYA DURUMU HER DEĞİŞTİĞİNDE MAĞDURA OTOMATİK SMS GÖNDERİLİR. EVRAK YÜKLÜYSE PDF LİNKİ DE SMS İÇİNDE YER ALIR.
          </div>
        </div>
      </div>

      {/* MESAJ */}
      {mesaj && (
        <div style={{padding:12, background: mesaj.type==='success' ? `${C.success}18` : `${C.danger}18`,
          borderRadius:8, border:`1px solid ${mesaj.type==='success' ? C.success+'33' : C.danger+'33'}`,
          color: mesaj.type==='success' ? C.success : C.danger, fontSize:12, fontWeight:600,
          display:'flex', alignItems:'center', gap:8}}>
          <LIcon name={mesaj.type==='success' ? 'CheckCircle' : 'AlertCircle'} size={16}
            color={mesaj.type==='success' ? C.success : C.danger}/>
          {mesaj.text}
          <span style={{marginLeft:'auto', cursor:'pointer', opacity:0.6}} onClick={() => setMesaj(null)}>✕</span>
        </div>
      )}

      <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:16}}>
        {/* SOL: AYARLAR */}
        <div style={S.card}>
          <div style={{...S.cardHead}}>
            <LIcon name="Settings" size={16} color={C.accent}/>
            <span style={{fontSize:13, fontWeight:700}}>NETGSM SMS AYARLARI</span>
          </div>
          <div style={{padding:20, display:'flex', flexDirection:'column', gap:14}}>
            {/* AKTİF/PASİF */}
            <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', padding:12,
              background: ayarlar.sms_aktif==='1' ? `${C.success}11` : `${C.danger}08`,
              borderRadius:10, border:`1px solid ${ayarlar.sms_aktif==='1' ? C.success+'33' : C.danger+'22'}`}}>
              <div>
                <div style={{fontSize:12, fontWeight:700}}>SMS BİLDİRİM</div>
                <div style={{fontSize:10, color:C.textMuted, marginTop:2}}>
                  {ayarlar.sms_aktif==='1' ? 'DURUM DEĞİŞİKLİKLERİNDE SMS GÖNDERİLİYOR' : 'SMS GÖNDERİMİ KAPALI'}
                </div>
              </div>
              <div onClick={() => u('sms_aktif', ayarlar.sms_aktif==='1' ? '0' : '1')}
                style={{width:52, height:28, borderRadius:14, cursor:'pointer', transition:'all .3s',
                  background: ayarlar.sms_aktif==='1' ? C.success : C.borderLight, position:'relative'}}>
                <div style={{width:22, height:22, borderRadius:11, background:'#fff', position:'absolute', top:3,
                  left: ayarlar.sms_aktif==='1' ? 27 : 3, transition:'all .3s',
                  boxShadow:'0 1px 3px rgba(0,0,0,0.3)'}}/>
              </div>
            </div>

            <FormGroup label="NETGSM KULLANICI ADI (USERCODE)">
              <input value={ayarlar.sms_kullanici||''} onChange={e => u('sms_kullanici', e.target.value)}
                placeholder="5550984254" style={{...S.input, fontSize:12}}/>
              <div style={{fontSize:9, color:C.textMuted, marginTop:4}}>
                NETGSM PANELİNDEKİ "KULLANICI ADI" (TELEFON NUMARANIZ). ABONELİK BİLGİLERİ SAYFASINDAN KONTROL EDİN.
              </div>
            </FormGroup>

            <FormGroup label="NETGSM ŞİFRE">
              <input type="password" value={ayarlar.sms_sifre||''} onChange={e => u('sms_sifre', e.target.value)}
                placeholder="••••••••" style={{...S.input, fontSize:12}}/>
              <div style={{fontSize:9, color:C.textMuted, marginTop:4}}>
                NETGSM PANELİNE GİRİŞ ŞİFRENİZ
              </div>
            </FormGroup>

            <FormGroup label="SMS BAŞLIĞI (SENDER / MSGHEADER)">
              <input value={ayarlar.sms_baslik||''} onChange={e => u('sms_baslik', e.target.value)}
                placeholder="MR HASAR" maxLength={11} style={{...S.input, fontSize:12}}/>
              <div style={{fontSize:9, color:C.textMuted, marginTop:4}}>
                NETGSM PANELİNDEN ONAYLANMIŞ GÖNDERİCİ ADI. "VARSAYILAN GÖNDERİCİ ADI" ALANIDIR (MAX 11 KARAKTER).
              </div>
            </FormGroup>

            <FormGroup label="SİTE URL (EVRAK LİNKLERİ İÇİN)">
              <input value={ayarlar.site_url||''} onChange={e => u('site_url', e.target.value)}
                placeholder="https://sistem.mrhasardanismanlik.com" style={{...S.input, fontSize:12}}/>
              <div style={{fontSize:9, color:C.textMuted, marginTop:4}}>
                EVRAK İNDİRME LİNKLERİ BU URL ÜZERİNDEN OLUŞTURULUR
              </div>
            </FormGroup>

            <button onClick={kaydet} disabled={saving}
              style={{...S.btn, ...S.btnS, justifyContent:'center', padding:14, fontSize:13, fontWeight:700}}>
              <LIcon name="Save" size={16} color="#fff"/>
              {saving ? 'KAYDEDİLİYOR...' : 'SMS AYARLARINI KAYDET'}
            </button>
          </div>
        </div>

        {/* SAĞ: TEST + BİLGİ */}
        <div style={{display:'flex', flexDirection:'column', gap:16}}>
          {/* TEST SMS */}
          <div style={S.card}>
            <div style={{...S.cardHead}}>
              <LIcon name="Send" size={16} color={C.warning}/>
              <span style={{fontSize:13, fontWeight:700}}>SMS TEST GÖNDERİMİ</span>
            </div>
            <div style={{padding:20}}>
              <FormGroup label="TEST TELEFON NUMARASI">
                <div style={{display:'flex', gap:8}}>
                  <input value={testTel} onChange={e => setTestTel(e.target.value)}
                    placeholder="05XX XXX XX XX" style={{...S.input, fontSize:12, flex:1}}/>
                  <button onClick={testGonder} disabled={testLoading}
                    style={{...S.btn, ...S.btnW, fontSize:11, padding:'8px 16px', whiteSpace:'nowrap'}}>
                    <LIcon name="Send" size={13} color="#000"/>
                    {testLoading ? 'GÖNDERİLİYOR...' : 'TEST GÖNDER'}
                  </button>
                </div>
              </FormGroup>
            </div>
          </div>

          {/* NASIL ÇALIŞIR */}
          <div style={S.card}>
            <div style={{...S.cardHead, background:`${C.cyan}06`}}>
              <LIcon name="HelpCircle" size={16} color={C.cyan}/>
              <span style={{fontSize:13, fontWeight:700}}>NASIL ÇALIŞIR?</span>
            </div>
            <div style={{padding:20, fontSize:11, color:C.textSec, lineHeight:1.8}}>
              <div style={{display:'flex', gap:8, marginBottom:10}}>
                <div style={{width:24, height:24, borderRadius:12, background:`${C.accent}22`, display:'flex',
                  alignItems:'center', justifyContent:'center', flexShrink:0, fontSize:11, fontWeight:800, color:C.accent}}>1</div>
                <div>DOSYA DETAY SAYFASINDA DURUM (AŞAMA) DEĞİŞTİRİLİR</div>
              </div>
              <div style={{display:'flex', gap:8, marginBottom:10}}>
                <div style={{width:24, height:24, borderRadius:12, background:`${C.success}22`, display:'flex',
                  alignItems:'center', justifyContent:'center', flexShrink:0, fontSize:11, fontWeight:800, color:C.success}}>2</div>
                <div>SİSTEM OTOMATİK OLARAK MAĞDURUN TELEFONUNA SMS GÖNDER</div>
              </div>
              <div style={{display:'flex', gap:8, marginBottom:10}}>
                <div style={{width:24, height:24, borderRadius:12, background:`${C.warning}22`, display:'flex',
                  alignItems:'center', justifyContent:'center', flexShrink:0, fontSize:11, fontWeight:800, color:C.warning}}>3</div>
                <div>SMS İÇERİĞİ: YENİ DURUM BİLGİSİ + EVRAK PDF LİNKİ (VARSA)</div>
              </div>
              <div style={{display:'flex', gap:8}}>
                <div style={{width:24, height:24, borderRadius:12, background:`${C.purple}22`, display:'flex',
                  alignItems:'center', justifyContent:'center', flexShrink:0, fontSize:11, fontWeight:800, color:C.purple}}>4</div>
                <div>TÜM SMS GÖNDERİMLERİ LOGLANIR VE AŞAĞIDAKİ TABLODA GÖRÜNTÜLENİR</div>
              </div>
            </div>
          </div>

          {/* İSTATİSTİK */}
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:10}}>
            <div style={{...S.stat, textAlign:'center'}}>
              <div style={{fontSize:20, fontWeight:800, color:C.success}}>{loglar.filter(l=>l.durum==='gonderildi').length}</div>
              <div style={{fontSize:9, color:C.textMuted, marginTop:2}}>BAŞARILI</div>
            </div>
            <div style={{...S.stat, textAlign:'center'}}>
              <div style={{fontSize:20, fontWeight:800, color:C.danger}}>{loglar.filter(l=>l.durum==='hata').length}</div>
              <div style={{fontSize:9, color:C.textMuted, marginTop:2}}>BAŞARISIZ</div>
            </div>
            <div style={{...S.stat, textAlign:'center'}}>
              <div style={{fontSize:20, fontWeight:800, color:C.accent}}>{logTotal}</div>
              <div style={{fontSize:9, color:C.textMuted, marginTop:2}}>TOPLAM</div>
            </div>
          </div>
        </div>
      </div>

        </div>
      )}
    </div>
  );
};

/* ════════════════════════════════════════════════════════════════
   TAB 5 - NETSANTRAL AYARLARI
   ════════════════════════════════════════════════════════════════ */
/* ═══ NETSANTRAL ÇAĞRI GEÇMİŞİ BİLEŞENİ ═══ */
const NetsantralCagriGecmisi = () => {
  const {C, S, LIcon, Badge, Loading, StatCard, api} = MR;
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({toplam: 0, gelen: 0, giden: 0, bugun: 0, toplam_sure: 0});
  const [sayfa, setSayfa] = useState(1);
  const [toplamSayfa, setToplamSayfa] = useState(1);
  const [toplamKayit, setToplamKayit] = useState(0);
  const [yonF, setYonF] = useState('');
  const [search, setSearch] = useState('');
  const [tarihBas, setTarihBas] = useState('');
  const [tarihBit, setTarihBit] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const p = {page: sayfa, limit: 30};
      if (yonF) p.yon = yonF;
      if (search) p.q = search;
      if (tarihBas) p.tarih_baslangic = tarihBas;
      if (tarihBit) p.tarih_bitis = tarihBit;
      const r = await api.netsantralAramaList(p);
      if (r?.success) {
        const items = r.data?.items || [];
        setData(items);
        if (r.data?.stats) setStats(r.data.stats);
        if (r.data?.pagination) {
          setToplamSayfa(r.data.pagination.totalPages || 1);
          setToplamKayit(r.data.pagination.total || 0);
        }
        if (r.data?.debug_error) {
          console.warn('[NETSANTRAL ÇAĞRI GEÇMİŞİ] SQL HATASI:', r.data.debug_error);
        }
      } else {
        console.error('[NETSANTRAL ÇAĞRI GEÇMİŞİ] API HATASI:', r?.error);
      }
    } catch (err) {
      console.error('[NETSANTRAL ÇAĞRI GEÇMİŞİ] YÜKLEME HATASI:', err);
    }
    setLoading(false);
  }, [sayfa, yonF, search, tarihBas, tarihBit]);

  useEffect(() => { load(); }, []);
  useEffect(() => {
    if (sayfa === 1 && !yonF && !search && !tarihBas && !tarihBit) return; // İLK YÜKLEME ZATEN YAPILDI
    const t = setTimeout(load, 400);
    return () => clearTimeout(t);
  }, [search, yonF, tarihBas, tarihBit, sayfa]);

  const fmtSure = (s) => {
    if (!s || s <= 0) return '-';
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return m > 0 ? `${m}DK ${sec}SN` : `${sec}SN`;
  };

  const durumRenk = (d) => {
    if (!d) return C.textMuted;
    const dl = d.toLowerCase();
    if (dl === 'gorusmede' || dl === 'baglandi') return C.success;
    if (dl === 'araniyor' || dl === 'calıyor') return C.warning;
    if (dl === 'sonlandi') return C.accent;
    if (dl === 'basarisiz') return C.danger;
    return C.textMuted;
  };

  const durumLabel = (d) => {
    if (!d) return 'BİLİNMİYOR';
    const dl = d.toLowerCase();
    if (dl === 'gorusmede' || dl === 'baglandi') return 'GÖRÜŞME';
    if (dl === 'araniyor' || dl === 'calıyor') return 'ARANIYOR';
    if (dl === 'sonlandi') return 'SONLANDI';
    if (dl === 'basarisiz') return 'BAŞARISIZ';
    return d.toUpperCase();
  };

  const thSt = {padding:'8px 10px', textAlign:'left', color:C.textMuted, fontWeight:600, fontSize:10, borderBottom:`2px solid ${C.border}`, whiteSpace:'nowrap', position:'sticky', top:0, background:C.bgCard, zIndex:1};
  const tdSt = {padding:'8px 10px', fontSize:11, borderBottom:`1px solid ${C.border}22`, whiteSpace:'nowrap'};

  return (
    <div style={S.card}>
      <div style={{...S.cardHead, justifyContent:'space-between'}}>
        <div style={{display:'flex', alignItems:'center', gap:10}}>
          <LIcon name="PhoneCall" size={14} color={C.accent}/>
          <span style={{fontSize:13, fontWeight:700}}>ÇAĞRI GEÇMİŞİ</span>
          <Badge text={stats.toplam + ' TOPLAM'} color={C.accent}/>
        </div>
        <div style={{display:'flex', gap:6, alignItems:'center'}}>
          <input placeholder="NUMARA VEYA İSİM ARA..." value={search} onChange={e => {setSearch(e.target.value); setSayfa(1);}}
            style={{...S.input, width:180, fontSize:10, padding:'6px 10px'}}/>
          <button onClick={load} style={{...S.btn, padding:'6px 10px', background:`${C.accent}22`, border:'none'}}>
            <LIcon name="RefreshCw" size={14} color={C.accent}/>
          </button>
        </div>
      </div>

      {/* İSTATİSTİK BANTLARI */}
      <div style={{display:'flex', gap:0, borderBottom:`1px solid ${C.border}`}}>
        {[
          {label:'BUGÜN', value:stats.bugun, c:C.accent, icon:'Calendar'},
          {label:'GELEN', value:stats.gelen, c:C.success, icon:'PhoneIncoming'},
          {label:'GİDEN', value:stats.giden, c:C.purple, icon:'PhoneOutgoing'},
          {label:'TOPLAM SÜRE', value: fmtSure(stats.toplam_sure), c:C.cyan, icon:'Clock'}
        ].map((item,i) => (
          <div key={i} style={{
            flex:1, padding:'12px 16px', display:'flex', alignItems:'center', gap:10,
            borderRight: i < 3 ? `1px solid ${C.border}` : 'none',
            background:`${item.c}05`
          }}>
            <div style={{
              width:32, height:32, borderRadius:8, background:`${item.c}15`,
              display:'flex', alignItems:'center', justifyContent:'center'
            }}>
              <LIcon name={item.icon} size={14} color={item.c}/>
            </div>
            <div>
              <div style={{fontSize:16, fontWeight:800, color:item.c}}>{item.value}</div>
              <div style={{fontSize:9, color:C.textMuted}}>{item.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* FİLTRE */}
      <div style={{padding:'10px 16px', borderBottom:`1px solid ${C.border}`, display:'flex', gap:6, alignItems:'center', flexWrap:'wrap'}}>
        <span style={{fontSize:9, fontWeight:700, color:C.textMuted, marginRight:6}}>YÖN:</span>
        {[
          {val:'', label:'HEPSİ', c:C.accent},
          {val:'gelen', label:'GELEN', c:C.success},
          {val:'giden', label:'GİDEN', c:C.purple}
        ].map(d => (
          <span key={d.val} onClick={() => {setYonF(d.val); setSayfa(1);}}
            style={{
              padding:'5px 12px', borderRadius:20, fontSize:10, fontWeight: yonF === d.val ? 700 : 500,
              cursor:'pointer',
              background: yonF === d.val ? `${d.c}18` : 'transparent',
              color: yonF === d.val ? d.c : C.textSec,
              border:`1px solid ${yonF === d.val ? d.c + '44' : C.border}`
            }}>
            {d.label}
          </span>
        ))}
        <div style={{marginLeft:'auto', display:'flex', gap:6, alignItems:'center'}}>
          <span style={{fontSize:9, color:C.textMuted}}>TARİH:</span>
          <input type="date" value={tarihBas} onChange={e => {setTarihBas(e.target.value); setSayfa(1);}}
            style={{...S.input, width:130, fontSize:10, padding:'5px 8px'}}/>
          <span style={{fontSize:9, color:C.textMuted}}>-</span>
          <input type="date" value={tarihBit} onChange={e => {setTarihBit(e.target.value); setSayfa(1);}}
            style={{...S.input, width:130, fontSize:10, padding:'5px 8px'}}/>
        </div>
      </div>

      {/* TABLO */}
      {loading ? <Loading/> : data.length === 0 ? (
        <div style={{padding:40, textAlign:'center'}}>
          <LIcon name="PhoneOff" size={32} color={C.textMuted} style={{opacity:.3, marginBottom:8}}/>
          <div style={{fontSize:12, color:C.textMuted}}>ÇAĞRI KAYDI BULUNAMADI</div>
        </div>
      ) : (
        <div style={{overflowX:'auto', maxHeight:'calc(100vh - 700px)'}}>
          <table style={{width:'100%', borderCollapse:'collapse', fontSize:11, minWidth:900}}>
            <thead>
              <tr style={{background:C.bgHover}}>
                <th style={thSt}>NO</th>
                <th style={thSt}>YÖN</th>
                <th style={thSt}>ARAYAN</th>
                <th style={thSt}>ARANAN</th>
                <th style={thSt}>ARAYAN ADI</th>
                <th style={thSt}>TARİH</th>
                <th style={thSt}>DURUM</th>
                <th style={thSt}>SÜRE</th>
                <th style={thSt}>CRM</th>
                <th style={thSt}>NOTLAR</th>
              </tr>
            </thead>
            <tbody>
              {data.map((item, i) => (
                <tr key={item.id} style={{
                  background: i % 2 === 1 ? `${C.bgHover}66` : 'transparent'
                }}
                  onMouseEnter={e => e.currentTarget.style.background = `${C.accent}08`}
                  onMouseLeave={e => e.currentTarget.style.background = i % 2 === 1 ? `${C.bgHover}66` : 'transparent'}
                >
                  <td style={{...tdSt, fontWeight:700, color:C.accent, fontSize:10}}>{item.id}</td>
                  <td style={tdSt}>
                    <span style={{
                      padding:'3px 8px', borderRadius:6, fontSize:9, fontWeight:700,
                      background: item.yon === 'gelen' ? `${C.success}18` : `${C.purple}18`,
                      color: item.yon === 'gelen' ? C.success : C.purple,
                      display:'inline-flex', alignItems:'center', gap:4
                    }}>
                      <LIcon name={item.yon === 'gelen' ? 'PhoneIncoming' : 'PhoneOutgoing'} size={10}
                        color={item.yon === 'gelen' ? C.success : C.purple}/>
                      {item.yon === 'gelen' ? 'GELEN' : 'GİDEN'}
                    </span>
                  </td>
                  <td style={{...tdSt, fontFamily:'monospace', fontWeight:600}}>{item.arayan || '-'}</td>
                  <td style={{...tdSt, fontFamily:'monospace', fontWeight:600}}>{item.aranan || '-'}</td>
                  <td style={{...tdSt, fontWeight:600}}>{item.arayan_adi || item.crm_ad_soyad || '-'}</td>
                  <td style={{...tdSt, color:C.textMuted, fontSize:10}}>
                    {item.arama_tarihi ? new Date(item.arama_tarihi).toLocaleString('tr-TR', {day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit'}) : '-'}
                  </td>
                  <td style={tdSt}>
                    <span style={{
                      padding:'3px 8px', borderRadius:6, fontSize:9, fontWeight:700,
                      background: `${durumRenk(item.durum)}18`,
                      color: durumRenk(item.durum)
                    }}>
                      {durumLabel(item.durum)}
                    </span>
                  </td>
                  <td style={{...tdSt, fontWeight:700, color: item.sure > 0 ? C.text : C.textMuted}}>
                    {fmtSure(item.sure)}
                  </td>
                  <td style={tdSt}>
                    {item.crm_id ? (
                      <span style={{
                        padding:'2px 6px', borderRadius:4, fontSize:9, fontWeight:600,
                        background:`${C.accent}18`, color:C.accent, cursor:'pointer'
                      }} title={'CRM #' + item.crm_id}>
                        <LIcon name="User" size={10} color={C.accent}/> #{item.crm_id}
                      </span>
                    ) : '-'}
                  </td>
                  <td style={{...tdSt, maxWidth:200, overflow:'hidden', textOverflow:'ellipsis', color:C.textMuted, fontSize:10}}>
                    {item.notlar || '-'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* SAYFALAMA */}
      {data.length > 0 && (
        <div style={{padding:'12px 16px', borderTop:`1px solid ${C.border}`, display:'flex', justifyContent:'space-between', alignItems:'center'}}>
          <span style={{fontSize:10, color:C.textMuted}}>
            {toplamKayit} KAYIT
          </span>
          <div style={{display:'flex', alignItems:'center', gap:4}}>
            <button disabled={sayfa <= 1} onClick={() => setSayfa(s => Math.max(1, s - 1))}
              style={{...S.btn, ...S.btnG, fontSize:10, padding:'4px 8px', opacity: sayfa <= 1 ? 0.4 : 1}}>&lsaquo;</button>
            {Array.from({length: Math.min(5, toplamSayfa)}, (_, i) => {
              let p = sayfa - 2 + i;
              if (p < 1) p = i + 1;
              if (p > toplamSayfa) p = toplamSayfa - (4 - i);
              if (p < 1) p = i + 1;
              return p;
            }).filter((v, i, a) => v >= 1 && v <= toplamSayfa && a.indexOf(v) === i).map(p => (
              <button key={p} onClick={() => setSayfa(p)}
                style={{
                  width:28, height:28, borderRadius:6, border:`1px solid ${p === sayfa ? C.accent : C.borderLight}`,
                  background: p === sayfa ? C.accent : 'transparent', color: p === sayfa ? '#fff' : C.textSec,
                  cursor:'pointer', fontSize:11, fontWeight:600, display:'flex', alignItems:'center', justifyContent:'center'
                }}>{p}</button>
            ))}
            <button disabled={sayfa >= toplamSayfa} onClick={() => setSayfa(s => Math.min(toplamSayfa, s + 1))}
              style={{...S.btn, ...S.btnG, fontSize:10, padding:'4px 8px', opacity: sayfa >= toplamSayfa ? 0.4 : 1}}>&rsaquo;</button>
            <span style={{fontSize:9, color:C.textMuted, marginLeft:6}}>SAYFA {sayfa} / {toplamSayfa}</span>
          </div>
        </div>
      )}
    </div>
  );
};

const NetsantralTab = () => {
  const {C, S, LIcon, Badge, Loading, StatCard, api} = MR;
  const [ayarlar, setAyarlar] = useState({
    netsantral_santral_no: '',
    netsantral_kullanici: '',
    netsantral_sifre: '',
    netsantral_dahili: '',
    netsantral_aktif: '0',
    netsantral_yonlendirme_modu: 'dynamic'
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [mesaj, setMesaj] = useState({type: '', text: ''});
  const [testResult, setTestResult] = useState(null);
  const [queueStats, setQueueStats] = useState(null);
  const [webhookTest, setWebhookTest] = useState(null);
  const [webhookTesting, setWebhookTesting] = useState(false);
  const [webhookLog, setWebhookLog] = useState(null);
  const [diagnoseResult, setDiagnoseResult] = useState(null);
  const [diagnosing, setDiagnosing] = useState(false);

  /* AYARLAR YÜKLE */
  useEffect(() => {
    (async () => {
      setLoading(true);
      const r = await api.ayarlarList();
      if (r?.success) {
        const data = r.data || {};
        setAyarlar(prev => ({
          ...prev,
          netsantral_santral_no: data.netsantral_santral_no || '',
          netsantral_kullanici: data.netsantral_kullanici || '',
          netsantral_sifre: data.netsantral_sifre || '',
          netsantral_dahili: data.netsantral_dahili || '',
          netsantral_aktif: data.netsantral_aktif || '0',
          netsantral_yonlendirme_modu: data.netsantral_yonlendirme_modu || 'dynamic'
        }));
      }
      setLoading(false);
    })();
  }, []);

  const up = (k, v) => setAyarlar(p => ({...p, [k]: v}));

  /* AYARLARI KAYDET */
  const kaydet = async () => {
    setSaving(true);
    setMesaj({type: '', text: ''});
    const r = await api.ayarlarGuncelle(ayarlar);
    if (r?.success) {
      setMesaj({type: 'success', text: 'NETSANTRAL AYARLARI BAŞARIYLA KAYDEDİLDİ'});
      /* GLOBAL DEĞİŞKENLERİ ANINDA GÜNCELLE - FLOATING PANEL HEMEN KULLLANSIN */
      MR._netsantralDahili = ayarlar.netsantral_dahili || '';
      MR._netsantralAktif = ayarlar.netsantral_aktif === '1';
      MR._netsantralSantralNo = ayarlar.netsantral_santral_no || '';
      /* DİĞER BİLEŞENLERE AYARLARIN DEĞİŞTİĞİNİ BİLDİR */
      window.dispatchEvent(new CustomEvent('mr-netsantral-ayar-degisti', {
        detail: {
          dahili: MR._netsantralDahili,
          aktif: MR._netsantralAktif,
          santralNo: MR._netsantralSantralNo
        }
      }));
      console.log('[NETSANTRAL] AYARLAR GÜNCELLENDİ - DAHİLİ:', MR._netsantralDahili, '| AKTİF:', MR._netsantralAktif);
    } else {
      setMesaj({type: 'error', text: r?.error || 'AYARLAR KAYDEDİLİRKEN HATA OLUŞTU'});
    }
    setSaving(false);
    setTimeout(() => setMesaj({type: '', text: ''}), 4000);
  };

  /* BAĞLANTI TESTİ */
  const testBaglanti = async () => {
    setTesting(true);
    setTestResult(null);
    setMesaj({type: '', text: ''});

    // Önce ayarları kaydet
    await api.ayarlarGuncelle(ayarlar);

    // GLOBAL DEĞİŞKENLERİ GÜNCELLE (KAYIT SONRASI HEMEN AKTİF OLSUN)
    MR._netsantralDahili = ayarlar.netsantral_dahili || '';
    MR._netsantralAktif = ayarlar.netsantral_aktif === '1';
    MR._netsantralSantralNo = ayarlar.netsantral_santral_no || '';

    // Sonra test et
    const r = await api.netsantralTest();
    if (r?.success && r.data?.success_api) {
      const resp = r.data?.response || {};
      setTestResult({success: true, data: resp, debug: r.data?.debug});
      // Alternatif format başarılıysa bildir
      if (resp.oneri_santral_no) {
        setMesaj({type: 'success', text: 'BAĞLANTI BAŞARILI! ÖNERİ: SANTRAL NO\'YU "' + resp.oneri_santral_no + '" OLARAK GÜNCELLEYİN.'});
        up('netsantral_santral_no', resp.oneri_santral_no);
      } else {
        setMesaj({type: 'success', text: 'NETSANTRAL BAĞLANTISI BAŞARILI!'});
      }

      // Kuyruk bilgisini kaydet
      if (resp) {
        setQueueStats(resp);
      }
    } else {
      // NETGSM HATA KODU KONTROLÜ
      const resp = r?.data?.response || {};
      const debug = r?.data?.debug || {};
      const hataMesaj = resp.hata_mesaj || resp.raw_response || r?.error || 'BAĞLANTI HATASI';
      const hataKodu = resp.hata_kodu || '';
      const cozumOnerisi = resp.cozum_onerisi || '';
      const denemeSayisi = resp.deneme_sayisi || 0;
      const formatOnerisi = resp.format_onerisi || '';
      const hatKullaniciUyari = resp.hat_kullanici_uyari || '';
      const oneriSantralNo = resp.oneri_santral_no || '';
      const oneriMesaj = resp.oneri_mesaj || '';
      const errText = hataKodu ? `HATA KODU: ${hataKodu} - ${hataMesaj}` : hataMesaj;
      if (denemeSayisi > 1) {
        debug._denemeSayisi = denemeSayisi + ' FARKLI AYARLA DENENDİ';
      }
      // Eğer alternatif format önerisi varsa, çözüm olarak göster
      let fullCozum = cozumOnerisi;
      if (oneriMesaj) fullCozum = oneriMesaj;
      else if (formatOnerisi) fullCozum = (fullCozum ? fullCozum + '. ' : '') + formatOnerisi;
      if (hatKullaniciUyari) fullCozum = (fullCozum ? fullCozum + '. ' : '') + hatKullaniciUyari;
      setTestResult({success: false, error: errText, debug: debug, httpCode: r?.data?.http_code, cozumOnerisi: fullCozum, oneriSantralNo: oneriSantralNo});
      setMesaj({type: 'error', text: 'BAĞLANTI HATASI: ' + errText});
    }
    setTesting(false);
    setTimeout(() => setMesaj({type: '', text: ''}), 8000);
  };

  /* WEBHOOK DURUM TESTİ */
  const testWebhook = async (mode) => {
    setWebhookTesting(true);
    setWebhookTest(null);
    try {
      const r = await api.req('/netsantral/test-webhook.php?mode=' + (mode || 'status'));
      setWebhookTest(r?.data || r);
    } catch(e) {
      setWebhookTest({hata: 'BAĞLANTI HATASI'});
    }
    setWebhookTesting(false);
  };

  /* ADIM ADIM TANILAMA */
  const runDiagnose = async () => {
    setDiagnosing(true);
    setDiagnoseResult(null);
    try {
      const r = await api.req('/netsantral/test-webhook.php?mode=diagnose');
      setDiagnoseResult(r?.data || r);
    } catch(e) {
      setDiagnoseResult({hata: 'TANILAMA BAŞLATILAMADI'});
    }
    setDiagnosing(false);
  };

  /* WEBHOOK LOG GÖSTERİM */
  const logGoster = async () => {
    try {
      const r = await api.req('/netsantral/test-webhook.php?mode=log');
      setWebhookLog(r?.data || null);
    } catch(e) {
      setWebhookLog({hata: 'LOG OKUNAMIYOR'});
    }
  };

  if (loading) return <Loading/>;

  const webhookUrl = window.location.origin + '/api/v1/netsantral/webhook.php';

  return (
    <div>
      {/* MESAJ */}
      {mesaj.text && (
        <div style={{
          padding: '12px 16px', borderRadius: 8, marginBottom: 16, fontSize: 12, fontWeight: 600,
          background: mesaj.type === 'success' ? `${C.success}22` : `${C.danger}22`,
          border: `1px solid ${mesaj.type === 'success' ? C.success + '44' : C.danger + '44'}`,
          color: mesaj.type === 'success' ? C.success : C.danger,
          display: 'flex', alignItems: 'center', gap: 8
        }}>
          <LIcon name={mesaj.type === 'success' ? 'CheckCircle' : 'AlertCircle'} size={16}
            color={mesaj.type === 'success' ? C.success : C.danger}/>
          {mesaj.text}
        </div>
      )}

      <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16}}>
        {/* BAĞLANTI AYARLARI */}
        <div style={S.card}>
          <div style={{...S.cardHead, padding: '12px 16px'}}>
            <LIcon name="Phone" size={14} color={C.accent}/>
            <span style={{fontSize: 12, fontWeight: 700}}>NETSANTRAL BAĞLANTI AYARLARI</span>
          </div>
          <div style={{padding: 16}}>
            <div style={{display: 'grid', gap: 16}}>
              {/* AKTİF/PASİF */}
              <div style={{
                padding: '12px 16px', borderRadius: 10,
                background: ayarlar.netsantral_aktif === '1' ? `${C.success}15` : `${C.textMuted}10`,
                border: `1px solid ${ayarlar.netsantral_aktif === '1' ? C.success + '33' : C.border}`,
                display: 'flex', alignItems: 'center', justifyContent: 'space-between'
              }}>
                <div style={{display: 'flex', alignItems: 'center', gap: 10}}>
                  <div style={{
                    width: 12, height: 12, borderRadius: '50%',
                    background: ayarlar.netsantral_aktif === '1' ? C.success : C.textMuted,
                    boxShadow: ayarlar.netsantral_aktif === '1' ? `0 0 8px ${C.success}` : 'none'
                  }}/>
                  <span style={{fontSize: 12, fontWeight: 700,
                    color: ayarlar.netsantral_aktif === '1' ? C.success : C.textMuted
                  }}>
                    NETSANTRAL {ayarlar.netsantral_aktif === '1' ? 'AKTİF' : 'PASİF'}
                  </span>
                </div>
                <div onClick={() => up('netsantral_aktif', ayarlar.netsantral_aktif === '1' ? '0' : '1')} style={{
                  width: 44, height: 24, borderRadius: 12, cursor: 'pointer',
                  background: ayarlar.netsantral_aktif === '1' ? C.success : C.borderLight,
                  position: 'relative', transition: 'all .3s'
                }}>
                  <div style={{
                    width: 20, height: 20, borderRadius: '50%',
                    background: '#fff', position: 'absolute', top: 2,
                    left: ayarlar.netsantral_aktif === '1' ? 22 : 2,
                    transition: 'all .3s', boxShadow: '0 1px 4px rgba(0,0,0,.3)'
                  }}/>
                </div>
              </div>

              {/* SANTRAL NO */}
              <div>
                <label style={S.label}>SANTRAL NUMARASI *</label>
                <input style={S.input} value={ayarlar.netsantral_santral_no}
                  onChange={e => up('netsantral_santral_no', e.target.value)}
                  placeholder="08503625026502"/>
                <div style={{fontSize: 9, color: C.textMuted, marginTop: 4}}>
                  NETGSM NETSANTRAL HAT NUMARANIZ. FORMAT: <strong>0850 + ABONE NO</strong> (ÖRN: 08503625026502).
                  NETGSM PANELİNDE ABONE BİLGİLERİ SAYFASINDAN "ABONE NO"YU ALIN VE BAŞINA 0850 EKLEYİN.
                </div>
              </div>

              {/* KULLANICI ADI */}
              <div>
                <label style={S.label}>KULLANICI ADI *</label>
                <input style={S.input} value={ayarlar.netsantral_kullanici}
                  onChange={e => up('netsantral_kullanici', e.target.value)}
                  placeholder="5550984254"/>
                <div style={{fontSize: 9, color: C.textMuted, marginTop: 4}}>
                  NETGSM PANELİNDEKİ "KULLANICI ADI" (TELEFON NUMARANIZ). "HAT KULLANICI BİLGİSİ" SEKMESİNDEN DE KONTROL EDEBİLİRSİNİZ.
                </div>
              </div>

              {/* ŞİFRE */}
              <div>
                <label style={S.label}>ŞİFRE *</label>
                <input style={S.input} type="password" value={ayarlar.netsantral_sifre}
                  onChange={e => up('netsantral_sifre', e.target.value)}
                  placeholder="NETGSM PANEL ŞİFRENİZ"/>
                <div style={{fontSize: 9, color: C.textMuted, marginTop: 4}}>
                  NETGSM PANELİNE GİRİŞ ŞİFRENİZ VEYA "HAT KULLANICI BİLGİSİ"NDEKİ ALT KULLANICI ŞİFRESİ
                </div>
              </div>

              {/* DAHİLİ */}
              <div>
                <label style={S.label}>VARSAYILAN DAHİLİ *</label>
                <input style={S.input} value={ayarlar.netsantral_dahili}
                  onChange={e => up('netsantral_dahili', e.target.value)}
                  placeholder="100"/>
                <div style={{fontSize: 9, color: C.textMuted, marginTop: 4}}>
                  NETSANTRAL DAHİLİ NUMARANIZ (ÖRN: 100, 101, 102). GELEN ÇAĞRILAR BU DAHİLİYE YÖNLENDİRİLİR.
                  NETGSM NETSANTRAL PANELİNDEN DAHİLİ TANIMLAYIN.
                </div>
              </div>

              {/* YÖNLENDİRME MODU */}
              <div>
                <label style={S.label}>GELEN ÇAĞRI YÖNLENDİRME MODU</label>
                <select style={S.select} value={ayarlar.netsantral_yonlendirme_modu}
                  onChange={e => up('netsantral_yonlendirme_modu', e.target.value)}>
                  <option value="dynamic">DİNAMİK - TTS + DAHİLİYE YÖNLENDIR (ÖNERİLEN)</option>
                  <option value="extensions">DİREKT - TTS'SİZ DAHİLİYE YÖNLENDIR</option>
                  <option value="tts">SADECE TTS - YÖNLENDİRME YOK</option>
                </select>
                <div style={{fontSize: 9, color: C.textMuted, marginTop: 4}}>
                  {ayarlar.netsantral_yonlendirme_modu === 'dynamic'
                    ? 'ARAYAN TANINIR → TTS İLE KARŞILANIR → DAHİLİYE AKTARILIR'
                    : ayarlar.netsantral_yonlendirme_modu === 'extensions'
                    ? 'DİREKT DAHİLİ NUMARASINA YÖNLENDİRİLİR (TTS OKUNMAZ)'
                    : 'SADECE HOŞGELDİNİZ MESAJI OKUNUR, IVR AKIŞI DEVAM EDER'}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* DURUM VE TEST */}
        <div style={{display: 'grid', gap: 16, alignContent: 'start'}}>
          {/* BAĞLANTI TESTİ */}
          <div style={S.card}>
            <div style={{...S.cardHead, padding: '12px 16px'}}>
              <LIcon name="Activity" size={14} color={C.accent}/>
              <span style={{fontSize: 12, fontWeight: 700}}>BAĞLANTI DURUMU</span>
            </div>
            <div style={{padding: 16}}>
              <button onClick={testBaglanti} disabled={testing} style={{
                ...S.btn, width: '100%', justifyContent: 'center',
                background: testing ? `${C.accent}55` : C.accent,
                color: '#fff', fontSize: 13, fontWeight: 700, padding: '12px 20px'
              }}>
                {testing ? (
                  <>
                    <div style={{width: 14, height: 14, border: '2px solid rgba(255,255,255,0.3)',
                      borderTop: '2px solid #fff', borderRadius: '50%', animation: 'spin 1s linear infinite'}}/>
                    TEST EDİLİYOR...
                  </>
                ) : (
                  <>
                    <LIcon name="Wifi" size={16} color="#fff"/> BAĞLANTIYI TEST ET
                  </>
                )}
              </button>

              {testResult && (
                <div style={{
                  marginTop: 12, padding: 12, borderRadius: 8,
                  background: testResult.success ? `${C.success}15` : `${C.danger}15`,
                  border: `1px solid ${testResult.success ? C.success + '33' : C.danger + '33'}`
                }}>
                  <div style={{
                    display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6
                  }}>
                    <LIcon name={testResult.success ? 'CheckCircle' : 'XCircle'} size={16}
                      color={testResult.success ? C.success : C.danger}/>
                    <span style={{
                      fontSize: 12, fontWeight: 700,
                      color: testResult.success ? C.success : C.danger
                    }}>
                      {testResult.success ? 'BAĞLANTI BAŞARILI' : 'BAĞLANTI HATASI'}
                    </span>
                  </div>
                  {testResult.error && (
                    <div style={{fontSize: 10, color: C.danger, wordBreak: 'break-all', marginBottom: 8}}>
                      {testResult.error}
                    </div>
                  )}
                  {/* ÇÖZÜM ÖNERİSİ */}
                  {!testResult.success && testResult.cozumOnerisi && (
                    <div style={{
                      marginTop: 4, marginBottom: 8, padding: '8px 10px', borderRadius: 6,
                      background: `${C.warning}15`, border: `1px solid ${C.warning}33`,
                      fontSize: 10, color: C.warning
                    }}>
                      <strong>ÇÖZÜM:</strong> {testResult.cozumOnerisi}
                      {testResult.oneriSantralNo && (
                        <div style={{marginTop:6}}>
                          <button onClick={() => {
                            up('netsantral_santral_no', testResult.oneriSantralNo);
                            setMesaj({type:'success', text:'SANTRAL NO "' + testResult.oneriSantralNo + '" OLARAK GÜNCELLENDİ. KAYDET VE TEKRAR TEST EDİN.'});
                          }} style={{...S.btn, background:C.warning, color:'#000', fontSize:10, padding:'6px 12px'}}>
                            <LIcon name="RefreshCw" size={11} color="#000"/>
                            SANTRAL NO'YU "{testResult.oneriSantralNo}" OLARAK GÜNCELLE
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                  {/* HATA DETAY - TANILAMA BUTONU */}
                  {!testResult.success && (
                    <button onClick={runDiagnose} disabled={diagnosing} style={{
                      ...S.btn, width: '100%', justifyContent: 'center', marginBottom: 8,
                      background: C.warning, color: '#000', fontSize: 10, padding: '8px 12px'
                    }}>
                      <LIcon name="Search" size={12} color="#000"/>
                      {diagnosing ? 'TANILAMA YAPILIYOR...' : 'ADIM ADIM TANILAMA BAŞLAT'}
                    </button>
                  )}
                  {/* DEBUG BİLGİLERİ */}
                  {testResult.debug && (
                    <div style={{
                      marginTop: 6, padding: '8px 10px', borderRadius: 6,
                      background: `${C.bg}88`, fontSize: 9, fontFamily: 'monospace',
                      color: C.textMuted, lineHeight: 1.8
                    }}>
                      <div style={{fontWeight: 700, color: C.textSec, marginBottom: 4, fontSize: 10}}>DETAY BİLGİ</div>
                      {testResult.debug.api_url && <div>API URL: {testResult.debug.api_url}</div>}
                      {testResult.debug.santral_no_api && <div>SANTRAL NO (API): {testResult.debug.santral_no_api}</div>}
                      {testResult.debug.username_api && <div>KULLANICI (API): {testResult.debug.username_api}</div>}
                      {testResult.httpCode !== undefined && <div>HTTP KOD: {testResult.httpCode}</div>}
                      {testResult.debug.primary_ip && <div>SUNUCU IP: {testResult.debug.primary_ip}</div>}
                      {testResult.debug.sure && <div>SÜRE: {testResult.debug.sure}</div>}
                      {testResult.debug.deneme && <div>DENEME: {testResult.debug.deneme}</div>}
                      {testResult.debug.curl_error && <div style={{color: C.danger}}>CURL: {testResult.debug.curl_error}</div>}
                      {testResult.debug.curl_errno !== undefined && <div style={{color: C.danger}}>CURL ERRNO: {testResult.debug.curl_errno}</div>}
                    </div>
                  )}
                  {/* TANILAMA SONUÇLARI */}
                  {diagnoseResult && diagnoseResult.adimlar && (
                    <div style={{
                      marginTop: 8, padding: '10px 12px', borderRadius: 8,
                      background: `${C.bg}`, border: `1px solid ${C.border}`,
                      fontSize: 10
                    }}>
                      <div style={{fontWeight: 700, color: C.accent, marginBottom: 8, fontSize: 11}}>
                        TANILAMA SONUÇLARI - {diagnoseResult.ozet}
                      </div>
                      {diagnoseResult.adimlar.map((adim, i) => (
                        <div key={i} style={{
                          marginBottom: 6, padding: '6px 8px', borderRadius: 6,
                          background: adim.durum === 'TAMAM' ? `${C.success}10` : `${C.danger}10`,
                          border: `1px solid ${adim.durum === 'TAMAM' ? C.success + '33' : C.danger + '33'}`
                        }}>
                          <div style={{display: 'flex', alignItems: 'center', gap: 6, marginBottom: 3}}>
                            <LIcon name={adim.durum === 'TAMAM' ? 'CheckCircle' : 'XCircle'} size={12}
                              color={adim.durum === 'TAMAM' ? C.success : C.danger}/>
                            <span style={{fontWeight: 700, color: adim.durum === 'TAMAM' ? C.success : C.danger}}>
                              ADIM {adim.adim}: {adim.baslik}
                            </span>
                          </div>
                          {adim.detay && (
                            <div style={{marginLeft: 18, fontFamily: 'monospace', fontSize: 9, color: C.textMuted, lineHeight: 1.6}}>
                              {Object.entries(adim.detay).map(([k, v]) => (
                                <div key={k}>{k}: {typeof v === 'object' ? JSON.stringify(v) : String(v)}</div>
                              ))}
                            </div>
                          )}
                        </div>
                      ))}
                      {diagnoseResult.sunucu_bilgi && (
                        <div style={{marginTop: 6, fontSize: 9, color: C.textMuted, fontFamily: 'monospace'}}>
                          SUNUCU: PHP {diagnoseResult.sunucu_bilgi.php} | CURL {diagnoseResult.sunucu_bilgi.curl} | SSL {diagnoseResult.sunucu_bilgi.ssl}
                        </div>
                      )}
                    </div>
                  )}
                  {/* BAŞARILI İSE KUYRUK BİLGİSİ */}
                  {testResult.success && testResult.data && (
                    <div style={{
                      marginTop: 6, padding: '8px 10px', borderRadius: 6,
                      background: `${C.success}10`, fontSize: 10, color: C.success
                    }}>
                      NETGSM BAĞLANTISI AKTİF - GELEN/GİDEN ARAMA HAZIR
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* WEBHOOK AYARLARI VE KURULUM REHBERİ */}
          <div style={S.card}>
            <div style={{...S.cardHead, padding: '12px 16px'}}>
              <LIcon name="Globe" size={14} color={C.purple}/>
              <span style={{fontSize: 12, fontWeight: 700}}>WEBHOOK & GELEN ÇAĞRI KURULUMU</span>
            </div>
            <div style={{padding: 16}}>
              {/* WEBHOOK URL */}
              <div style={{marginBottom: 12}}>
                <label style={S.label}>WEBHOOK URL (BU ADRESİ NETGSM'E GİRİN)</label>
                <div style={{
                  padding: '10px 14px', borderRadius: 8,
                  background: `${C.accent}11`, border: `1px solid ${C.accent}33`,
                  fontSize: 11, color: C.accent, fontFamily: 'monospace', wordBreak: 'break-all',
                  cursor: 'pointer', userSelect: 'all'
                }} onClick={() => {
                  navigator.clipboard?.writeText(webhookUrl);
                  setMesaj({type: 'success', text: 'WEBHOOK URL KOPYALANDI!'});
                  setTimeout(() => setMesaj({type: '', text: ''}), 2000);
                }}>
                  {webhookUrl}
                  <span style={{fontSize: 9, color: C.textMuted, display: 'block', marginTop: 4}}>
                    KOPYALAMAK İÇİN TIKLAYIN
                  </span>
                </div>
              </div>

              {/* KURULUM ADIMLARI */}
              <div style={{
                padding: '12px 14px', borderRadius: 8,
                background: `${C.warning}08`, border: `1px solid ${C.warning}22`,
                fontSize: 10, lineHeight: 2, color: C.textSec
              }}>
                <div style={{fontSize: 11, fontWeight: 700, color: C.warning, marginBottom: 6}}>
                  <LIcon name="BookOpen" size={12} color={C.warning}/> NETGSM PANEL KURULUM ADIMLARI
                </div>
                <div><strong style={{color: C.accent}}>1.</strong> NETGSM NETSANTRAL {'>'} MODÜLLER {'>'} ENTEGRASYONLAR {'>'} ÖZEL API</div>
                <div><strong style={{color: C.accent}}>2.</strong> FONKSİYON İSMİ: <strong>MR HASAR CRM GELEN</strong></div>
                <div><strong style={{color: C.accent}}>3.</strong> FONKSİYON URL: <strong style={{color: C.accent}}>YUKARIDAKİ WEBHOOK URL</strong></div>
                <div><strong style={{color: C.accent}}>4.</strong> FONKSİYON METOD: <strong style={{color: C.success}}>HTTP POST</strong></div>
                <div><strong style={{color: C.accent}}>5.</strong> SABİT DEĞİŞKEN EKLE: <strong>api_key = mr_hasar_2026</strong></div>
                <div><strong style={{color: C.accent}}>6.</strong> SONUÇ DURUMLARI: <strong>e</strong>=HATA, <strong>t</strong>=ZAMAN AŞIMI, <strong>1</strong>=BAŞARILI (TTS)</div>
                <div><strong style={{color: C.accent}}>7.</strong> FONKSİYONDAN MODÜL OLUŞTURUN</div>
                <div><strong style={{color: C.accent}}>8.</strong> AYARLAR {'>'} IVR {'>'} TUŞLAMAYINCA {'>'} MODÜL {'>'} ÖZEL API MODÜLÜ SEÇİN</div>
                <div style={{marginTop: 6, fontSize: 9, color: C.textMuted, fontStyle: 'italic'}}>
                  NOT: DİNAMİK YÖNLENDİRME İÇİN RESULT ALANI DAHİLİ NUMARASINI İÇERİR (ÖRN: 102)
                </div>
              </div>

              {/* WEBHOOK TEST BUTONLARI */}
              <div style={{display: 'flex', gap: 8, marginTop: 12}}>
                <button onClick={() => testWebhook('status')} disabled={webhookTesting} style={{
                  ...S.btn, flex: 1, justifyContent: 'center',
                  background: C.purple, color: '#fff', fontSize: 11, padding: '10px 12px'
                }}>
                  <LIcon name="Activity" size={14} color="#fff"/>
                  {webhookTesting ? 'KONTROL...' : 'WEBHOOK DURUMU'}
                </button>
                <button onClick={() => testWebhook('simulate')} disabled={webhookTesting} style={{
                  ...S.btn, flex: 1, justifyContent: 'center',
                  background: C.success, color: '#fff', fontSize: 11, padding: '10px 12px'
                }}>
                  <LIcon name="PhoneIncoming" size={14} color="#fff"/>
                  SİMÜLE ET
                </button>
                <button onClick={logGoster} style={{
                  ...S.btn, flex: 1, justifyContent: 'center',
                  background: C.borderLight, color: C.textSec, fontSize: 11, padding: '10px 12px'
                }}>
                  <LIcon name="FileText" size={14} color={C.textSec}/>
                  LOGLAR
                </button>
              </div>

              {/* WEBHOOK TEST SONUÇLARI */}
              {webhookTest && (
                <div style={{
                  marginTop: 12, padding: 12, borderRadius: 8,
                  background: `${C.bgHover}`, border: `1px solid ${C.border}`,
                  fontSize: 10, maxHeight: 300, overflowY: 'auto'
                }}>
                  {/* WEBHOOK DURUMU */}
                  {webhookTest.webhook_url && (
                    <div style={{marginBottom: 8}}>
                      <div style={{fontWeight: 700, color: C.accent, marginBottom: 4}}>WEBHOOK URL</div>
                      <div style={{color: C.text, fontFamily: 'monospace', wordBreak: 'break-all'}}>{webhookTest.webhook_url}</div>
                    </div>
                  )}
                  {/* API TEST DURUMU */}
                  {webhookTest.api_testi && (
                    <div style={{marginBottom: 8}}>
                      <div style={{fontWeight: 700, color: C.accent, marginBottom: 4}}>API BAĞLANTI</div>
                      <span style={{
                        ...MR.S.badge(webhookTest.api_testi.durum === 'BAĞLI' ? C.success : C.danger),
                        fontSize: 10
                      }}>
                        {webhookTest.api_testi.durum}
                      </span>
                      {webhookTest.api_testi.hata && (
                        <div style={{color: C.danger, marginTop: 4}}>{webhookTest.api_testi.hata}</div>
                      )}
                    </div>
                  )}
                  {/* YÖNLENDİRME BİLGİSİ */}
                  {webhookTest.yonlendirme && (
                    <div style={{marginBottom: 8}}>
                      <div style={{fontWeight: 700, color: C.accent, marginBottom: 4}}>YÖNLENDİRME</div>
                      <div style={{color: C.success}}>{webhookTest.yonlendirme.aciklama}</div>
                    </div>
                  )}
                  {/* SİMÜLASYON SONUCU */}
                  {webhookTest.dogrulama && (
                    <div style={{marginBottom: 8}}>
                      <div style={{fontWeight: 700, color: C.accent, marginBottom: 4}}>WEBHOOK YANIT DOĞRULAMA</div>
                      {Object.entries(webhookTest.dogrulama).map(([k, v]) => (
                        <div key={k} style={{display: 'flex', justifyContent: 'space-between', padding: '2px 0'}}>
                          <span style={{color: C.textMuted}}>{k.replace(/_/g, ' ').toUpperCase()}</span>
                          <span style={{color: String(v).includes('HAYIR') ? C.danger : C.success, fontWeight: 600}}>{v}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  {/* KURULUM REHBERİ */}
                  {webhookTest.kurulum_rehberi && (
                    <div>
                      <div style={{fontWeight: 700, color: C.warning, marginBottom: 4}}>KURULUM ADIMLARI</div>
                      {Object.values(webhookTest.kurulum_rehberi).map((step, i) => (
                        <div key={i} style={{color: C.textSec, padding: '1px 0'}}>{i + 1}. {step}</div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* WEBHOOK LOG */}
              {webhookLog && (
                <div style={{
                  marginTop: 12, padding: 12, borderRadius: 8,
                  background: '#0a0e1a', border: `1px solid ${C.border}`,
                  maxHeight: 250, overflowY: 'auto'
                }}>
                  <div style={{fontWeight: 700, color: C.warning, marginBottom: 8, fontSize: 11}}>WEBHOOK LOG</div>
                  <pre style={{
                    fontSize: 9, color: C.success, fontFamily: 'monospace',
                    whiteSpace: 'pre-wrap', wordBreak: 'break-all', margin: 0
                  }}>
                    {webhookLog.webhook_log || 'BOŞ'}
                  </pre>
                  {webhookLog.proxy_log && (
                    <>
                      <div style={{fontWeight: 700, color: C.warning, marginBottom: 8, marginTop: 12, fontSize: 11}}>PROXY LOG</div>
                      <pre style={{
                        fontSize: 9, color: C.cyan, fontFamily: 'monospace',
                        whiteSpace: 'pre-wrap', wordBreak: 'break-all', margin: 0
                      }}>
                        {webhookLog.proxy_log}
                      </pre>
                    </>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* KAYDET BUTONU */}
      <div style={{
        ...S.card, padding: '16px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        marginBottom: 16
      }}>
        <div style={{fontSize: 12, color: C.textMuted}}>
          <LIcon name="Info" size={14} color={C.textMuted} style={{verticalAlign: 'middle'}}/>{' '}
          NETSANTRAL AYARLARINI KAYDETTİKTEN SONRA TEK EKRANDAN ARAMA YAPABİLİRSİNİZ
        </div>
        <button style={{
          ...S.btn, ...S.btnP, fontSize: 13, padding: '12px 32px', fontWeight: 700,
          opacity: saving ? 0.7 : 1
        }} onClick={kaydet} disabled={saving}>
          <LIcon name="Save" size={16} color="#fff"/>
          {saving ? 'KAYDEDİLİYOR...' : 'AYARLARI KAYDET'}
        </button>
      </div>

      {/* ═══ ÇAĞRI GEÇMİŞİ ═══ */}
      <NetsantralCagriGecmisi/>
    </div>
  );
};

/* ════════════════════════════════════════════════════════════════
   TOPLU DOSYA AKTARIM TAB'I (SADECE ADMİN)
   ════════════════════════════════════════════════════════════════ */
const TopluAktarimTab = () => {
  const {C, S, LIcon, api} = MR;
  const [yukleniyor, setYukleniyor] = useState(false);
  const [sablonIndiriliyor, setSablonIndiriliyor] = useState(false);
  const [sonuc, setSonuc] = useState(null);
  const [hata, setHata] = useState('');
  const [secilenDosya, setSecilenDosya] = useState(null);
  const fileRef = React.useRef(null);

  /* ŞABLON İNDİR */
  const sablonIndir = async () => {
    setSablonIndiriliyor(true);
    try {
      const token = MR.api?.token;
      const r = await fetch('/api/v1/dosya/excel-sablon.php', {
        headers: token ? {'Authorization': 'Bearer ' + token} : {}
      });
      if (!r.ok) { setHata('ŞABLON İNDİRİLEMEDİ'); setSablonIndiriliyor(false); return; }
      const blob = await r.blob();
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'dosya_toplu_aktarim_sablonu.csv';
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    } catch(e) { setHata('İNDİRME HATASI: ' + e.message); }
    setSablonIndiriliyor(false);
  };

  /* DOSYA YÜKLE */
  const dosyaYukle = async () => {
    if (!secilenDosya) { setHata('LÜTFEN BİR CSV DOSYASI SEÇİN'); return; }
    setYukleniyor(true); setHata(''); setSonuc(null);

    try {
      const token = MR.api?.token;
      const formData = new FormData();
      formData.append('dosya', secilenDosya);

      const r = await fetch('/api/v1/dosya/excel-import.php', {
        method: 'POST',
        headers: token ? {'Authorization': 'Bearer ' + token} : {},
        body: formData
      });

      const json = await r.json();
      if (json.success) {
        setSonuc(json.data);
        setSecilenDosya(null);
        if (fileRef.current) fileRef.current.value = '';
      } else {
        setHata(json.error || 'AKTARIM HATASI');
      }
    } catch(e) {
      setHata('BAĞLANTI HATASI: ' + e.message);
    }
    setYukleniyor(false);
  };

  return (
    <div style={{display:'flex',flexDirection:'column',gap:16}}>
      {/* BİLGİ KARTI */}
      <div style={{...S.card}}>
        <div style={{...S.cardHead}}>
          <LIcon name="FileSpreadsheet" size={16} color={C.accent}/>
          <span style={{fontWeight:700}}>TOPLU DOSYA AKTARIMI (EXCEL/CSV)</span>
        </div>
        <div style={{padding:16}}>
          <div style={{background:`${C.accent}08`,border:`1px solid ${C.accent}22`,borderRadius:10,padding:16,marginBottom:16}}>
            <div style={{fontSize:12,fontWeight:700,color:C.accent,marginBottom:8,display:'flex',alignItems:'center',gap:6}}>
              <LIcon name="Info" size={14} color={C.accent}/> NASIL KULLANILIR?
            </div>
            <ol style={{fontSize:11,color:C.textSec,lineHeight:1.8,margin:0,paddingLeft:20}}>
              <li><b>ŞABLON İNDİR</b> butonuna tıklayarak Excel şablonunu indirin</li>
              <li>Şablondaki örnek satırları silin, kendi verilerinizi doldurun</li>
              <li><b>DOSYA TÜRÜ</b> (ADK/BH) ve <b>ADI SOYADI</b> zorunlu alanlardır</li>
              <li>Kaza tarihi formatı: <b>GG.AA.YYYY</b> (örn: 15.01.2026)</li>
              <li>CSV dosyasını <b>YÜKLE</b> butonuyla sisteme aktarın</li>
            </ol>
          </div>

          {/* ŞABLON SÜTUN BİLGİSİ */}
          <div style={{background:C.bgInput,borderRadius:8,padding:12,marginBottom:16}}>
            <div style={{fontSize:10,fontWeight:700,color:C.textMuted,marginBottom:8}}>ŞABLON ALANLARI:</div>
            <div style={{display:'flex',flexWrap:'wrap',gap:4}}>
              {['DOSYA TÜRÜ *','ADI SOYADI *','T.C. KİMLİK','TELEFON','TELEFON 2','E-POSTA',
                'SİGORTA ŞİRKETİ','HASAR NO','POLİÇE NO','KAZA TARİHİ','KAZA İL','KAZA İLÇE',
                'PLAKA','MARKA','MODEL','MODEL YILI','KARŞI PLAKA','KARŞI SİGORTA','DOSYA KAYNAĞI','AŞAMA','NOTLAR'
              ].map((s,i) => (
                <span key={i} style={{
                  fontSize:9,fontWeight:s.includes('*')?800:600,
                  padding:'3px 8px',borderRadius:4,
                  background:s.includes('*')?`${C.danger}18`:`${C.accent}12`,
                  color:s.includes('*')?C.danger:C.textSec,
                  border:`1px solid ${s.includes('*')?C.danger+'33':C.border}`
                }}>{s}</span>
              ))}
            </div>
            <div style={{fontSize:9,color:C.textMuted,marginTop:6}}>* Zorunlu alanlar</div>
          </div>

          {/* BUTONLAR */}
          <div style={{display:'flex',gap:12,alignItems:'flex-start',flexWrap:'wrap'}}>
            {/* ŞABLON İNDİR */}
            <button onClick={sablonIndir} disabled={sablonIndiriliyor}
              style={{...S.btn,padding:'12px 24px',fontSize:12,fontWeight:700,borderRadius:10,cursor:'pointer',
                background:`${C.accent}`,color:'#fff',border:'none',display:'flex',alignItems:'center',gap:8,
                opacity:sablonIndiriliyor?0.6:1}}>
              <LIcon name="Download" size={16} color="#fff"/>
              {sablonIndiriliyor ? 'İNDİRİLİYOR...' : 'ŞABLON İNDİR (CSV)'}
            </button>

            {/* DOSYA SEÇ + YÜKLE */}
            <div style={{display:'flex',gap:8,alignItems:'center',flex:1,minWidth:280}}>
              <label style={{...S.btn,padding:'12px 24px',fontSize:12,fontWeight:700,borderRadius:10,cursor:'pointer',
                background:`${C.success}`,color:'#fff',border:'none',display:'flex',alignItems:'center',gap:8}}>
                <LIcon name="Upload" size={16} color="#fff"/>
                DOSYA SEÇ
                <input ref={fileRef} type="file" accept=".csv,.txt" style={{display:'none'}}
                  onChange={e => { setSecilenDosya(e.target.files[0] || null); setHata(''); setSonuc(null); }}/>
              </label>
              {secilenDosya && (
                <div style={{display:'flex',alignItems:'center',gap:8,flex:1}}>
                  <div style={{fontSize:11,color:C.text,fontWeight:600,padding:'8px 12px',background:C.bgInput,borderRadius:8,border:`1px solid ${C.border}`,flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
                    <LIcon name="FileText" size={12} color={C.accent} style={{marginRight:6}}/>
                    {secilenDosya.name} ({(secilenDosya.size/1024).toFixed(0)}KB)
                  </div>
                  <button onClick={dosyaYukle} disabled={yukleniyor}
                    style={{...S.btn,padding:'10px 20px',fontSize:12,fontWeight:700,borderRadius:10,cursor:'pointer',
                      background:C.warning,color:'#fff',border:'none',display:'flex',alignItems:'center',gap:6,
                      opacity:yukleniyor?0.6:1,whiteSpace:'nowrap'}}>
                    <LIcon name="Upload" size={14} color="#fff"/>
                    {yukleniyor ? 'AKTARILIYOR...' : 'AKTAR'}
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* HATA MESAJI */}
          {hata && (
            <div style={{marginTop:12,padding:'10px 14px',borderRadius:8,background:`${C.danger}12`,border:`1px solid ${C.danger}33`,
              color:C.danger,fontSize:11,fontWeight:600,display:'flex',alignItems:'center',gap:8}}>
              <LIcon name="AlertTriangle" size={14} color={C.danger}/> {hata}
            </div>
          )}
        </div>
      </div>

      {/* SONUÇ KARTI */}
      {sonuc && (
        <div style={{...S.card}}>
          <div style={{...S.cardHead,background:`${sonuc.hatali > 0 ? C.warning : C.success}08`}}>
            <LIcon name={sonuc.hatali > 0 ? 'AlertCircle' : 'CheckCircle'} size={16} color={sonuc.hatali > 0 ? C.warning : C.success}/>
            <span style={{fontWeight:700}}>AKTARIM SONUCU</span>
          </div>
          <div style={{padding:16}}>
            {/* ÖZET */}
            <div style={{display:'flex',gap:12,marginBottom:16}}>
              <div style={{flex:1,padding:14,borderRadius:10,background:`${C.success}10`,border:`1px solid ${C.success}22`,textAlign:'center'}}>
                <div style={{fontSize:24,fontWeight:800,color:C.success}}>{sonuc.basarili}</div>
                <div style={{fontSize:10,fontWeight:600,color:C.success,marginTop:2}}>BAŞARILI</div>
              </div>
              <div style={{flex:1,padding:14,borderRadius:10,background:`${C.danger}10`,border:`1px solid ${C.danger}22`,textAlign:'center'}}>
                <div style={{fontSize:24,fontWeight:800,color:C.danger}}>{sonuc.hatali}</div>
                <div style={{fontSize:10,fontWeight:600,color:C.danger,marginTop:2}}>HATALI</div>
              </div>
              <div style={{flex:1,padding:14,borderRadius:10,background:`${C.accent}10`,border:`1px solid ${C.accent}22`,textAlign:'center'}}>
                <div style={{fontSize:24,fontWeight:800,color:C.accent}}>{sonuc.toplam}</div>
                <div style={{fontSize:10,fontWeight:600,color:C.accent,marginTop:2}}>TOPLAM</div>
              </div>
            </div>

            {/* OLUŞTURULAN DOSYALAR */}
            {sonuc.olusturulan?.length > 0 && (
              <div style={{marginBottom:12}}>
                <div style={{fontSize:11,fontWeight:700,color:C.success,marginBottom:8,display:'flex',alignItems:'center',gap:6}}>
                  <LIcon name="Check" size={12} color={C.success}/> OLUŞTURULAN DOSYALAR
                </div>
                <div style={{maxHeight:300,overflowY:'auto',borderRadius:8,border:`1px solid ${C.border}`}}>
                  <table style={{width:'100%',borderCollapse:'collapse',fontSize:11}}>
                    <thead>
                      <tr style={{background:C.bgInput}}>
                        <th style={{padding:'8px 10px',textAlign:'left',fontWeight:700,fontSize:9,color:C.textMuted}}>SATIR</th>
                        <th style={{padding:'8px 10px',textAlign:'left',fontWeight:700,fontSize:9,color:C.textMuted}}>DOSYA NO</th>
                        <th style={{padding:'8px 10px',textAlign:'left',fontWeight:700,fontSize:9,color:C.textMuted}}>ADI SOYADI</th>
                        <th style={{padding:'8px 10px',textAlign:'left',fontWeight:700,fontSize:9,color:C.textMuted}}>TÜR</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sonuc.olusturulan.map((d,i) => (
                        <tr key={i} style={{borderTop:`1px solid ${C.border}22`}}>
                          <td style={{padding:'6px 10px',fontSize:10,color:C.textMuted}}>{d.satir}</td>
                          <td style={{padding:'6px 10px',fontSize:11,fontWeight:700,color:C.accent}}>{d.dosya_no}</td>
                          <td style={{padding:'6px 10px',fontSize:11,color:C.text}}>{d.ad_soyad}</td>
                          <td style={{padding:'6px 10px'}}><span style={{fontSize:9,fontWeight:700,padding:'2px 6px',borderRadius:4,background:d.dosya_turu==='ADK'?`${C.accent}18`:`${C.gold}18`,color:d.dosya_turu==='ADK'?C.accent:C.gold}}>{d.dosya_turu}</span></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* HATALAR */}
            {sonuc.hatalar?.length > 0 && (
              <div>
                <div style={{fontSize:11,fontWeight:700,color:C.danger,marginBottom:8,display:'flex',alignItems:'center',gap:6}}>
                  <LIcon name="AlertTriangle" size={12} color={C.danger}/> HATALI SATIRLAR
                </div>
                <div style={{maxHeight:200,overflowY:'auto',background:`${C.danger}06`,borderRadius:8,padding:10,border:`1px solid ${C.danger}22`}}>
                  {sonuc.hatalar.map((h,i) => (
                    <div key={i} style={{fontSize:10,color:C.danger,padding:'4px 0',borderBottom:i<sonuc.hatalar.length-1?`1px solid ${C.danger}11`:'none'}}>
                      {h}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

/* ════════════════════════════════════════════════════════════════
   PORTAL AYARLARI TAB
   MÜŞTERİ/MAĞDUR PORTAL YÖNETİMİ & AYARLARI
   ════════════════════════════════════════════════════════════════ */
const PortalTab = () => {
  const {C, S, LIcon, Badge, StatCard, Loading, EmptyState, Modal, FormGroup, Confirm, api} = MR;
  const [subTab, setSubTab] = useState('ayarlar');
  const [ayarlar, setAyarlar] = useState({});
  const [erisimler, setErisimler] = useState([]);
  const [loglar, setLoglar] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [stats, setStats] = useState({toplam:0, aktif:0, pasif:0, son7gun_aktif:0});
  const [arama, setArama] = useState('');
  const [confirmState, setConfirmState] = useState({open:false, id:null, msg:''});
  const [mesajModal, setMesajModal] = useState({open:false, dosyaId:null, dosyaNo:'', mesajlar:[], yeniMesaj:'', loading:false});

  /* Portal ayarları varsayılan değerler */
  const PORTAL_AYAR_KEYS = {
    portal_aktif: '1',
    portal_giris_yontemi: 'tc_telefon',
    portal_oturum_suresi: '120',
    portal_evrak_goster: '1',
    portal_evrak_indir: '1',
    portal_gecmis_goster: '1',
    portal_masraf_goster: '0',
    portal_mesaj_aktif: '1',
    portal_otomatik_olustur: '0',
    portal_karsilama: 'Hoş geldiniz. Dosyanızın güncel durumunu bu portal üzerinden takip edebilirsiniz.',
    portal_kvkk_metni: '6698 sayılı KVKK kapsamında kişisel verileriniz korunmaktadır.'
  };

  const loadAyarlar = async () => {
    const r = await api.ayarlarList();
    if (r?.success) {
      const data = r.data || {};
      const portalAyarlar = {};
      Object.keys(PORTAL_AYAR_KEYS).forEach(key => {
        portalAyarlar[key] = data[key] !== undefined ? data[key] : PORTAL_AYAR_KEYS[key];
      });
      setAyarlar(portalAyarlar);
    }
  };

  const loadErisimler = async () => {
    const params = arama ? `arama=${encodeURIComponent(arama)}&limit=50` : 'limit=50';
    const r = await api.req('/portal/erisim-list.php?' + params);
    if (r?.success) {
      const d = r.data || {};
      setErisimler(d.items || []);
      if (d.istatistik) setStats(d.istatistik);
    }
  };

  const loadLoglar = async () => {
    const r = await api.req('/portal/loglar.php?limit=50');
    if (r?.success) {
      setLoglar(r.data?.items || []);
    }
  };

  useEffect(() => {
    setLoading(true);
    Promise.all([loadAyarlar(), loadErisimler()]).then(() => setLoading(false));
  }, []);

  useEffect(() => { if (subTab === 'loglar') loadLoglar(); }, [subTab]);

  const ayarKaydet = async () => {
    setSaving(true);
    const r = await api.ayarlarGuncelle(ayarlar);
    setSaving(false);
    if (r?.success) MR.toast?.('PORTAL AYARLARI KAYDEDİLDİ', 'success');
    else MR.toast?.('KAYIT HATASI: ' + (r?.error || ''), 'error');
  };

  const up = (k, v) => setAyarlar(p => ({...p, [k]: v}));

  const erisimKapat = async (id) => {
    const r = await api.req('/portal/erisim-sil.php?id=' + id, {method: 'DELETE'});
    if (r?.success) { MR.toast?.('ERİŞİM KAPATILDI', 'success'); loadErisimler(); }
    else MR.toast?.(r?.error || 'HATA', 'error');
  };

  const erisimAktifPasif = async (id, aktif) => {
    const r = await api.req('/portal/erisim-guncelle.php', {method: 'PUT', body: JSON.stringify({id, aktif: aktif ? 1 : 0})});
    if (r?.success) { MR.toast?.(aktif ? 'ERİŞİM AKTİFLEŞTİRİLDİ' : 'ERİŞİM DURDURULDU', 'success'); loadErisimler(); }
  };

  const smsYenidenGonder = async (id) => {
    const r = await api.req('/portal/erisim-guncelle.php', {method: 'PUT', body: JSON.stringify({id, sms_gonder: true})});
    if (r?.success) MR.toast?.('PORTAL SMS YENİDEN GÖNDERİLDİ', 'success');
    else MR.toast?.(r?.error || 'SMS GÖNDERİLEMEDİ', 'error');
  };

  const mesajlariAc = async (dosyaId, dosyaNo) => {
    setMesajModal({open:true, dosyaId, dosyaNo, mesajlar:[], yeniMesaj:'', loading:true});
    const r = await api.req('/portal/portal-mesaj-list.php?dosya_id=' + dosyaId);
    setMesajModal(p => ({...p, mesajlar: r?.success ? (r.data || []) : [], loading:false}));
  };

  const firmaMesajGonder = async () => {
    if (!mesajModal.yeniMesaj.trim()) return;
    const r = await api.req('/portal/portal-mesaj-gonder.php', {method:'POST', body: JSON.stringify({dosya_id: mesajModal.dosyaId, mesaj: mesajModal.yeniMesaj})});
    if (r?.success) {
      setMesajModal(p => ({...p, yeniMesaj: ''}));
      const r2 = await api.req('/portal/portal-mesaj-list.php?dosya_id=' + mesajModal.dosyaId);
      setMesajModal(p => ({...p, mesajlar: r2?.success ? (r2.data || []) : p.mesajlar}));
    }
  };

  const formatTarih = (t) => {
    if(!t) return '-';
    try { return new Date(t).toLocaleDateString('tr-TR'); } catch(e) { return t; }
  };
  const formatTS = (t) => {
    if(!t) return '-';
    try { const d = new Date(t); return d.toLocaleDateString('tr-TR') + ' ' + d.toLocaleTimeString('tr-TR',{hour:'2-digit',minute:'2-digit'}); } catch(e) { return t; }
  };

  if (loading) return React.createElement(Loading);

  const SUB_TABS = [
    {key:'ayarlar', label:'GENEL AYARLAR', icon:'Settings'},
    {key:'erisimler', label:'AKTİF PORTALLAR', icon:'Users'},
    {key:'loglar', label:'PORTAL LOGLARI', icon:'Activity'}
  ];

  const Sw = ({checked, onChange, label}) => (
    <div style={{display:'flex', alignItems:'center', gap:10, padding:'8px 0'}}>
      <div onClick={() => onChange(!checked)} style={{width:42, height:22, borderRadius:11, background:checked ? C.success : C.borderLight, cursor:'pointer', position:'relative', transition:'all .2s'}}>
        <div style={{width:18, height:18, borderRadius:9, background:'#fff', position:'absolute', top:2, left:checked ? 22 : 2, transition:'all .2s', boxShadow:'0 1px 3px rgba(0,0,0,.2)'}}/>
      </div>
      <span style={{fontSize:12, fontWeight:500, color:C.textSec}}>{label}</span>
    </div>
  );

  return (
    <div>
      {/* İSTATİSTİKLER */}
      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(160px,1fr))', gap:12, marginBottom:16}}>
        <div style={{...S.stat}}>
          <div style={{fontSize:10, fontWeight:600, color:C.textMuted, letterSpacing:.5}}>TOPLAM PORTAL</div>
          <div style={{fontSize:22, fontWeight:800, color:C.accent, marginTop:4}}>{stats.toplam || 0}</div>
        </div>
        <div style={{...S.stat}}>
          <div style={{fontSize:10, fontWeight:600, color:C.textMuted, letterSpacing:.5}}>AKTİF</div>
          <div style={{fontSize:22, fontWeight:800, color:C.success, marginTop:4}}>{stats.aktif || 0}</div>
        </div>
        <div style={{...S.stat}}>
          <div style={{fontSize:10, fontWeight:600, color:C.textMuted, letterSpacing:.5}}>PASİF</div>
          <div style={{fontSize:22, fontWeight:800, color:C.danger, marginTop:4}}>{stats.pasif || 0}</div>
        </div>
        <div style={{...S.stat}}>
          <div style={{fontSize:10, fontWeight:600, color:C.textMuted, letterSpacing:.5}}>SON 7 GÜN AKTİF</div>
          <div style={{fontSize:22, fontWeight:800, color:C.warning, marginTop:4}}>{stats.son7gun_aktif || 0}</div>
        </div>
      </div>

      {/* SUB TAB MENU */}
      <div style={{...S.card, marginBottom:16}}>
        <div style={{display:'flex', borderBottom:`1px solid ${C.border}`, padding:'0 12px'}}>
          {SUB_TABS.map(st => {
            const aktif = subTab === st.key;
            return (
              <div key={st.key} onClick={() => setSubTab(st.key)} style={{display:'flex', alignItems:'center', gap:6, padding:'12px 16px', cursor:'pointer', fontSize:11, fontWeight:aktif?700:500, color:aktif?C.accent:C.textSec, borderBottom:aktif?`2px solid ${C.accent}`:'2px solid transparent', transition:'all .2s', whiteSpace:'nowrap'}}>
                <LIcon name={st.icon} size={14} color={aktif?C.accent:C.textMuted}/> {st.label}
              </div>
            );
          })}
        </div>

        <div style={{...S.cardBody}}>
          {/* ═══ GENEL AYARLAR ═══ */}
          {subTab === 'ayarlar' && (
            <div>
              <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:20}}>
                {/* SOL KOLON */}
                <div>
                  <div style={{fontSize:13, fontWeight:700, marginBottom:12, color:C.text}}>PORTAL SİSTEMİ</div>

                  <Sw checked={ayarlar.portal_aktif === '1'} onChange={v => up('portal_aktif', v?'1':'0')} label="PORTAL SİSTEMİ AKTİF"/>
                  <Sw checked={ayarlar.portal_otomatik_olustur === '1'} onChange={v => up('portal_otomatik_olustur', v?'1':'0')} label="DOSYA AÇILIŞINDA OTOMATİK PORTAL OLUŞTUR"/>

                  <div style={{marginTop:16}}>
                    <label style={S.label}>GİRİŞ YÖNTEMİ</label>
                    <select style={S.select} value={ayarlar.portal_giris_yontemi || 'sms_otp'} onChange={e => up('portal_giris_yontemi', e.target.value)}>
                      <option value="tc_telefon">TC KİMLİK + TELEFON (SMS GEREKTİRMEZ)</option>
                      <option value="link">DOĞRUDAN LİNK (KOPYALANABİLİR LİNK)</option>
                      <option value="sms_otp">SMS OTP (SMS ABONELİĞİ GEREKTİRİR)</option>
                    </select>
                  </div>

                  <div style={{marginTop:12}}>
                    <label style={S.label}>OTURUM SÜRESİ (DAKİKA)</label>
                    <input type="number" style={S.input} value={ayarlar.portal_oturum_suresi || '120'} onChange={e => up('portal_oturum_suresi', e.target.value)} min="15" max="1440"/>
                  </div>

                  <div style={{fontSize:13, fontWeight:700, marginTop:24, marginBottom:12, color:C.text}}>ERİŞİM İZİNLERİ</div>
                  <Sw checked={ayarlar.portal_evrak_goster === '1'} onChange={v => up('portal_evrak_goster', v?'1':'0')} label="EVRAKLARI GÖSTER"/>
                  <Sw checked={ayarlar.portal_evrak_indir === '1'} onChange={v => up('portal_evrak_indir', v?'1':'0')} label="EVRAK İNDİRMEYE İZİN VER"/>
                  <Sw checked={ayarlar.portal_gecmis_goster === '1'} onChange={v => up('portal_gecmis_goster', v?'1':'0')} label="DOSYA GEÇMİŞİNİ GÖSTER"/>
                  <Sw checked={ayarlar.portal_masraf_goster === '1'} onChange={v => up('portal_masraf_goster', v?'1':'0')} label="MASRAFLARI GÖSTER"/>
                  <Sw checked={ayarlar.portal_mesaj_aktif === '1'} onChange={v => up('portal_mesaj_aktif', v?'1':'0')} label="MESAJLAŞMA ÖZELLİĞİ"/>
                </div>

                {/* SAĞ KOLON */}
                <div>
                  <div style={{fontSize:13, fontWeight:700, marginBottom:12, color:C.text}}>PORTAL İÇERİK</div>

                  <label style={S.label}>KARŞILAMA MESAJI</label>
                  <textarea style={{...S.input, height:80, resize:'vertical'}} value={ayarlar.portal_karsilama || ''} onChange={e => up('portal_karsilama', e.target.value)} placeholder="Müşteriye gösterilecek karşılama mesajı..."/>

                  <div style={{marginTop:12}}>
                    <label style={S.label}>KVKK BİLGİLENDİRME METNİ</label>
                    <textarea style={{...S.input, height:80, resize:'vertical'}} value={ayarlar.portal_kvkk_metni || ''} onChange={e => up('portal_kvkk_metni', e.target.value)} placeholder="KVKK aydınlatma metni..."/>
                  </div>

                  <div style={{marginTop:20, padding:16, background:`${C.accent}08`, borderRadius:10, border:`1px solid ${C.accent}22`}}>
                    <div style={{fontSize:12, fontWeight:700, color:C.accent, marginBottom:8}}>PORTAL NASIL ÇALIŞIR?</div>
                    <div style={{fontSize:11, color:C.textSec, lineHeight:1.7}}>
                      1. Dosya detayından PORTAL butonuna tıklayarak erişim oluşturun<br/>
                      2. Oluşan link ve giriş bilgilerini müşteriye iletin (WhatsApp, e-posta vb.)<br/>
                      3. Müşteri TC Kimlik + Telefon ile veya doğrudan link ile giriş yapar<br/>
                      4. Evrakları görüntüler, mesaj gönderir<br/>
                      5. Tüm giriş/çıkışlar KVKK uyumlu loglanır (SMS aboneliği gerekmez)
                    </div>
                  </div>

                  <div style={{marginTop:16, padding:16, background:`${C.warning}08`, borderRadius:10, border:`1px solid ${C.warning}22`}}>
                    <div style={{fontSize:12, fontWeight:700, color:C.warning, marginBottom:6}}>YASAL UYUM</div>
                    <div style={{fontSize:11, color:C.textSec, lineHeight:1.6}}>
                      - 6698 sayılı KVKK'ya uygun veri işleme<br/>
                      - Tüm portal erişimleri IP ve tarih bazlı loglanır<br/>
                      - Müşteri yalnızca kendi dosyasını görür<br/>
                      - OTP ile güvenli kimlik doğrulama<br/>
                      - Erişim süresi ve bitiş tarihi belirleme
                    </div>
                  </div>
                </div>
              </div>

              <div style={{marginTop:20, display:'flex', justifyContent:'flex-end'}}>
                <button onClick={ayarKaydet} disabled={saving} style={{...S.btn, ...S.btnP, opacity:saving?.5:1}}>
                  <LIcon name="Save" size={14}/> {saving ? 'KAYDEDİLİYOR...' : 'AYARLARI KAYDET'}
                </button>
              </div>
            </div>
          )}

          {/* ═══ AKTİF PORTALLAR ═══ */}
          {subTab === 'erisimler' && (
            <div>
              <div style={{display:'flex', gap:8, marginBottom:16}}>
                <input style={{...S.input, maxWidth:300}} placeholder="DOSYA NO, AD SOYAD VEYA TELEFON ARA..." value={arama} onChange={e => setArama(e.target.value)} onKeyDown={e => e.key === 'Enter' && loadErisimler()}/>
                <button onClick={loadErisimler} style={{...S.btn, ...S.btnP}}>
                  <LIcon name="Search" size={14}/> ARA
                </button>
                <button onClick={() => {setArama(''); setTimeout(loadErisimler, 100);}} style={{...S.btn, ...S.btnG}}>
                  <LIcon name="RotateCcw" size={14}/> TEMİZLE
                </button>
              </div>

              {erisimler.length === 0 ? (
                <div style={{textAlign:'center', padding:40, color:C.textMuted, fontSize:13}}>
                  <LIcon name="Users" size={32} color={C.textMuted}/>
                  <div style={{marginTop:8}}>HENÜZ PORTAL ERİŞİMİ TANIMLANMAMIŞ</div>
                </div>
              ) : (
                <div style={{overflowX:'auto'}}>
                  <table style={{width:'100%', borderCollapse:'collapse', fontSize:12}}>
                    <thead>
                      <tr style={{borderBottom:`2px solid ${C.border}`}}>
                        {['DOSYA NO','MÜŞTERİ','TELEFON','GİRİŞ','DURUM','SON GİRİŞ','MESAJ','İŞLEMLER'].map(h => (
                          <th key={h} style={{padding:'10px 8px', textAlign:'left', fontWeight:700, fontSize:10, color:C.textMuted, letterSpacing:.5}}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {erisimler.map(e => (
                        <tr key={e.id} style={{borderBottom:`1px solid ${C.border}`}}>
                          <td style={{padding:'10px 8px', fontWeight:700, color:C.accent}}>{e.dosya_no}</td>
                          <td style={{padding:'10px 8px', fontWeight:600}}>{e.ad_soyad}</td>
                          <td style={{padding:'10px 8px', color:C.textSec, fontSize:11}}>{e.telefon}</td>
                          <td style={{padding:'10px 8px'}}>
                            <span style={{...S.badge(e.giris_yontemi === 'sms_otp' ? C.accent : C.purple)}}>
                              {e.giris_yontemi === 'sms_otp' ? 'SMS OTP' : 'LİNK'}
                            </span>
                          </td>
                          <td style={{padding:'10px 8px'}}>
                            <span style={{...S.badge(e.aktif == 1 ? C.success : C.danger)}}>
                              {e.aktif == 1 ? 'AKTİF' : 'PASİF'}
                            </span>
                          </td>
                          <td style={{padding:'10px 8px', fontSize:11, color:C.textSec}}>{formatTS(e.son_giris)}</td>
                          <td style={{padding:'10px 8px'}}>
                            {e.okunmamis_mesaj > 0 && (
                              <span onClick={() => mesajlariAc(e.dosya_id, e.dosya_no)} style={{background:C.danger, color:'#fff', padding:'2px 8px', borderRadius:10, fontSize:10, fontWeight:700, cursor:'pointer'}}>
                                {e.okunmamis_mesaj} YENİ
                              </span>
                            )}
                            {(!e.okunmamis_mesaj || e.okunmamis_mesaj == 0) && (
                              <span onClick={() => mesajlariAc(e.dosya_id, e.dosya_no)} style={{color:C.textMuted, fontSize:10, cursor:'pointer', textDecoration:'underline'}}>MESAJLAR</span>
                            )}
                          </td>
                          <td style={{padding:'10px 8px'}}>
                            <div style={{display:'flex', gap:4}}>
                              <button onClick={() => smsYenidenGonder(e.id)} title="SMS YENİDEN GÖNDER" style={{...S.btn, padding:'4px 8px', fontSize:10, ...S.btnP}}>
                                <LIcon name="MessageSquare" size={12}/>
                              </button>
                              <button onClick={() => erisimAktifPasif(e.id, e.aktif != 1)} title={e.aktif == 1 ? 'DURDUR' : 'AKTİFLEŞTİR'} style={{...S.btn, padding:'4px 8px', fontSize:10, background:e.aktif == 1 ? C.warning : C.success, color:'#fff'}}>
                                <LIcon name={e.aktif == 1 ? 'Pause' : 'Play'} size={12}/>
                              </button>
                              <button onClick={() => setConfirmState({open:true, id:e.id, msg:`${e.dosya_no} - ${e.ad_soyad} portal erişimi kapatılsın mı?`})} title="ERİŞİMİ KAPAT" style={{...S.btn, padding:'4px 8px', fontSize:10, ...S.btnD}}>
                                <LIcon name="Trash2" size={12}/>
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* ═══ PORTAL LOGLARI ═══ */}
          {subTab === 'loglar' && (
            <div>
              <div style={{display:'flex', justifyContent:'space-between', marginBottom:12}}>
                <div style={{fontSize:13, fontWeight:700, color:C.text}}>PORTAL GİRİŞ / İŞLEM LOGLARI (KVKK)</div>
                <button onClick={loadLoglar} style={{...S.btn, ...S.btnG, padding:'6px 12px', fontSize:10}}>
                  <LIcon name="RotateCcw" size={12}/> YENİLE
                </button>
              </div>
              {loglar.length === 0 ? (
                <div style={{textAlign:'center', padding:40, color:C.textMuted, fontSize:13}}>
                  HENÜZ LOG KAYDI YOK
                </div>
              ) : (
                <div style={{overflowX:'auto'}}>
                  <table style={{width:'100%', borderCollapse:'collapse', fontSize:11}}>
                    <thead>
                      <tr style={{borderBottom:`2px solid ${C.border}`}}>
                        {['TARİH','MÜŞTERİ','DOSYA NO','İŞLEM','DETAY','IP ADRESİ'].map(h => (
                          <th key={h} style={{padding:'8px 6px', textAlign:'left', fontWeight:700, fontSize:10, color:C.textMuted}}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {loglar.map(l => (
                        <tr key={l.id} style={{borderBottom:`1px solid ${C.border}`}}>
                          <td style={{padding:'8px 6px', fontSize:10, color:C.textSec}}>{formatTS(l.created_at)}</td>
                          <td style={{padding:'8px 6px', fontWeight:600}}>{l.ad_soyad || '-'}</td>
                          <td style={{padding:'8px 6px', color:C.accent, fontWeight:600}}>{l.dosya_no || '-'}</td>
                          <td style={{padding:'8px 6px'}}>
                            <span style={{...S.badge(LOG_ISLEM_RENK(l.islem))}}>{l.islem}</span>
                          </td>
                          <td style={{padding:'8px 6px', color:C.textSec, maxWidth:200, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap'}}>{l.detay || '-'}</td>
                          <td style={{padding:'8px 6px', fontSize:10, color:C.textMuted, fontFamily:'monospace'}}>{l.ip_adresi || '-'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* CONFIRM DIALOG */}
      {confirmState.open && React.createElement(Confirm, {
        message: confirmState.msg,
        onConfirm: () => { erisimKapat(confirmState.id); setConfirmState({open:false, id:null, msg:''}); },
        onCancel: () => setConfirmState({open:false, id:null, msg:''})
      })}

      {/* MESAJ MODAL */}
      {mesajModal.open && React.createElement(Modal, {
        title: `PORTAL MESAJLARI - ${mesajModal.dosyaNo}`,
        onClose: () => setMesajModal({open:false, dosyaId:null, dosyaNo:'', mesajlar:[], yeniMesaj:'', loading:false}),
        width: 600
      },
        React.createElement('div', {style: {maxHeight:400, overflowY:'auto', marginBottom:12}},
          mesajModal.loading ? React.createElement('div', {style:{textAlign:'center', padding:20, color:C.textMuted}}, 'YÜKLENİYOR...') :
          mesajModal.mesajlar.length === 0 ? React.createElement('div', {style:{textAlign:'center', padding:20, color:C.textMuted, fontSize:12}}, 'HENÜZ MESAJ YOK') :
          mesajModal.mesajlar.map(m => React.createElement('div', {key:m.id, style:{marginBottom:8, maxWidth:'80%', marginLeft:m.gonderen_tip==='musteri'?0:'auto', marginRight:m.gonderen_tip==='firma'?0:'auto'}},
            React.createElement('div', {style:{padding:'8px 12px', borderRadius:10, fontSize:12, background:m.gonderen_tip==='musteri'?`${C.accent}11`:C.bgHover, border:`1px solid ${m.gonderen_tip==='musteri'?C.accent+'33':C.border}`}},
              React.createElement('div', {style:{fontSize:9, fontWeight:700, color:m.gonderen_tip==='musteri'?C.accent:C.success, marginBottom:2}}, m.gonderen_tip==='musteri' ? 'MÜŞTERİ' : (m.gonderen_adi || 'FİRMA')),
              m.mesaj
            ),
            React.createElement('div', {style:{fontSize:9, color:C.textMuted, marginTop:2, textAlign:m.gonderen_tip==='firma'?'right':'left'}}, formatTS(m.created_at))
          ))
        ),
        React.createElement('div', {style:{display:'flex', gap:8}},
          React.createElement('input', {style:{...S.input, flex:1}, placeholder:'Müşteriye mesaj yazın...', value:mesajModal.yeniMesaj, onChange:e => setMesajModal(p=>({...p, yeniMesaj:e.target.value})), onKeyDown:e => e.key==='Enter' && firmaMesajGonder()}),
          React.createElement('button', {style:{...S.btn, ...S.btnP}, onClick:firmaMesajGonder, disabled:!mesajModal.yeniMesaj.trim()}, React.createElement(LIcon, {name:'Send', size:14}), ' GÖNDER')
        )
      )}
    </div>
  );
};

/* ════════════════════════════════════════════════════════════════
   ANA SAYFA BİLEŞENİ - MR.SistemPage
   ════════════════════════════════════════════════════════════════ */
MR.SistemPage = ({setPage, user, subPage}) => {
  const {C, S, LIcon, SectionTitle} = MR;

  /* ─── TAB TANIMLAMALARI ─── */
  const tabs = [
    {key: 'kullanici', label: 'KULLANICI YÖNETİMİ', icon: 'Users',     desc: 'KULLANICI OLUŞTUR, DÜZENLE, YÖNETİMİ'},
    {key: 'yetki',     label: 'YETKİ YÖNETİMİ',     icon: 'KeyRound',  desc: 'MODÜL BAZLI İZİN YÖNETİMİ'},
    {key: 'ayarlar',   label: 'FİRMA AYARLARI',      icon: 'Settings',  desc: 'LOGO, ÜNVAN, SLOGAN, BİLGİLER'},
    {key: 'netsantral',label: 'NETSANTRAL',           icon: 'Phone',     desc: 'NETSANTRAL ENTEGRASYON AYARLARI'},
    {key: 'sms',       label: 'SMS BİLDİRİM',         icon: 'MessageSquare', desc: 'DURUM DEĞİŞİKLİĞİ SMS BİLDİRİM AYARLARI'},
    {key: 'portal',    label: 'PORTAL AYARLARI',       icon: 'Globe',     desc: 'MÜŞTERİ/MAĞDUR PORTAL YÖNETİMİ'},
    {key: 'aktarim',   label: 'TOPLU AKTARIM',         icon: 'FileSpreadsheet', desc: 'EXCEL/CSV İLE TOPLU DOSYA AKTARIMI'},
    {key: 'log',       label: 'LOG KAYITLARI',        icon: 'Activity',  desc: 'SİSTEM OLAY GEÇMİŞİ'}
  ];

  /* ADMİN DEĞİLSE SADECE LOG TAB'INI GÖSTER */
  const isAdmin = user?.rol === 'admin';
  const gorunenTabs = isAdmin ? tabs : tabs.filter(t => t.key === 'log');

  /* AKTİF TAB */
  const [aktifTab, setAktifTab] = useState(() => {
    if (subPage && gorunenTabs.some(t => t.key === subPage)) return subPage;
    return gorunenTabs[0]?.key || 'kullanici';
  });

  /* subPage DEĞİŞTİĞİNDE TAB GÜNCELLE */
  useEffect(() => {
    if (subPage && gorunenTabs.some(t => t.key === subPage)) {
      setAktifTab(subPage);
    }
  }, [subPage]);

  const aktifTabInfo = tabs.find(t => t.key === aktifTab);

  return (
    <div className="fade-in">
      {/* BAŞLIK */}
      <div style={{...S.card, marginBottom:20}}>
        <div style={{...S.cardHead, justifyContent:'space-between'}}>
          <div style={{display:'flex', alignItems:'center', gap:12}}>
            <div style={{width:40, height:40, borderRadius:10, background:`${C.accent}22`,
              display:'flex', alignItems:'center', justifyContent:'center'}}>
              <LIcon name="Settings" size={20} color={C.accent}/>
            </div>
            <div>
              <div style={{fontSize:16, fontWeight:800}}>SİSTEM YÖNETİMİ</div>
              <div style={{fontSize:11, color:C.textMuted}}>KULLANICILAR, YETKİLER, AYARLAR VE SİSTEM LOGLARI</div>
            </div>
          </div>
          {user && (
            <div style={{display:'flex', alignItems:'center', gap:8}}>
              <LIcon name="User" size={14} color={C.textMuted}/>
              <span style={{fontSize:11, color:C.textSec}}>{user.ad_soyad}</span>
              <span style={{...S.badge(ROL_RENK[user.rol] || C.accent)}}>{ROL_LABEL[user.rol] || (user.rol || '').toUpperCase()}</span>
            </div>
          )}
        </div>

        {/* TAB MENÜSÜ */}
        <div style={{display:'flex', borderBottom:`1px solid ${C.border}`, padding:'0 16px', overflowX:'auto'}}>
          {gorunenTabs.map(tab => {
            const aktif = aktifTab === tab.key;
            return (
              <div key={tab.key} onClick={() => setAktifTab(tab.key)}
                style={{
                  display:'flex', alignItems:'center', gap:8, padding:'14px 20px',
                  cursor:'pointer', position:'relative', transition:'all .2s',
                  color: aktif ? C.accent : C.textSec,
                  fontWeight: aktif ? 700 : 500, fontSize:12, whiteSpace:'nowrap',
                  borderBottom: aktif ? `2px solid ${C.accent}` : '2px solid transparent'
                }}
                onMouseEnter={e => { if (!aktif) e.currentTarget.style.color = C.text; }}
                onMouseLeave={e => { if (!aktif) e.currentTarget.style.color = C.textSec; }}>
                <LIcon name={tab.icon} size={15} color={aktif ? C.accent : C.textMuted}/>
                {tab.label}
              </div>
            );
          })}
        </div>
      </div>

      {/* TAB İÇERİĞİ */}
      <div key={aktifTab} className="fade-in">
        {aktifTab === 'kullanici' && isAdmin && <KullaniciTab/>}
        {aktifTab === 'yetki' && isAdmin && <YetkiTab/>}
        {aktifTab === 'ayarlar' && isAdmin && <AyarlarTab/>}
        {aktifTab === 'netsantral' && isAdmin && <NetsantralTab/>}
        {aktifTab === 'sms' && isAdmin && <SmsTab/>}
        {aktifTab === 'portal' && isAdmin && <PortalTab/>}
        {aktifTab === 'aktarim' && isAdmin && <TopluAktarimTab/>}
        {aktifTab === 'log' && <LogTab/>}
      </div>
    </div>
  );
};
