# MR HASAR — v2.2 KRİTİK FİNANSAL & GÜVENLİK HOTFİX
**Tarih:** 03 Mayıs 2026
**Hedef:** sistem.mrhasardanismanlik.com
**Tahmini süre:** 6-8 dakika
**Risk:** Sıfır (sadece backend hardening + frontend yetki)

---

## 📦 BU PAKET NE GETİRİYOR

### 8 Kritik Sorun Çözümü

| # | Konu | Dosya | Etki |
|---|---|---|---|
| **#017** | Masraf silinince kasa bakiyesi geri yüklenmiyordu | masraf/delete.php | Kasa rollback |
| **#018** | Masraf güncellenirken kasa hareketi senkronize değildi | masraf/update.php | Tutar farkı senkron |
| **#019** | Paralel ödeme race condition (çift düşüm riski) | masraf/ode.php + paydas/komisyon-ode.php | FOR UPDATE lock |
| **#020** | Kapanmış dosyaya masraf/evrak eklenebiliyordu | masraf/create.php + evrak/upload.php | Aşama kontrolü |
| **#021** | KAPANDI'dan AÇIK'a geri dönüş engelliydi | dosya/update.php | Sadece admin |
| **#022** | İçtihat sayfası yetki kontrolü yoktu | js/pages/ictihat.js | Yetki kapısı |
| **#024** | evrak/diagnose hardcoded backdoor key | evrak/diagnose.php | Sadece admin |
| **#025** | arama-log production'da display_errors=1 | arama-log/list.php + istatistik.php | Production-safe |

> **#023 (AI key güncellemesi)** ayrı tutuldu — yeni Anthropic + Gemini API key'leri sen verince yapılacak.

---

## 📋 ÖN HAZIRLIK

- [ ] **Veritabanı yedeği** (cPanel > phpMyAdmin > mrhasard_dosyatakip > Export > Quick > Go)
- [ ] **Sistem dosyaları yedeği** (cPanel > File Manager > sistem.mrhasardanismanlik.com > Compress)
- [ ] **Sistem boş** (kimse şu anda kullanmıyor)
- [ ] **Bu zip indirildi** (`MR_HASAR_v2.2_KRITIK_HOTFIX_2026-05-03.zip`)

---

## 🎯 KURULUM ADIMLARI

### ADIM 1 — DOSYA YAMASINI YÜKLE

**Yer:** cPanel > File Manager > **sistem.mrhasardanismanlik.com**

1. Sol menüden `sistem.mrhasardanismanlik.com` klasörüne tıkla
2. Üst menüde **Yükle** (Upload)
3. ZIP'i seç: `MR_HASAR_v2.2_KRITIK_HOTFIX_2026-05-03.zip`
4. ZIP'e sağ tık > **Extract**
5. **Hedef:** Aynı klasör (sistem.mrhasardanismanlik.com)
6. **"Replace existing files"** sorusuna **EVET** / **YES** / **Replace All**
7. ZIP'i sil
8. `YUKLENECEK_DOSYALAR/` klasörü oluştuysa → içindekileri ana klasöre **TAŞI** > "Replace All"
9. `YUKLENECEK_DOSYALAR/` ve `KURULUM_KILAVUZU.md` dosyalarını sil

### Yüklenen Dosyalar

```
api/v1/masraf/create.php       ← #020 kapanmış dosya engeli
api/v1/masraf/delete.php       ← #017 kasa rollback
api/v1/masraf/ode.php          ← #019 FOR UPDATE
api/v1/masraf/update.php       ← #018 kasa senkron
api/v1/paydas/komisyon-ode.php ← #019 FOR UPDATE
api/v1/evrak/upload.php        ← #020 kapanmış dosya engeli
api/v1/evrak/diagnose.php      ← #024 backdoor kaldırıldı
api/v1/dosya/update.php        ← #021 KAPANDI geri açma engeli
api/v1/arama-log/list.php      ← #025 display_errors kapalı
api/v1/arama-log/istatistik.php← #025 display_errors kapalı
js/pages/ictihat.js            ← #022 yetki kapısı
```

**Toplam: 11 dosya**

---

### ADIM 2 — TARAYICI CACHE TEMİZLE

JS değiştiği için zorunlu.

1. **Ctrl + Shift + Delete**
2. Zaman: **Tüm zamanlar**
3. İşaretle: **Önbelleğe alınmış görüntüler ve dosyalar**
4. **Verileri Temizle**

---

### ADIM 3 — TEST

#### Test 1 — Login + Genel Kontrol
- `https://sistem.mrhasardanismanlik.com/`
- Login normal çalışıyor mu?
- Dashboard açılıyor mu?
- Konsol (F12) hatasız mı?

#### Test 2 — Masraf Silme + Kasa Rollback (#017)
1. Bir dosyaya masraf ekle (örn. 100 TL eksper ücreti)
2. Masrafı **öde** (kasa bakiyesi 100 TL düşer)
3. Kasaya bak: bakiye düştü ✓
4. Aynı masrafı **sil**
5. Kasaya tekrar bak: bakiye **100 TL geri yüklenmiş** olmalı ✓
6. Kasa hareketleri'nde "MASRAF SİLİNDİ" iptal kaydı görünmeli ✓

#### Test 3 — Masraf Güncellemede Senkron (#018)
1. Bir masraf ekle ve **öde** (örn. 500 TL)
2. Aynı masrafı düzenle, tutarı **300 TL'ye düşür**
3. Kasaya bak: bakiye **200 TL artmış** olmalı (fark 200) ✓
4. Kasa hareketleri'nde "MASRAF GÜNCELLEME" düzeltme kaydı ✓

#### Test 4 — Kapanmış Dosyaya Masraf Engeli (#020)
1. Bir dosyayı kapat (DOSYA KAPANDI aşaması)
2. Aynı dosyaya masraf ekle dene → personel hesabıyla
3. Beklenen: **403 — "Kapanmış dosyaya masraf ekleme yetkisi sadece admin için verilmiştir"** ✓
4. Admin hesabıyla denersen geçer (admin'in yetkisi var)

#### Test 5 — KAPANDI'dan AÇIK'a Geri Dönüş Engeli (#021)
1. Kapanmış dosyada aşamayı tekrar "DOSYA AÇIK" yapmaya çalış (personel hesabı)
2. Beklenen: **403 — "Kapanmış dosyayı yeniden açma yetkisi sadece admin için verilmiştir"** ✓
3. Admin hesabıyla denersen geçer

#### Test 6 — İçtihat Yetki Kapısı (#022)
1. Yetkisiz bir personel hesabıyla giriş yap
2. İçtihat menüsüne tıkla
3. Beklenen: **🔒 YETKİSİZ ERİŞİM** kutusu, "Ana Sayfaya Dön" butonu ✓
4. Admin'le aynı sayfa açılır (yetki var)

#### Test 7 — Diagnose Backdoor Kaldırıldı (#024)
Tarayıcıda aç:
```
https://sistem.mrhasardanismanlik.com/api/v1/evrak/diagnose.php?key=mrhasar2025
```
Beklenen: **Yetki hatası** (artık key çalışmıyor) ✓

Admin login'liyken aynı URL açıldığında diagnose verileri gelmeli ✓

#### Test 8 — Arama Log Production-Safe (#025)
F12 > Network > arama-log/list.php çağrısının response'una bak:
- Hata olsa bile **stack trace görünmeyecek**, sadece "Sunucu hatası" döner ✓

---

## 🚨 SORUN ÇIKARSA

| Belirti | Olası Sebep | Çözüm |
|---|---|---|
| Masraf ödeme "409 başka işlemle ödendi" | Race condition test sırasında çakışma — normal | Sayfayı yenile, tekrar dene |
| Masraf silmede 500 hatası | kasa_hareketleri INSERT şema farkı | `error_log` kontrol et — silme yine olur, sadece hareket kaydı yazılmamış olabilir |
| İçtihat sayfası admin'e de "yetkisiz" diyor | hasYetki fonksiyonu admin için true dönmüyor | Konsol'da `MR.hasYetki(user, 'ictihat', 'goruntule')` kontrol |
| Diagnose admin'le açılmıyor | JWT auth probleminden | Önce `/api/v1/auth/me.php` ile rolünü kontrol |

### Geri Alma (Rollback)

Sorun olursa:
1. Yedek ZIP'ini extract et
2. Etkilenen dosyaları yedekten geri yükle:
   - api/v1/masraf/{create,delete,ode,update}.php
   - api/v1/paydas/komisyon-ode.php
   - api/v1/evrak/{upload,diagnose}.php
   - api/v1/dosya/update.php
   - api/v1/arama-log/{list,istatistik}.php
   - js/pages/ictihat.js
3. Cache temizle, login dene

---

## 📊 BU YAMADA NELER ÇÖZÜLDÜ

| # | Konu | Risk | Süre |
|---|---|---|---|
| #017 | Masraf delete kasa rollback | 🟢 Sıfır | 30 dk |
| #018 | Masraf update kasa senkron | 🟢 Düşük | 45 dk |
| #019 | Paralel ödeme FOR UPDATE | 🟢 Düşük | 30 dk |
| #020 | Kapanmış dosya masraf/evrak engeli | 🟢 Düşük | 30 dk |
| #021 | KAPANDI geri açma admin'e bağlı | 🟢 Düşük | 30 dk |
| #022 | İçtihat yetki kapısı | 🟢 Çok düşük | 30 dk |
| #024 | Backdoor key kaldırıldı | 🟢 Düşük | 10 dk |
| #025 | arama-log production-safe | 🟢 Sıfır | 5 dk |

**Toplam: 8 madde tamam** 🎯

---

## 📞 DOĞRULAMA

Yamayı bitirdiğinde şu 3 şeyi yaz bana:

1. ✅ "Login + dashboard normal"
2. ✅ "Masraf sil-test çalıştı (kasa rollback OK)"
3. ✅ "İçtihat yetkisiz hesapla 'YETKİSİZ ERİŞİM' gösterdi"

Hata varsa hata mesajını / ekran görüntüsünü paylaş.

---

**HAZIR! Adımları sırasıyla uygula. Bu pakette SQL migration YOK — sadece dosya yükleme.**
