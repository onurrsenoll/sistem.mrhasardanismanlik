<?php
/**
 * PUT /api/v1/masraf/update.php
 * Masraf kaydini guncelle (tutar, masraf_kalemi, aciklama)
 *
 * v2.2 #018 fix:
 *   Tutar değişiminde kasa hareketleri senkronize edilir.
 *   Eski tutar 5000, yeni tutar 3000 ise → kasa bakiyesine 2000 iade,
 *   kasa_hareketleri'ne fark hareketi yazılır.
 */
require_once __DIR__ . '/../../config/helpers.php';
require_once __DIR__ . '/../../config/auth.php';

setup_headers();
require_method('PUT');

$user = auth_required();
if (!has_yetki($user, 'dosya', 'dosya-masraf-duzenle')) {
    json_error('Bu islem icin yetkiniz bulunmamaktadir', 403);
}

$body = get_json_body();
require_fields($body, ['id']);

$db = getDB();
$id = (int)$body['id'];

$stmt = $db->prepare('SELECT * FROM masraflar WHERE id = ?');
$stmt->execute([$id]);
$masraf = $stmt->fetch();
if (!$masraf) json_error('Masraf bulunamadi', 404);

$sets = [];
$params = [];
$tutarFarki = 0.0;
$tutarDegisti = false;

if (isset($body['tutar'])) {
    $yeniTutar = (float)$body['tutar'];
    if ($yeniTutar < 0) json_error('Tutar 0 dan kucuk olamaz', 422);
    $eskiTutar = (float)$masraf['tutar'];
    $tutarFarki = $eskiTutar - $yeniTutar; // pozitifse kasa'ya iade, negatifse kasa'dan ek düş
    $tutarDegisti = abs($tutarFarki) > 0.01;
    $sets[] = 'tutar = ?';
    $params[] = $yeniTutar;
}

if (isset($body['masraf_kalemi'])) {
    $sets[] = 'masraf_kalemi = ?';
    $params[] = clean($body['masraf_kalemi']);
}

if (isset($body['aciklama'])) {
    $sets[] = 'aciklama = ?';
    $params[] = clean($body['aciklama']);
}

if (empty($sets)) json_error('Guncellenecek alan yok', 422);

try {
    $db->beginTransaction();

    $params[] = $id;
    $stmt = $db->prepare('UPDATE masraflar SET ' . implode(', ', $sets) . ' WHERE id = ?');
    $stmt->execute($params);

    // ═══ v2.2 #018: ÖDENMİŞSE KASA HAREKETİ SENKRONİZE ET ═══
    $odemeDurumu = $masraf['odeme_durumu'] ?? 'odenmedi';
    $kasaId = !empty($masraf['kasa_id']) ? (int)$masraf['kasa_id'] : 0;

    if ($tutarDegisti && $odemeDurumu === 'odendi' && $kasaId > 0) {
        // Kasa bakiyesini fark kadar düzelt (pozitif fark = kasa'ya iade)
        $db->prepare('UPDATE kasalar SET bakiye = bakiye + ? WHERE id = ?')
           ->execute([$tutarFarki, $kasaId]);

        // Kasa hareket geçmişine düzeltme kaydı yaz
        try {
            $hareketTipi = $tutarFarki > 0 ? 'gelir' : 'gider';
            $hareketTutar = abs($tutarFarki);
            $aciklama = "MASRAF GÜNCELLEME - " . ($masraf['masraf_kalemi'] ?? 'Masraf') . " (eski: " . number_format((float)$masraf['tutar'], 2) . " TL, yeni: " . number_format((float)$body['tutar'], 2) . " TL)";
            $db->prepare("INSERT INTO kasa_hareketleri (kasa_id, dosya_id, tutar, hareket_tipi, aciklama, kullanici_id, islem_tarihi)
                          VALUES (?, ?, ?, ?, ?, ?, NOW())")
               ->execute([$kasaId, $masraf['dosya_id'] ?? null, $hareketTutar, $hareketTipi, $aciklama, $user['id']]);
        } catch (\Exception $e) {
            error_log('[mr_hasar v2.2] masraf update kasa_hareketleri INSERT: ' . $e->getMessage());
        }
    }

    $db->commit();
} catch (Exception $e) {
    $db->rollBack();
    json_error('Guncelleme hatasi: ' . $e->getMessage(), 500);
}

log_action($user['id'], 'masraf_guncelle', "Masraf guncellendi ID:$id - Dosya:{$masraf['dosya_id']}" . ($tutarDegisti && $odemeDurumu === 'odendi' ? " (v2.2 fix: kasa senkronize)" : ""), 'masraflar', $id);

json_success(null, 'Masraf guncellendi');
