# MR HASAR — v2.1 GÜVENLİK YAMASI KURULUM KILAVUZU
**Tarih:** 02 Mayıs 2026
**Hedef:** sistem.mrhasardanismanlik.com (canlı)
**Tahmini süre:** 15-20 dakika

---

## 📋 ÖN HAZIRLIK KONTROL LİSTESİ

Kuruluma başlamadan önce ✅ koy:

- [ ] **Veritabanı yedeği alındı** (phpMyAdmin > mrhasard_dosyatakip > Export > Quick > Go)
- [ ] **Sistem dosyaları yedeği alındı** (cPanel > File Manager > sistem.mrhasardanismanlik.com > Compress)
- [ ] **Sistem boş** (kimse şu anda kullanmıyor)
- [ ] **Bu ZIP indirildi** (`MR_HASAR_v2.1_GUVENLIK_FINAL_2026-05-02.zip`)

---

## 🎯 KURULUM ADIMLARI (SIRASIYLA)

### ADIM 1 — SQL MİGRATION ÇALIŞTIR (3 dakika)

**Yer:** cPanel > phpMyAdmin > sol menüden **`mrhasard_dosyatakip`** seç

1. Sol menüden `mrhasard_dosyatakip` veritabanına tıkla
2. Üst menüde **SQL** sekmesine tıkla
3. ZIP içindeki `migrations/2026_04_29_security_safety.sql` dosyasının **TAMAMINI kopyala**
4. SQL kutusuna **yapıştır**
5. Sağ altta **Go** (Git) butonuna bas
6. Ekranda yeşil "✓ Sorgu başarılı" gibi mesaj görmelisin

**Bu adımda neler eklenir:**
- `dosyalar` tablosuna `silindi`, `silinme_tarihi`, `silen_kullanici_id` kolonları
- `oturumlar` tablosu (logout blacklist için)
- `refresh_tokens` tablosu (token rotation için)
- `magdurlar`, `araclar`, `masraflar`, `evraklar` FK CASCADE → RESTRICT

**Hata olursa:** "Duplicate column" veya "Table already exists" görürsen sorun değil — `IF NOT EXISTS` ile korunmuş, geç.

---

### ADIM 2 — DOSYA YAMASINI YÜKLE (5 dakika)

**Yer:** cPanel > File Manager > **sistem.mrhasardanismanlik.com** klasörü

1. Sol menüden `sistem.mrhasardanismanlik.com` klasörüne tıkla
2. Üst menüde **Yükle** (Upload) butonuna bas
3. ZIP'in **TAMAMINI** yükle (`MR_HASAR_v2.1_GUVENLIK_FINAL_2026-05-02.zip`)
4. Yükleme bittikten sonra sayfayı yenile (Reload)
5. Yüklenen ZIP'e sağ tık > **Extract** (Çıkar)
6. **HEDEF YOL:** `/home/.../sistem.mrhasardanismanlik.com` (yani bulunduğun yer)
7. ⚠️ **"Replace existing files"** sorusu gelirse **EVET / Yes / Replace** seç
8. Çıkarma bittiğinde ZIP'i sil (artık gerek yok)

**Yüklenecek dosyalar (otomatik üzerine yazılır):**
```
api/v1/auth/login.php          ← güncellendi (oturum kayıt + refresh token)
api/v1/auth/logout.php         ← güncellendi (oturum iptal)
api/v1/auth/refresh.php        ← yeni (token yenileme)
api/v1/dosya/list.php          ← güncellendi (silindi=0 filtresi)
api/v1/dosya/get.php           ← güncellendi
api/v1/dosya/delete.php        ← güncellendi (UPDATE silindi=1)
api/v1/dosya/restore.php       ← yeni (geri yükleme)
api/config/database.php        ← güncellendi (.env desteği)
api/config/auth.php            ← güncellendi (jti, session, refresh)
api/config/bootstrap.php       ← yeni (env yükleyici, hata kontrolü)
api/config/env.php             ← yeni (.env okuyucu)
api/config/helpers.php         ← güncellendi
api/config/.env.example        ← yeni (env örneği)
api/config/.htaccess           ← yeni (env web koruması)
api/.htaccess                  ← yeni (api genel koruma)
helpers.php                    ← güncellendi
js/app.js                      ← güncellendi (refresh token)
js/components.js               ← güncellendi
js/config.js                   ← güncellendi
```

---

### ADIM 3 — `.env` DOSYASINI OLUŞTUR (2 dakika)

**Yer:** cPanel > File Manager > sistem.mrhasardanismanlik.com / **api/config/**

1. `api/config/` klasörüne gir
2. `.env.example` dosyasını **kopyala**
3. Kopyayı **yeniden adlandır:** `.env.example` → `.env` (başında nokta var, dikkat!)
4. `.env` dosyasını **Code Editor** ile aç (HTML Düzenleyici DEĞİL)
5. İçeriği şu şekilde doldur:

```ini
# === VERİTABANI ===
DB_HOST=localhost
DB_NAME=mrhasard_dosyatakip
DB_USER=mrhasard_dtuser
DB_PASS=MrHasar2025!

# === JWT ===
# Aşağıdaki satırı 64 karakterlik rastgele bir dizeyle değiştir
# (cPanel Terminal varsa: openssl rand -hex 64)
# YOKSA: bana sor, ben sana üreteyim
JWT_SECRET=BURAYA_64_KARAKTER_RASTGELE_DİZE
JWT_EXPIRE=86400
JWT_REFRESH_EXPIRE=2592000

# === ORTAM ===
APP_ENV=production
ERROR_LOG_PATH=
```

6. **DB şifresi:** Mevcut `database.php`'deki `MrHasar2025!` aynısı (zaten yazılı)
7. **JWT_SECRET:** Aşağıdaki KRİTİK NOT'a bak

#### 🔑 KRİTİK NOT — JWT_SECRET üretimi

JWT_SECRET, kullanıcı oturumlarını imzalayan gizli anahtardır. **Mutlaka uzun ve rastgele olmalı.**

**Yöntem A — cPanel Terminal varsa:**
```bash
openssl rand -hex 64
```
Çıkan dizeyi `JWT_SECRET=` satırına yapıştır.

**Yöntem B — Online araç:**
- https://generate-random.org/api-token-generator > Hex 64 karakter > Generate

**Yöntem C — Bana sor:**
> "JWT_SECRET üret bana"

Yazarsan ben sana 64 karakterlik bir tane veririm.

8. Kaydet (Save Changes)

---

### ADIM 4 — `.env` GÜVENLİK TESTİ (1 dakika)

**MUTLAKA YAPILMALI** — `.env` dosyası web'den erişilebilir olmamalı.

Tarayıcıda aç:
```
https://sistem.mrhasardanismanlik.com/api/config/.env
```

**Beklenen sonuç:** **`403 Forbidden`** sayfası

**Eğer `.env` içeriği görünüyorsa:** ⚠️ DUR. Bu kritik bir güvenlik açığı.
- `api/config/.htaccess` dosyası gerçekten o klasörde mi kontrol et
- O dosya kopyalanmadıysa elle oluştur (içeriği aşağıda)
- Yine olmuyorsa bana yaz, çözeriz

---

### ADIM 5 — TARAYICI CACHE TEMİZLE VE LOGİN (2 dakika)

1. Tarayıcıda **Ctrl + Shift + Delete** (cache temizle)
2. Tüm zamanlar / Cached images and files işaretle / Clear data
3. `https://sistem.mrhasardanismanlik.com/` aç
4. **Login ekranı gelmeli** (eski oturumun JWT_SECRET değiştiği için iptal oldu)
5. E-posta + şifre ile yeniden giriş yap
6. Dashboard açılırsa ✅ **YAMA BAŞARILI**

---

### ADIM 6 — DOĞRULAMA TESTLERİ (5 dakika)

Aşağıdaki testleri tek tek yap:

#### Test 1 — Dosya Açma
- [ ] Dosyalar listesini aç → eskiden olan dosyalar görünüyor
- [ ] Bir dosyaya tıkla → detayı açılıyor
- [ ] Detayda mağdur, araç, masraf, evrak sekmeleri çalışıyor

#### Test 2 — Dosya Silme (Soft-Delete)
- [ ] Bir dosyayı sil
- [ ] Listede artık görünmüyor
- [ ] phpMyAdmin'de DB'de o satır hâlâ duruyor (`silindi=1` olmuş olmalı)

#### Test 3 — Logout/Login
- [ ] Sağ üstten çıkış yap
- [ ] Tekrar login → çalışıyor

#### Test 4 — Refresh Token
- [ ] F12 > Application > Local Storage > `mr_token` ve `mr_refresh_token` görünüyor
- [ ] mr_token'ı sil > sayfa yenile > otomatik yeniden giriş yapmalı (refresh ile)

#### Test 5 — `.env` Koruması
- [ ] `https://.../api/config/.env` → 403 Forbidden ✅
- [ ] `https://.../api/config/.htaccess` → 403 Forbidden ✅

---

## 🚨 SORUN ÇIKARSA

| Belirti | Olası Sebep | Çözüm |
|---|---|---|
| Login ekranı gelmiyor, beyaz sayfa | JWT_SECRET hatalı | `.env`'de JWT_SECRET'i kontrol et |
| "Veritabanı bağlantı hatası" | DB_PASS yanlış | `.env`'deki DB_PASS = `MrHasar2025!` mi? |
| Dosya silmek hata veriyor | FK RESTRICT + eski delete kalmış | yamayı eksiksiz yükle, delete.php yeni mi kontrol et |
| `.env` web'den okunabiliyor | .htaccess yok | `api/config/.htaccess` dosyasını manuel oluştur |
| Personel "sistem bozuldu" diyor | Eski JS cache | Ctrl+Shift+Delete cache temizle |

---

## 🔄 GERİ ALMA (ROLLBACK) — Sorun Olursa

Eğer bir şey ciddi yanlış giderse:

### 1. Dosya yedeğini geri yükle
- File Manager > daha önce aldığın yedek ZIP'i extract et
- Mevcut dosyaların üzerine yaz

### 2. DB yedeğini geri yükle
- phpMyAdmin > mrhasard_dosyatakip > Operations > Drop
- Yeni boş DB oluştur (aynı isim)
- Import > daha önce aldığın .sql yedeği

### 3. Tüm session'ları temizle
- Tarayıcı cache temizle
- Yeniden login

---

## 📞 SON KONTROL — Bana Bildirilecekler

Yamayı bitirdiğinde şu 3 şeyi bana yaz:

1. ✅ "Login başarılı oldu, dashboard açıldı"
2. ✅ "Dosya silme çalıştı (soft-delete oldu, DB'de duruyor)"
3. ✅ ".env dosyası 403 dönüyor"

Sorun olduğunda hata kodunu / ekran görüntüsünü paylaş.

---

**HAZIR! Adımları sırasıyla uygula, her adımda dur ve bir sonrakine geç. Acele etme.**
