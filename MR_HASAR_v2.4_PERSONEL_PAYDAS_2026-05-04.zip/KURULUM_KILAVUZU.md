# MR HASAR — v2.4 PERSONEL + PAYDAŞ MODÜLÜ KURULUM KILAVUZU
**Tarih:** 04 Mayıs 2026
**Hedef:** sistem.mrhasardanismanlik.com
**Tahmini süre:** 15 dakika

---

## 📦 BU PAKET NE GETİRİYOR

### A. PERSONEL MODÜLÜ — Kapsamlı Yenileme
1. **Kazanç Modeli Sistemi** (her personele özel)
   - **Sabit** maaş
   - **Sabit + Prim** (basit prim_adk/prim_bh)
   - **Kademeli SAHA** (Sercan tipi: 1-10/11-15/16-20/21+)
   - **Kademeli OFİS** (ADK + BH ayrı kademe + kota sistemi)
   - **Yıllık Bonus** (Bronz/Gümüş/Altın eşikleri)
2. **Otomatik Prim Kayıtları** — dosya açılınca personel_prim_kayitlari'na kayıt
3. **Personel Kart Modal** (5 sekme):
   - Genel Bilgiler · Kazanç Modeli · Cari Hesap · Ödemeler · Evraklar
4. **Cari Hesap Dökümü** — bekleyen primler + hakediş + ödeme akışı
5. **Ödeme Sistemi** — maaş/prim/avans/ikramiye/mesai/diğer + PDF dekont
6. **Evrak Yönetimi** — sözleşme + dekont + KVKK + araç zimmet (PDF/JPG)

### B. PAYDAŞ MODÜLÜ — Yenileme
1. **Otomatik Ödendi** — dosya açılınca paydaş yönlendiren ücreti ÖDENDİ olarak işaretlenir
2. **Varsayılan Kasa** — sistem ayarından `varsayilan_paydas_kasa_id` ile kasa düşümü otomatik
3. **Paydaş Kart Modal** (3 sekme):
   - Genel · Cari Hesap · Evraklar
4. **Evrak Yönetimi** — sözleşme + dekont (PDF/JPG)
5. **Cari Hesap** — komisyon geçmişi + ödeme durumları

---

## 📋 ÖN HAZIRLIK

- [ ] **Veritabanı yedeği** (cPanel > phpMyAdmin > Export)
- [ ] **Sistem dosyaları yedeği** (Compress sistem.mrhasardanismanlik.com)
- [ ] **Sistem boş** (kimse kullanmıyor — uzun yama)
- [ ] **Bu zip indirildi:** `MR_HASAR_v2.4_PERSONEL_PAYDAS_2026-05-04.zip`

---

## 🎯 KURULUM ADIMLARI (SIRASIYLA)

### ADIM 1 — SQL MIGRATION ÇALIŞTIR (3 dakika)

**Yer:** cPanel > phpMyAdmin > **`mrhasard_dosyatakip`** > **SQL** sekmesi

1. ZIP'i bilgisayara aç, `SQL/01_personel_paydas_tablolar.sql` dosyasını aç
2. İçeriğin **TAMAMINI kopyala** (yorum satırları dahil)
3. phpMyAdmin SQL kutusuna **yapıştır**
4. Sağ altta **Go** > Yeşil "Sorgu başarılı" mesajı

**Eklenenler:**
- 5 yeni tablo: `personel_kazanc_modelleri`, `personel_prim_kayitlari`, `personel_odemeler`, `personel_evraklari`, `paydas_evraklari`
- `paydas_komisyonlari.evrak_id` kolonu (varsa atla)
- `ayarlar` tablosuna `varsayilan_paydas_kasa_id` anahtarı

> **Hata:** "Duplicate column" / "Table already exists" → sorun değil, `IF NOT EXISTS` ile korunmuş

---

### ADIM 2 — DOSYA YAMASINI YÜKLE (5 dakika)

**Yer:** cPanel > File Manager > **`sistem.mrhasardanismanlik.com`**

1. ZIP'i klasöre yükle
2. ZIP'e sağ tık > **Extract** > Hedef: aynı klasör
3. **"Replace existing"** sorusuna **YES / Hepsini Değiştir**
4. ZIP'i sil
5. `YUKLENECEK_DOSYALAR/` klasörü oluştuysa → içindekileri ana klasöre **TAŞI**

**Yüklenecek dosyalar (22 adet):**

| Yol | Açıklama |
|---|---|
| `api/v1/dosya/create.php` | **Güncel** — personel prim otomatik + paydaş otomatik ödendi |
| `api/v1/personel/hakedis-hesapla.php` | **Güncel** — kademeli motor entegrasyonu |
| `api/v1/personel/hakedis-motor.php` | **Yeni** — kazanç modeli motoru (helper) |
| `api/v1/personel/cari-hesap.php` | **Yeni** — cari hesap dökümü |
| `api/v1/personel/odeme-yap.php` | **Yeni** — maaş/prim/avans ödeme |
| `api/v1/personel/evrak-yukle.php` | **Yeni** — sözleşme/dekont yükleme |
| `api/v1/personel/evrak-list.php` | **Yeni** — evrak listesi |
| `api/v1/personel/evrak-indir.php` | **Yeni** — önizleme/indirme |
| `api/v1/personel/evrak-sil.php` | **Yeni** — evrak silme |
| `api/v1/personel/kazanc-modeli-get.php` | **Yeni** — model getirme + şablonlar |
| `api/v1/personel/kazanc-modeli-set.php` | **Yeni** — model kaydetme |
| `api/v1/paydas/cari-hesap.php` | **Yeni** — paydaş cari |
| `api/v1/paydas/evrak-yukle.php` | **Yeni** |
| `api/v1/paydas/evrak-list.php` | **Yeni** |
| `api/v1/paydas/evrak-indir.php` | **Yeni** |
| `api/v1/paydas/evrak-sil.php` | **Yeni** |
| `js/config.js` | **Güncel** — 14 yeni API endpoint binding |
| `js/pages/personel.js` | **Güncel** — tıklama → kart modal |
| `js/pages/ortaklar.js` | **Güncel** — paydaş satır → kart modal |
| `js/pages/kart-modulleri.js` | **Yeni** — PersonelKartModal + PaydasKartModal bileşenleri |
| `index.html` | **Güncel** — kart-modulleri.js script tag eklendi |

---

### ADIM 3 — VARSAYILAN PAYDAŞ KASASI TANIMLA (2 dakika)

Sistemin paydaş otomatik ödeme yapacağı **MR ANA KASA**'yı tanımlamak için:

1. cPanel > phpMyAdmin > `mrhasard_dosyatakip` > SQL
2. Önce kasanın ID'sini bul:
   ```sql
   SELECT id, ad FROM kasalar WHERE aktif = 1;
   ```
3. **MR ANA KASA**'nın ID'sini al (örn. 1)
4. Sistem ayarına yaz:
   ```sql
   UPDATE ayarlar SET deger = '1' WHERE anahtar = 'varsayilan_paydas_kasa_id';
   ```
   (1 yerine kendi MR ANA KASA ID'ni yaz)

> **Boş bırakırsan:** Paydaş ödeme sembolik olur (kasa hareketi yazılmaz). Test için boş bırakabilirsin, prod için MUTLAKA ID gir.

---

### ADIM 4 — TARAYICI CACHE TEMİZLE

JS değişti, zorunlu:
1. **Ctrl + Shift + Delete** > Tüm zamanlar > Cache + Çerezler > Verileri Temizle

---

### ADIM 5 — TEST (5 dakika)

#### Test 1 — Personel Kart Modal Açılışı
1. **Sistem > Personel** sayfasına gir
2. Bir personel satırına **tıkla**
3. **Kart modal açılmalı** (eskiden direkt düzenleme açılıyordu) ✓
4. 5 sekme görünüyor: Genel · Kazanç Modeli · Cari · Ödemeler · Evraklar

#### Test 2 — Kazanç Modeli Tanımlama (Sercan örneği)
1. Personel kartında **KAZANÇ MODELİ** sekmesi
2. **"Saha — Sercan Tipi (40K + Kademeli)"** şablonuna tıkla
3. Form otomatik dolacak (40.000 TL maaş + kademe tablosu + bonus)
4. **KAYDET** > "Kazanç modeli kaydedildi" toast ✓
5. Tekrar aç → Aktif Model: kademeli_saha · 40.000 TL ✓

#### Test 3 — Personel Otomatik Prim Kaydı
1. **Yeni Dosya Aç** > Sorumlu olarak yukarıdaki personeli seç (örn. ADK türü)
2. Dosyayı **KAYDET**
3. phpMyAdmin SQL:
   ```sql
   SELECT * FROM personel_prim_kayitlari WHERE personel_id = X ORDER BY id DESC LIMIT 5;
   ```
4. Yeni "bekliyor" satırı görmelisin ✓

#### Test 4 — Paydaş Otomatik Ödeme
1. **Yeni Dosya Aç** > Paydaş seç (örn. Mahir Kol veya başka aktif paydaş)
2. Dosyayı **KAYDET**
3. phpMyAdmin SQL:
   ```sql
   SELECT id, paydas_id, dosya_id, tutar, durum, odeme_tarihi
   FROM paydas_komisyonlari ORDER BY id DESC LIMIT 5;
   ```
4. Son satır **`durum='odendi'`** + odeme_tarihi=bugün olmalı ✓
5. Eğer `varsayilan_paydas_kasa_id` doluysa → kasada bakiye düşmüş olmalı

#### Test 5 — Hakediş Hesaplama
1. Personel sayfası > **HAKEDİŞ** sekmesi (mevcut)
2. **Bu Ay Hesapla** butonuna bas (mevcut yapı)
3. Yeni motor kademeli formülü uygulayacak
4. Hesaplama sonucu doğru mu kontrol et (örn. 5 dosyalık personelden 0 prim, 15 dosyalıdan 15×2.500=37.500)

#### Test 6 — Personel Ödeme + Dekont
1. Personel kartı > **ÖDEMELER** sekmesi
2. **+ YENİ ÖDEME YAP** > Maaş, 40000, Kasa seç > KAYDET
3. Toast "Ödeme başarıyla yapıldı" ✓
4. **EVRAKLAR** sekmesi > **+ EVRAK YÜKLE** > Maaş Dekontu seç + PDF yükle
5. Evrak listede görünmeli, **ÖNİZLE** butonuyla açılmalı ✓

#### Test 7 — Paydaş Kart + Evrak
1. **Sistem > Paydaşlar** > satıra tıkla
2. Kart açılmalı, 3 sekme görünmeli ✓
3. **CARİ HESAP** > komisyonlar listesi (Test 4'teki ÖDENDİ olanı görmelisin) ✓
4. **EVRAKLAR** > PDF yükle > listele/önizle ✓

---

## 🚨 SORUN ÇIKARSA

| Belirti | Olası Sebep | Çözüm |
|---|---|---|
| Personel sayfasında tıklama hala düzenleme açıyor | Eski JS cache | Ctrl+Shift+Delete |
| Personel kartında "kart-modulleri.js bulunamadı" konsol | index.html güncellenmemiş | yeni index.html'i tekrar yükle |
| Hakediş hesaplama eski sistem | hakedis-motor.php yüklenmedi | dosyayı kontrol et |
| Paydaş ödeme "ödenmedi" görünüyor | Eski cache veya dosya/create.php eski | tarayıcı cache + create.php yeniden yükle |
| SQL hata "evrak_id duplicate" | Migration tekrar çalıştı | sorun değil, geç |
| "Yetki yok" hatası | Personel-cari-hesap için muhasebe yetkisi yok | admin hesabıyla dene |

---

## 📊 BU YAMADA NELER ÇÖZÜLDÜ

| Sorun | Durum |
|---|---|
| Personel primi DB'ye yazılmıyordu | ✅ personel_prim_kayitlari otomatik |
| Paydaş yönlendiren ücreti "bekleyen" görünüyordu | ✅ Otomatik ÖDENDİ |
| Personel listesi tıklama düzenleme açıyordu | ✅ Kart modal |
| Personel cari hesap dökümü yoktu | ✅ Yeni endpoint + sekme |
| Personel ödeme türü ayrımı yoktu | ✅ Maaş/prim/avans/ikramiye/mesai/diğer |
| Personel PDF evrak yükleme yoktu | ✅ Sözleşme dahil tüm evraklar |
| Sercan tipi kademeli prim sistemi yoktu | ✅ Esnek kazanç modeli (4 tip) |
| Yıllık bonus sistemi yoktu | ✅ Bronz/Gümüş/Altın eşikleri |
| Paydaş kart yoktu | ✅ Modal + 3 sekme |
| Paydaş PDF evrak yoktu | ✅ Sözleşme + dekont |

**Toplam: 10 büyük iyileştirme** 🎯

---

## 📞 DOĞRULAMA

Yamayı bitirdiğinde şu 4 şeyi yaz bana:

1. ✅ "Personel kartı tıklayınca açıldı, 5 sekme görünüyor"
2. ✅ "Sercan şablonunu uyguladım, kazanç modeli kaydedildi"
3. ✅ "Yeni dosya açtım, paydaş otomatik ÖDENDİ olarak yazıldı"
4. ✅ "Ödeme yaptım + PDF dekont yükledim, önizleme çalıştı"

Sorun olduğunda hata mesajını/konsol çıktısını paylaş.

---

## 🔮 SONRAKI ADIMLAR

Bu yama sonrası bekleyen işler:
- **v2.5** — NetSantral autocall karar (frontend kaldır VEYA backend yap)
- **v2.5** — Babel CDN local'a alma (ben js/dist/ derleyeceğim)
- **v3.0** — Dosya Kapanış Modülü (Madde 5.4 entegrasyonu — Demirhan toplantısı sonrası)
- **AI key güncellemesi** — sen yeni Anthropic + Gemini key verince yapılacak
- **v2.1.1** — Çağrı widget (hafta sonu, mesai dışı)

---

**HAZIR! Adımları sırasıyla uygula. Bu pakette SQL migration ZORUNLU (Adım 1).**
