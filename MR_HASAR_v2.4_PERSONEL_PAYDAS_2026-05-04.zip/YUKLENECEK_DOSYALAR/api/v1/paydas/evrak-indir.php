<?php
/**
 * GET /api/v1/paydas/evrak-indir.php?id=X[&mode=inline]
 * Paydaş evrakını indir veya tarayıcıda önizle (mode=inline)
 *
 * NOT: Bu endpoint header'ları manuel set ediyor (binary download).
 *      setup_headers() kullanılmıyor çünkü Content-Type fark.
 */

require_once __DIR__ . '/../../config/helpers.php';
require_once __DIR__ . '/../../config/auth.php';

require_method('GET');

$user = auth_required();
$db = getDB();
$id = (int)($_GET['id'] ?? 0);
if (!$id) { http_response_code(422); echo 'ID gerekli'; exit; }

$mode = $_GET['mode'] ?? 'attachment';

$stmt = $db->prepare('SELECT * FROM paydas_evraklari WHERE id = ?');
$stmt->execute([$id]);
$evrak = $stmt->fetch();
if (!$evrak) { http_response_code(404); echo 'Evrak bulunamadı'; exit; }

$fullPath = UPLOAD_DIR . $evrak['dosya_yolu'];
if (!file_exists($fullPath)) { http_response_code(404); echo 'Dosya disk\'te bulunamadı'; exit; }

header('Content-Type: ' . ($evrak['mime_type'] ?: 'application/octet-stream'));
header('Content-Length: ' . filesize($fullPath));
header('Content-Disposition: ' . ($mode === 'inline' ? 'inline' : 'attachment') . '; filename="' . rawurlencode($evrak['dosya_adi']) . '"');
header('Cache-Control: private, max-age=300');
readfile($fullPath);
exit;
