<?php
/**
 * GET /api/v1/paydas/cari-hesap.php?id=X&donem_baslangic=YYYY-MM-DD&donem_bitis=YYYY-MM-DD
 *
 * Paydaş cari hesap dökümü:
 *   + Komisyon alacakları (paydas_komisyonlari)
 *   - Yapılmış ödemeler (durum='odendi' olanlar zaten alacak'tan düşülür)
 *
 * NOT: Paydaş kazanç sistemi personelden farklı:
 *   - Komisyon kayıtları zaten "alacak" + "ödendi" durumu içerir
 *   - Tek kalem hareket: komisyon (alacak), ödendiğinde aynı satır kapanır
 */

require_once __DIR__ . '/../../config/helpers.php';
require_once __DIR__ . '/../../config/auth.php';

setup_headers();
require_method('GET');

$user = auth_required();
$db = getDB();
$paydasId = (int)($_GET['id'] ?? 0);
if (!$paydasId) json_error('Paydaş ID gerekli', 422);

$bas = $_GET['donem_baslangic'] ?? date('Y-m-d', strtotime('-12 months'));
$son = $_GET['donem_bitis'] ?? date('Y-m-d');

$stmt = $db->prepare('SELECT id, ad, telefon FROM paydaslar WHERE id = ?');
$stmt->execute([$paydasId]);
$paydas = $stmt->fetch();
if (!$paydas) json_error('Paydaş bulunamadı', 404);

// Komisyon hareketleri
$stmt = $db->prepare("SELECT pk.*, d.dosya_no, d.dosya_turu, k.ad as kasa_adi
    FROM paydas_komisyonlari pk
    LEFT JOIN dosyalar d ON d.id = pk.dosya_id
    LEFT JOIN kasalar k ON k.id = pk.kasa_id
    WHERE pk.paydas_id = ? AND pk.tarih BETWEEN ? AND ?
    ORDER BY pk.tarih DESC");
$stmt->execute([$paydasId, $bas, $son]);
$komisyonlar = $stmt->fetchAll();

$hareketler = [];
foreach ($komisyonlar as $k) {
    $hareketler[] = [
        'tarih' => $k['tarih'],
        'tur' => 'komisyon',
        'aciklama' => "Komisyon: " . ($k['dosya_no'] ?: '#' . $k['dosya_id']) . ' (' . ($k['dosya_turu'] ?: '-') . ')' . ($k['aciklama'] ? " — {$k['aciklama']}" : ''),
        'tutar' => (float)$k['tutar'],
        'durum' => $k['durum'],
        'odeme_tarihi' => $k['odeme_tarihi'],
        'kasa_adi' => $k['kasa_adi']
    ];
}

// Özet
$toplam = array_sum(array_column($hareketler, 'tutar'));
$odenen = array_sum(array_filter(array_map(fn($h) => $h['durum'] === 'odendi' ? $h['tutar'] : 0, $hareketler)));
$bekleyen = $toplam - $odenen;

json_success([
    'paydas' => $paydas,
    'donem_baslangic' => $bas,
    'donem_bitis' => $son,
    'hareketler' => $hareketler,
    'ozet' => [
        'toplam_komisyon' => $toplam,
        'odenen' => $odenen,
        'bekleyen' => $bekleyen,
        'islem_sayisi' => count($hareketler)
    ]
]);
