<?php
/**
 * POST /api/v1/paydas/evrak-yukle.php
 * Paydaş evrakı yükle (sözleşme, dekont, vs.)
 *
 * Form Data: paydas_id, evrak_turu, evrak_etiketi, file (PDF/JPG/PNG)
 *            komisyon_id (opsiyonel — dekont için)
 *
 * Yükleme yolu: uploads/paydas/{paydas_id}/{uuid}.{ext}
 */

require_once __DIR__ . '/../../config/helpers.php';
require_once __DIR__ . '/../../config/auth.php';

setup_headers();
require_method('POST');

$user = auth_required(['admin', 'muhasebe', 'uzman']);

$paydasId = (int)($_POST['paydas_id'] ?? 0);
$evrakTuru = clean($_POST['evrak_turu'] ?? 'diger');
$evrakEtiketi = clean($_POST['evrak_etiketi'] ?? '');
$odemeId = !empty($_POST['komisyon_id']) ? (int)$_POST['komisyon_id'] : null;

if (!$paydasId) json_error('paydas_id gerekli', 422);

$db = getDB();

// Paydaş var mı
$stmt = $db->prepare('SELECT id, ad FROM paydaslar WHERE id = ?');
$stmt->execute([$paydasId]);
$paydas = $stmt->fetch();
if (!$paydas) json_error('Paydaş bulunamadı', 404);

// Dosya yüklendi mi
if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    json_error('Dosya yükleme hatası', 422);
}

$file = $_FILES['file'];
if ($file['size'] > MAX_FILE_SIZE) json_error('Dosya çok büyük (max 512MB)', 422);

$finfo = new finfo(FILEINFO_MIME_TYPE);
$mimeType = $finfo->file($file['tmp_name']);
if (!in_array($mimeType, ALLOWED_TYPES)) {
    json_error('Desteklenmeyen dosya türü', 422);
}

// UUID + uzantı
$orijinalAd = basename($file['name']);
$uuid = generate_uuid();
$extMap = ['application/pdf'=>'pdf','image/jpeg'=>'jpg','image/png'=>'png','image/svg+xml'=>'svg','application/msword'=>'doc','application/vnd.openxmlformats-officedocument.wordprocessingml.document'=>'docx'];
$ext = $extMap[$mimeType] ?? pathinfo($orijinalAd, PATHINFO_EXTENSION) ?: 'pdf';
$sunucuAdi = $uuid . '.' . $ext;

// Klasör: uploads/paydas/{paydas_id}/
$relPath = "paydas/$paydasId/";
$uploadPath = UPLOAD_DIR . $relPath;
if (!is_dir($uploadPath)) mkdir($uploadPath, 0755, true);

$fullPath = $uploadPath . $sunucuAdi;
if (!move_uploaded_file($file['tmp_name'], $fullPath)) {
    json_error('Dosya kaydedilemedi', 500);
}

// DB kayıt
$stmt = $db->prepare('INSERT INTO paydas_evraklari
    (paydas_id, komisyon_id, evrak_turu, evrak_etiketi, dosya_adi, sunucu_adi, dosya_yolu, mime_type, dosya_boyutu, yukleyen_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
$stmt->execute([
    $paydasId, $odemeId, $evrakTuru, $evrakEtiketi ?: null,
    $orijinalAd, $sunucuAdi, $relPath . $sunucuAdi,
    $mimeType, filesize($fullPath), $user['id']
]);
$evrakId = (int)$db->lastInsertId();

// Bağlı ödeme varsa evrak_id güncelle
if ($odemeId) {
    try {
        $db->prepare('UPDATE paydas_komisyonlari SET evrak_id = ? WHERE id = ? AND paydas_id = ?')
           ->execute([$evrakId, $odemeId, $paydasId]);
    } catch (\Exception $e) {}
}

log_action($user['id'], 'paydas_evrak_yukle', "{$paydas['ad']} - $orijinalAd ($evrakTuru)", 'paydas_evraklari', $evrakId);

json_success([
    'evrak_id' => $evrakId,
    'dosya_adi' => $orijinalAd,
    'boyut' => $file['size'],
    'evrak_turu' => $evrakTuru
], 'Evrak başarıyla yüklendi', 201);
