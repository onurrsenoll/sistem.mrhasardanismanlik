<?php
/**
 * GET /api/v1/paydas/evrak-list.php?id=X[&evrak_turu=sozlesme]
 * Paydaş evraklarını listele (önizleme URL'leri ile)
 */

require_once __DIR__ . '/../../config/helpers.php';
require_once __DIR__ . '/../../config/auth.php';

setup_headers();
require_method('GET');

$user = auth_required();
$db = getDB();
$paydasId = (int)($_GET['id'] ?? 0);
if (!$paydasId) json_error('Paydaş ID gerekli', 422);

$evrakTuru = !empty($_GET['evrak_turu']) ? clean($_GET['evrak_turu']) : null;

$sql = 'SELECT pe.*, u.ad as yukleyen_adi
        FROM paydas_evraklari pe
        LEFT JOIN users u ON u.id = pe.yukleyen_id
        WHERE pe.paydas_id = ?';
$params = [$paydasId];

if ($evrakTuru) {
    $sql .= ' AND pe.evrak_turu = ?';
    $params[] = $evrakTuru;
}
$sql .= ' ORDER BY pe.created_at DESC';

$stmt = $db->prepare($sql);
$stmt->execute($params);
$evraklar = $stmt->fetchAll();

// URL ekle (önizleme için)
foreach ($evraklar as &$e) {
    $e['preview_url'] = '/api/v1/paydas/evrak-indir.php?id=' . $e['id'] . '&mode=inline';
    $e['download_url'] = '/api/v1/paydas/evrak-indir.php?id=' . $e['id'];
    $e['boyut_okunabilir'] = number_format($e['dosya_boyutu'] / 1024, 1) . ' KB';
}
unset($e);

json_success($evraklar);
