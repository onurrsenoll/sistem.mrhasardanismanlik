<?php
/**
 * GET /api/v1/personel/cari-hesap.php?id=X&donem_baslangic=YYYY-MM-DD&donem_bitis=YYYY-MM-DD
 *
 * Personel cari hesap dökümü:
 *   + Bekleyen primler (personel_prim_kayitlari)
 *   + Hesaplanmış hakedişler (personel_hakedis)
 *   - Yapılmış ödemeler (personel_odemeler)
 *   = NET BAKİYE
 */

require_once __DIR__ . '/../../config/helpers.php';
require_once __DIR__ . '/../../config/auth.php';

setup_headers();
require_method('GET');

$user = auth_required();
if (!has_yetki($user, 'muhasebe', 'personel-hakedis') && ($user['rol'] ?? '') !== 'admin') {
    json_error('Yetki yok', 403);
}

$db = getDB();
$personelId = (int)($_GET['id'] ?? 0);
if (!$personelId) json_error('Personel ID gerekli', 422);

// Filtre tarihleri
$bas = $_GET['donem_baslangic'] ?? date('Y-m-01', strtotime('-12 months'));
$son = $_GET['donem_bitis'] ?? date('Y-m-t');

// Personel bilgisi
$stmt = $db->prepare('SELECT id, ad_soyad, departman FROM personel WHERE id = ?');
$stmt->execute([$personelId]);
$personel = $stmt->fetch();
if (!$personel) json_error('Personel bulunamadı', 404);

// Hareketler — UNION birleştirme
$hareketler = [];

// 1. Prim kayıtları (alacak) — bekleyen olanlar görünür
$stmt = $db->prepare("SELECT
    pk.created_at as tarih,
    pk.dosya_no,
    pk.dosya_turu,
    pk.donem,
    pk.durum,
    pk.dosya_id,
    'prim' as tur
    FROM personel_prim_kayitlari pk
    WHERE pk.personel_id = ?
      AND pk.created_at BETWEEN ? AND ?
    ORDER BY pk.created_at DESC");
$stmt->execute([$personelId, $bas . ' 00:00:00', $son . ' 23:59:59']);
foreach ($stmt->fetchAll() as $r) {
    $hareketler[] = [
        'tarih' => $r['tarih'],
        'tur' => 'prim',
        'aciklama' => "Dosya primi (#{$r['dosya_no']} - {$r['dosya_turu']}) — Durum: {$r['durum']}",
        'alacak' => 0, // Henüz hesaplanmamış, bilgi amaçlı
        'borc' => 0,
        'bakiye_etki' => 0,
        'donem' => $r['donem'],
        'durum' => $r['durum']
    ];
}

// 2. Hesaplanmış hakedişler (alacak)
try {
    $stmt = $db->prepare("SELECT id, donem, hakedis_tutar, odeme_durumu, hesaplama_tarihi
        FROM personel_hakedis WHERE personel_id = ?
        AND hesaplama_tarihi BETWEEN ? AND ?");
    $stmt->execute([$personelId, $bas, $son]);
    foreach ($stmt->fetchAll() as $r) {
        $hareketler[] = [
            'tarih' => $r['hesaplama_tarihi'],
            'tur' => 'hakedis',
            'aciklama' => "Aylık hakediş tahakkuku — {$r['donem']}",
            'alacak' => (float)$r['hakedis_tutar'],
            'borc' => 0,
            'bakiye_etki' => (float)$r['hakedis_tutar'],
            'durum' => $r['odeme_durumu']
        ];
    }
} catch (Exception $e) {}

// 3. Ödemeler (borç)
$stmt = $db->prepare("SELECT id, odeme_turu, tutar, donem, odeme_tarihi, aciklama, evrak_id
    FROM personel_odemeler
    WHERE personel_id = ? AND odeme_tarihi BETWEEN ? AND ?");
$stmt->execute([$personelId, $bas, $son]);
foreach ($stmt->fetchAll() as $r) {
    $hareketler[] = [
        'tarih' => $r['odeme_tarihi'],
        'tur' => 'odeme',
        'odeme_turu' => $r['odeme_turu'],
        'aciklama' => "Ödeme: " . strtoupper($r['odeme_turu']) . ($r['donem'] ? " ({$r['donem']})" : '') . ($r['aciklama'] ? " — {$r['aciklama']}" : ''),
        'alacak' => 0,
        'borc' => (float)$r['tutar'],
        'bakiye_etki' => -(float)$r['tutar'],
        'donem' => $r['donem'],
        'evrak_id' => $r['evrak_id']
    ];
}

// Tarih sıralı + bakiye yürüt
usort($hareketler, fn($a, $b) => strcmp($a['tarih'], $b['tarih']));
$bakiye = 0;
foreach ($hareketler as &$h) {
    $bakiye += $h['bakiye_etki'];
    $h['bakiye'] = $bakiye;
}
unset($h);
$hareketler = array_reverse($hareketler);

// Özet
$toplam_alacak = array_sum(array_column($hareketler, 'alacak'));
$toplam_borc = array_sum(array_column($hareketler, 'borc'));
$bekleyen_prim_sayisi = 0;
foreach ($hareketler as $h) {
    if ($h['tur'] === 'prim' && ($h['durum'] ?? '') === 'bekliyor') $bekleyen_prim_sayisi++;
}

json_success([
    'personel' => $personel,
    'donem_baslangic' => $bas,
    'donem_bitis' => $son,
    'hareketler' => $hareketler,
    'ozet' => [
        'toplam_alacak' => $toplam_alacak,
        'toplam_borc' => $toplam_borc,
        'net_bakiye' => $toplam_alacak - $toplam_borc,
        'bekleyen_prim_sayisi' => $bekleyen_prim_sayisi
    ]
]);
