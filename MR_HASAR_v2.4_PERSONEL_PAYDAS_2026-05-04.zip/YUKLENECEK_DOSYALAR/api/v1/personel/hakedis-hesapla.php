<?php
/**
 * POST /api/v1/personel/hakedis-hesapla.php
 * v2.4: Aylık hakediş hesapla — yeni kazanç modeli motoru kullanılır
 *
 * Body: {
 *   personel_id, donem (YYYY-MM),
 *   calisan_gun (default 22)
 * }
 *
 * Veya tüm personel için: { donem }
 */

require_once __DIR__ . '/../../config/helpers.php';
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/hakedis-motor.php';

ensure_prim_columns();

setup_headers();
require_method('POST');

$user = auth_required(['admin', 'muhasebe']);
$body = get_json_body();
require_fields($body, ['donem']);

$db = getDB();
$donem = clean($body['donem']);
$calisan_gun = isset($body['calisan_gun']) ? (int)$body['calisan_gun'] : 22;

if (!preg_match('/^\d{4}-\d{2}$/', $donem)) json_error('Geçersiz dönem formatı (YYYY-MM)', 422);

// Tek personel veya tümü
$tekPersonelId = !empty($body['personel_id']) ? (int)$body['personel_id'] : null;
if ($tekPersonelId) {
    $personeller = [['id' => $tekPersonelId]];
} else {
    $stmt = $db->query("SELECT id FROM personel WHERE durum = 'aktif' OR durum IS NULL");
    $personeller = $stmt->fetchAll();
}

$sonuclar = [];
$db->beginTransaction();
try {
    foreach ($personeller as $p) {
        $pid = (int)$p['id'];

        // Hakediş hesapla
        $hakedis = hakedis_personel_aylik_hesapla($db, $pid, $donem, $calisan_gun);
        if (!empty($hakedis['hata'])) {
            $sonuclar[] = ['personel_id' => $pid, 'hata' => $hakedis['hata']];
            continue;
        }

        // personel_hakedis tablosuna yaz/güncelle
        try {
            // Önce var mı kontrol
            $stmtChk = $db->prepare("SELECT id FROM personel_hakedis WHERE personel_id = ? AND donem = ?");
            $stmtChk->execute([$pid, $donem]);
            $mevcut = $stmtChk->fetch();

            if ($mevcut) {
                $stmtU = $db->prepare("UPDATE personel_hakedis SET
                    hakedis_tutar = ?, calisan_gun = ?, dosya_sayisi = ?,
                    hesaplama_detay = ?, hesaplama_tarihi = NOW()
                    WHERE id = ?");
                $stmtU->execute([
                    $hakedis['toplam_hakedis'], $calisan_gun, $hakedis['toplam_dosya'],
                    json_encode($hakedis, JSON_UNESCAPED_UNICODE),
                    $mevcut['id']
                ]);
                $hakedisId = (int)$mevcut['id'];
            } else {
                $stmtI = $db->prepare("INSERT INTO personel_hakedis
                    (personel_id, donem, hakedis_tutar, calisan_gun, dosya_sayisi, odeme_durumu, hesaplama_detay, hesaplama_tarihi)
                    VALUES (?, ?, ?, ?, ?, 'bekliyor', ?, NOW())");
                $stmtI->execute([
                    $pid, $donem, $hakedis['toplam_hakedis'], $calisan_gun,
                    $hakedis['toplam_dosya'],
                    json_encode($hakedis, JSON_UNESCAPED_UNICODE)
                ]);
                $hakedisId = (int)$db->lastInsertId();
            }

            // Bekleyen prim kayıtlarını "sayildi" yap + hakedis_id bağla
            $db->prepare("UPDATE personel_prim_kayitlari
                SET durum = 'sayildi', hakedis_id = ?
                WHERE personel_id = ? AND donem = ? AND durum = 'bekliyor'")
               ->execute([$hakedisId, $pid, $donem]);

            $hakedis['hakedis_id'] = $hakedisId;
        } catch (\Exception $e) {
            error_log('[v2.4 hakedis-hesapla] kaydetme: ' . $e->getMessage());
            $hakedis['kaydetme_hatasi'] = $e->getMessage();
        }

        $sonuclar[] = $hakedis;
    }

    $db->commit();
} catch (\Exception $e) {
    $db->rollBack();
    json_error('Hesaplama hatası: ' . $e->getMessage(), 500);
}

log_action($user['id'], 'hakedis_hesapla_v24', "Dönem: $donem · " . count($sonuclar) . ' personel', 'personel_hakedis', null);

json_success([
    'donem' => $donem,
    'islem_sayisi' => count($sonuclar),
    'sonuclar' => $sonuclar
], 'Hakediş hesaplama tamamlandı');
