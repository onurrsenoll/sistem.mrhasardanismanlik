<?php
/**
 * POST /api/v1/personel/kazanc-modeli-set.php
 * Personelin kazanç modelini oluştur/güncelle
 *
 * Body: {
 *   personel_id, model_tipi (sabit|sabit_prim|kademeli_saha|kademeli_ofis),
 *   sabit_maas, yemek_gunluk, yemek_gun_sayisi,
 *   prim_adk, prim_bh,                         (sabit_prim için)
 *   saha_kademe (array),                        (kademeli_saha için)
 *   ofis_kota (object),                         (kademeli_ofis için)
 *   yillik_bonus (array),
 *   gecerlilik_baslangic, notlar
 * }
 *
 * Eski aktif modeli "gecerlilik_bitis = bugün-1" olarak kapatır,
 * yeni modeli aktif olarak yazar.
 */

require_once __DIR__ . '/../../config/helpers.php';
require_once __DIR__ . '/../../config/auth.php';

setup_headers();
require_method('POST');

$user = auth_required(['admin', 'muhasebe']);
$body = get_json_body();
require_fields($body, ['personel_id', 'model_tipi']);

$db = getDB();
$personelId = (int)$body['personel_id'];
$modelTipi = clean($body['model_tipi']);
$gecerli = ['sabit','sabit_prim','kademeli_saha','kademeli_ofis'];
if (!in_array($modelTipi, $gecerli)) json_error('Geçersiz model tipi', 422);

// Personel var mı
$stmt = $db->prepare('SELECT id, ad_soyad FROM personel WHERE id = ?');
$stmt->execute([$personelId]);
$personel = $stmt->fetch();
if (!$personel) json_error('Personel bulunamadı', 404);

$gecerlilikBaslangic = $body['gecerlilik_baslangic'] ?? date('Y-m-d');

$db->beginTransaction();
try {
    // 1. Aktif modeli kapat (varsa)
    $eskiBitis = date('Y-m-d', strtotime($gecerlilikBaslangic . ' -1 day'));
    $db->prepare("UPDATE personel_kazanc_modelleri
        SET gecerlilik_bitis = ?, aktif = 0
        WHERE personel_id = ? AND aktif = 1
          AND (gecerlilik_bitis IS NULL OR gecerlilik_bitis >= ?)")
       ->execute([$eskiBitis, $personelId, $gecerlilikBaslangic]);

    // 2. Yeni model
    $stmt = $db->prepare("INSERT INTO personel_kazanc_modelleri
        (personel_id, model_tipi, sabit_maas, yemek_gunluk, yemek_gun_sayisi,
         prim_adk, prim_bh, saha_kademe_json, ofis_kota_json, yillik_bonus_json,
         gecerlilik_baslangic, gecerlilik_bitis, aktif, notlar, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, 1, ?, ?)");
    $stmt->execute([
        $personelId, $modelTipi,
        (float)($body['sabit_maas'] ?? 0),
        (float)($body['yemek_gunluk'] ?? 0),
        (int)($body['yemek_gun_sayisi'] ?? 22),
        (float)($body['prim_adk'] ?? 0),
        (float)($body['prim_bh'] ?? 0),
        !empty($body['saha_kademe']) ? json_encode($body['saha_kademe'], JSON_UNESCAPED_UNICODE) : null,
        !empty($body['ofis_kota']) ? json_encode($body['ofis_kota'], JSON_UNESCAPED_UNICODE) : null,
        !empty($body['yillik_bonus']) ? json_encode($body['yillik_bonus'], JSON_UNESCAPED_UNICODE) : null,
        $gecerlilikBaslangic,
        clean($body['notlar'] ?? ''),
        $user['id']
    ]);
    $modelId = (int)$db->lastInsertId();

    $db->commit();
} catch (\Exception $e) {
    $db->rollBack();
    json_error('Kayıt hatası: ' . $e->getMessage(), 500);
}

log_action($user['id'], 'kazanc_modeli_set', "{$personel['ad_soyad']} - $modelTipi (geçerli: $gecerlilikBaslangic)", 'personel_kazanc_modelleri', $modelId);

json_success(['model_id' => $modelId], 'Kazanç modeli kaydedildi', 201);
