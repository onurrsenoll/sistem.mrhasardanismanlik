<?php
/**
 * DELETE /api/v1/personel/evrak-sil.php?id=X
 * Personel evrakını sil (DB + disk)
 */
require_once __DIR__ . '/../../config/helpers.php';
require_once __DIR__ . '/../../config/auth.php';

setup_headers();
require_method('DELETE');

$user = auth_required(['admin', 'muhasebe']);
$db = getDB();
$id = (int)($_GET['id'] ?? 0);
if (!$id) json_error('ID gerekli', 422);

$stmt = $db->prepare('SELECT * FROM personel_evraklari WHERE id = ?');
$stmt->execute([$id]);
$evrak = $stmt->fetch();
if (!$evrak) json_error('Evrak bulunamadı', 404);

// Disk'ten sil (varsa)
$fullPath = UPLOAD_DIR . $evrak['dosya_yolu'];
if (file_exists($fullPath)) @unlink($fullPath);

// DB'den sil
$db->prepare('DELETE FROM personel_evraklari WHERE id = ?')->execute([$id]);

// Bağlı ödeme varsa evrak_id'yi NULL yap
if (!empty($evrak['odeme_id'])) {
    try { $db->prepare('UPDATE personel_odemeler SET evrak_id = NULL WHERE evrak_id = ?')->execute([$id]); }
    catch (\Exception $e) {}
}

log_action($user['id'], 'personel_evrak_sil', "{$evrak['dosya_adi']} silindi", 'personel_evraklari', $id);
json_success(null, 'Evrak silindi');
