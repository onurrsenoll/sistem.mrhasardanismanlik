<?php
/**
 * MR HASAR — v2.4 HAKEDİŞ HESAPLAMA MOTORU
 * Kademeli prim formülleri + yıllık bonus + iptal mahsup
 *
 * Bu dosya endpoint DEĞİL — sadece include edilen helper.
 * personel/hakedis-hesapla.php ve dosya/create.php tarafından kullanılır.
 */

if (!function_exists('hakedis_aktif_modeli_getir')) {
    /**
     * Personelin verilen tarihte aktif olan kazanç modelini döndürür.
     * Yoksa null döner (eski sisteme — basit prim_adk/prim_bh — düşülür).
     */
    function hakedis_aktif_modeli_getir($db, $personel_id, $tarih = null) {
        if ($tarih === null) $tarih = date('Y-m-d');
        $sql = "SELECT * FROM personel_kazanc_modelleri
                WHERE personel_id = ?
                  AND aktif = 1
                  AND gecerlilik_baslangic <= ?
                  AND (gecerlilik_bitis IS NULL OR gecerlilik_bitis >= ?)
                ORDER BY gecerlilik_baslangic DESC LIMIT 1";
        $stmt = $db->prepare($sql);
        $stmt->execute([$personel_id, $tarih, $tarih]);
        return $stmt->fetch();
    }
}

if (!function_exists('hakedis_saha_prim_hesapla')) {
    /**
     * SAHA tipi kademeli prim hesaplar.
     * @param int $toplam_dosya — Aydaki sayılan dosya sayısı (vekâletli + iptal hariç)
     * @param array $kademeler — [{min,max,birim,etiket},...]
     * @return array {prim, kademe, birim, etiket}
     */
    function hakedis_saha_prim_hesapla($toplam_dosya, $kademeler) {
        $prim = 0;
        $aktifKademe = null;
        foreach ($kademeler as $k) {
            $min = (int)($k['min'] ?? 0);
            $max = (int)($k['max'] ?? 999);
            $birim = (float)($k['birim'] ?? 0);
            if ($toplam_dosya >= $min && $toplam_dosya <= $max) {
                $prim = $toplam_dosya * $birim;
                $aktifKademe = $k;
                break;
            }
        }
        return [
            'prim' => $prim,
            'kademe_etiket' => $aktifKademe['etiket'] ?? '—',
            'birim' => $aktifKademe['birim'] ?? 0,
            'dosya_sayisi' => $toplam_dosya
        ];
    }
}

if (!function_exists('hakedis_ofis_prim_hesapla')) {
    /**
     * OFİS tipi (ADK + BH ayrı kademeli + kota) prim hesaplar.
     * Kota karşılanmazsa prim YOK (her iki kategoride min sağlanmalı).
     * @return array {adk_prim, bh_prim, toplam, adk_kademe, bh_kademe, kota_ok, aciklama}
     */
    function hakedis_ofis_prim_hesapla($adk_sayi, $bh_sayi, $ofis_kota_json) {
        $adk_kota = (int)($ofis_kota_json['adk_kota'] ?? 5);
        $bh_kota = (int)($ofis_kota_json['bh_kota'] ?? 2);
        $adk_kademeler = $ofis_kota_json['adk_kademe'] ?? [];
        $bh_kademeler = $ofis_kota_json['bh_kademe'] ?? [];

        // Kota kontrol — minimum sağlanmadan prim YOK
        $kota_ok = ($adk_sayi >= $adk_kota) && ($bh_sayi >= $bh_kota);

        // ADK kademe bul
        $adk_birim = 0; $adk_kademe_etiket = '—';
        foreach ($adk_kademeler as $k) {
            if ($adk_sayi >= (int)$k['min'] && $adk_sayi <= (int)$k['max']) {
                $adk_birim = (float)$k['birim'];
                $adk_kademe_etiket = $k['etiket'] ?? '—';
                break;
            }
        }

        // BH kademe bul
        $bh_birim = 0; $bh_kademe_etiket = '—';
        foreach ($bh_kademeler as $k) {
            if ($bh_sayi >= (int)$k['min'] && $bh_sayi <= (int)$k['max']) {
                $bh_birim = (float)$k['birim'];
                $bh_kademe_etiket = $k['etiket'] ?? '—';
                break;
            }
        }

        $adk_prim = $kota_ok ? $adk_sayi * $adk_birim : 0;
        $bh_prim = $kota_ok ? $bh_sayi * $bh_birim : 0;

        $aciklama = $kota_ok
            ? "Kota tamamlandı. ADK: $adk_sayi × " . number_format($adk_birim, 0) . " TL = " . number_format($adk_prim, 2) . " TL · BH: $bh_sayi × " . number_format($bh_birim, 0) . " TL = " . number_format($bh_prim, 2) . " TL"
            : "Kota sağlanmadı (ADK min $adk_kota / BH min $bh_kota). Prim hesaplanmadı.";

        return [
            'adk_prim' => $adk_prim,
            'bh_prim' => $bh_prim,
            'toplam' => $adk_prim + $bh_prim,
            'adk_kademe_etiket' => $adk_kademe_etiket,
            'bh_kademe_etiket' => $bh_kademe_etiket,
            'adk_birim' => $adk_birim,
            'bh_birim' => $bh_birim,
            'kota_ok' => $kota_ok,
            'aciklama' => $aciklama
        ];
    }
}

if (!function_exists('hakedis_yillik_bonus_hesapla')) {
    /**
     * Yıllık bonus hesaplama (Aralık ayı için).
     * @param int $yillik_dosya — yıl boyunca toplam dosya
     * @param array $bonuslar — [{min,max,bonus,etiket}]
     * @return array {bonus, etiket, kazanildi}
     */
    function hakedis_yillik_bonus_hesapla($yillik_dosya, $bonuslar) {
        $kazanilan = 0;
        $etiket = '—';
        foreach ($bonuslar as $b) {
            if ($yillik_dosya >= (int)$b['min'] && $yillik_dosya <= (int)$b['max']) {
                $kazanilan = (float)$b['bonus'];
                $etiket = $b['etiket'] ?? '—';
                break;
            }
        }
        return [
            'bonus' => $kazanilan,
            'etiket' => $etiket,
            'kazanildi' => $kazanilan > 0,
            'yillik_dosya' => $yillik_dosya
        ];
    }
}

if (!function_exists('hakedis_personel_aylik_hesapla')) {
    /**
     * Bir personel için verilen ayda hakediş hesaplar.
     * Ana fonksiyon — modele göre saha/ofis/sabit/sabit_prim formülünü uygular.
     *
     * @param PDO $db
     * @param int $personel_id
     * @param string $donem (YYYY-MM)
     * @param int $calisan_gun (default 22)
     * @return array — tam hakediş özeti
     */
    function hakedis_personel_aylik_hesapla($db, $personel_id, $donem, $calisan_gun = 22) {
        // 1. Personel bilgisi
        $stmt = $db->prepare('SELECT * FROM personel WHERE id = ?');
        $stmt->execute([$personel_id]);
        $personel = $stmt->fetch();
        if (!$personel) return ['hata' => 'Personel bulunamadı'];

        // 2. Aktif kazanç modelini bul
        $donem_son_gun = date('Y-m-t', strtotime($donem . '-01'));
        $model = hakedis_aktif_modeli_getir($db, $personel_id, $donem_son_gun);

        // Model yoksa → eski basit yapıya düş (prim_adk/prim_bh)
        if (!$model) {
            $model = [
                'model_tipi' => 'sabit_prim',
                'sabit_maas' => $personel['maas'] ?? 0,
                'yemek_gunluk' => 0,
                'prim_adk' => $personel['prim_adk'] ?? $personel['prim_orani'] ?? 0,
                'prim_bh' => $personel['prim_bh'] ?? 0,
                'yillik_bonus_json' => null,
                'saha_kademe_json' => null,
                'ofis_kota_json' => null
            ];
        }

        // 3. Dönemde sayılan dosyaları bul
        $sayilanlar = hakedis_donem_dosyalari_say($db, $personel_id, $donem);
        $adk_sayi = $sayilanlar['adk'];
        $bh_sayi = $sayilanlar['bh'];
        $toplam_dosya = $adk_sayi + $bh_sayi;

        // 4. Sabit maaş — gün bazlı
        $sabit_maas = (float)($model['sabit_maas'] ?? 0);
        $gunluk = $sabit_maas / 30;
        $maas_tutar = round($gunluk * $calisan_gun, 2);

        // 5. Yemek (varsa)
        $yemek_gunluk = (float)($model['yemek_gunluk'] ?? 0);
        $yemek_gun = (int)($model['yemek_gun_sayisi'] ?? 0);
        $yemek_tutar = round($yemek_gunluk * $yemek_gun, 2);

        // 6. Prim hesapla — model tipine göre
        $prim_detay = ['adk_prim' => 0, 'bh_prim' => 0, 'toplam' => 0, 'aciklama' => ''];
        $tip = $model['model_tipi'] ?? 'sabit_prim';

        if ($tip === 'sabit') {
            $prim_detay['aciklama'] = 'Sabit maaş modeli, prim yok';
        } elseif ($tip === 'sabit_prim') {
            $adk_prim = $adk_sayi * (float)$model['prim_adk'];
            $bh_prim = $bh_sayi * (float)$model['prim_bh'];
            $prim_detay = [
                'adk_prim' => $adk_prim,
                'bh_prim' => $bh_prim,
                'toplam' => $adk_prim + $bh_prim,
                'aciklama' => "ADK: $adk_sayi × " . number_format($model['prim_adk'], 0) . " · BH: $bh_sayi × " . number_format($model['prim_bh'], 0)
            ];
        } elseif ($tip === 'kademeli_saha') {
            $kademeler = json_decode($model['saha_kademe_json'] ?? '[]', true) ?: [];
            $sonuc = hakedis_saha_prim_hesapla($toplam_dosya, $kademeler);
            $prim_detay = [
                'adk_prim' => 0,
                'bh_prim' => 0,
                'toplam' => $sonuc['prim'],
                'kademe' => $sonuc['kademe_etiket'],
                'birim' => $sonuc['birim'],
                'aciklama' => "Saha kademe: {$sonuc['kademe_etiket']} ({$toplam_dosya} dosya × " . number_format($sonuc['birim'], 0) . " TL)"
            ];
        } elseif ($tip === 'kademeli_ofis') {
            $kota = json_decode($model['ofis_kota_json'] ?? '{}', true) ?: [];
            $sonuc = hakedis_ofis_prim_hesapla($adk_sayi, $bh_sayi, $kota);
            $prim_detay = $sonuc;
        }

        // 7. İptal mahsup (önceki ay iptal_mahsup işaretli kayıtlar)
        $iptal_mahsup = hakedis_iptal_mahsup_topla($db, $personel_id, $donem, $model);

        // 8. Yıllık bonus — sadece Aralık'ta
        $yillik_bonus = ['bonus' => 0, 'etiket' => '—', 'kazanildi' => false];
        if (substr($donem, -2) === '12') {
            $yillik_dosya = hakedis_yillik_dosya_say($db, $personel_id, substr($donem, 0, 4));
            $bonuslar = json_decode($model['yillik_bonus_json'] ?? '[]', true) ?: [];
            if (!empty($bonuslar)) {
                $yillik_bonus = hakedis_yillik_bonus_hesapla($yillik_dosya, $bonuslar);
            }
        }

        // 9. Toplam hakediş
        $toplam = $maas_tutar + $yemek_tutar + $prim_detay['toplam'] + $yillik_bonus['bonus'] - $iptal_mahsup;

        return [
            'personel_id' => $personel_id,
            'personel_adi' => $personel['ad_soyad'],
            'donem' => $donem,
            'model_tipi' => $tip,
            'calisan_gun' => $calisan_gun,
            'adk_sayi' => $adk_sayi,
            'bh_sayi' => $bh_sayi,
            'toplam_dosya' => $toplam_dosya,
            'sabit_maas' => $sabit_maas,
            'maas_tutar' => $maas_tutar,
            'yemek_tutar' => $yemek_tutar,
            'prim_detay' => $prim_detay,
            'iptal_mahsup' => $iptal_mahsup,
            'yillik_bonus' => $yillik_bonus,
            'toplam_hakedis' => $toplam,
            'aciklama' => "Maaş: " . number_format($maas_tutar, 2) . " · Yemek: " . number_format($yemek_tutar, 2) . " · Prim: " . number_format($prim_detay['toplam'], 2) . ($yillik_bonus['kazanildi'] ? " · Yıllık Bonus: " . number_format($yillik_bonus['bonus'], 2) : '') . ($iptal_mahsup > 0 ? " · İptal Mahsup: -" . number_format($iptal_mahsup, 2) : '')
        ];
    }
}

if (!function_exists('hakedis_donem_dosyalari_say')) {
    /**
     * Verilen ay için sayılan dosyaları döner (bekliyor + sayildi durumunda olanlar).
     * personel_prim_kayitlari'dan okur.
     */
    function hakedis_donem_dosyalari_say($db, $personel_id, $donem) {
        $stmt = $db->prepare("SELECT
            SUM(CASE WHEN dosya_turu = 'ADK' THEN 1 ELSE 0 END) as adk,
            SUM(CASE WHEN dosya_turu = 'BH' THEN 1 ELSE 0 END) as bh
            FROM personel_prim_kayitlari
            WHERE personel_id = ? AND donem = ? AND durum IN ('bekliyor','sayildi')");
        $stmt->execute([$personel_id, $donem]);
        $row = $stmt->fetch();
        return [
            'adk' => (int)($row['adk'] ?? 0),
            'bh' => (int)($row['bh'] ?? 0)
        ];
    }
}

if (!function_exists('hakedis_yillik_dosya_say')) {
    /**
     * Yıl boyunca sayılan toplam dosya sayısı (yıllık bonus için).
     */
    function hakedis_yillik_dosya_say($db, $personel_id, $yil) {
        $stmt = $db->prepare("SELECT COUNT(*) as toplam
            FROM personel_prim_kayitlari
            WHERE personel_id = ? AND donem LIKE ? AND durum IN ('bekliyor','sayildi')");
        $stmt->execute([$personel_id, $yil . '-%']);
        return (int)($stmt->fetch()['toplam'] ?? 0);
    }
}

if (!function_exists('hakedis_iptal_mahsup_topla')) {
    /**
     * Önceki ay iptal_mahsup durumuna geçen kayıtların toplam tutarını
     * hesaplar (önceki ay primli olarak ödenmiş, şimdi iptal oldu).
     * Mahsup tutarı = o dosyanın o dönem birim primi.
     */
    function hakedis_iptal_mahsup_topla($db, $personel_id, $donem, $model) {
        $stmt = $db->prepare("SELECT COUNT(*) as adet, dosya_turu
            FROM personel_prim_kayitlari
            WHERE personel_id = ? AND iptal_tarihi IS NOT NULL
              AND DATE_FORMAT(iptal_tarihi, '%Y-%m') = ?
              AND durum = 'iptal_mahsup'
            GROUP BY dosya_turu");
        $stmt->execute([$personel_id, $donem]);

        $toplam_mahsup = 0;
        $tip = $model['model_tipi'] ?? 'sabit_prim';

        while ($row = $stmt->fetch()) {
            $sayi = (int)$row['adet'];
            $tur = $row['dosya_turu'];

            if ($tip === 'sabit_prim') {
                $birim = $tur === 'ADK' ? (float)$model['prim_adk'] : (float)$model['prim_bh'];
                $toplam_mahsup += $sayi * $birim;
            } elseif ($tip === 'kademeli_saha') {
                // Saha için kademe önceden bilinmediği için ortalama kullan
                $kademeler = json_decode($model['saha_kademe_json'] ?? '[]', true) ?: [];
                $birim = !empty($kademeler[1]) ? (float)$kademeler[1]['birim'] : 0;
                $toplam_mahsup += $sayi * $birim;
            } elseif ($tip === 'kademeli_ofis') {
                $kota = json_decode($model['ofis_kota_json'] ?? '{}', true) ?: [];
                $kademeler = $tur === 'ADK' ? ($kota['adk_kademe'] ?? []) : ($kota['bh_kademe'] ?? []);
                $birim = !empty($kademeler[1]) ? (float)$kademeler[1]['birim'] : 0;
                $toplam_mahsup += $sayi * $birim;
            }
        }

        return $toplam_mahsup;
    }
}
