<?php
/**
 * POST /api/v1/personel/odeme-yap.php
 * Personele ödeme yap (maaş/avans/prim/ikramiye/mesai/diger)
 *
 * Body: {
 *   personel_id, odeme_turu, tutar, kasa_id,
 *   donem (YYYY-MM, opsiyonel — maaş/prim için),
 *   aciklama, hakedis_id (opsiyonel — bağlı hakediş)
 * }
 *
 * - personel_odemeler'a kayıt
 * - Kasadan tutar düş
 * - kasa_hareketleri'ne yansıt
 * - Bağlı hakediş varsa odeme_durumu='odendi' yap
 *
 * Evrak ayrı endpoint ile yüklenir (odeme_id ile bağlanır)
 */

require_once __DIR__ . '/../../config/helpers.php';
require_once __DIR__ . '/../../config/auth.php';

setup_headers();
require_method('POST');

$user = auth_required();
if (!has_yetki($user, 'muhasebe', 'personel-maas-ode') && ($user['rol'] ?? '') !== 'admin') {
    json_error('Yetki yok', 403);
}

$body = get_json_body();
require_fields($body, ['personel_id', 'odeme_turu', 'tutar', 'kasa_id']);

$db = getDB();
$personelId = (int)$body['personel_id'];
$odemeTuru = clean($body['odeme_turu']);
$tutar = (float)$body['tutar'];
$kasaId = (int)$body['kasa_id'];
$donem = !empty($body['donem']) ? clean($body['donem']) : null;
$aciklama = !empty($body['aciklama']) ? clean($body['aciklama']) : null;
$hakedisId = !empty($body['hakedis_id']) ? (int)$body['hakedis_id'] : null;
$bugun = date('Y-m-d');

if ($tutar <= 0) json_error('Tutar 0\'dan büyük olmalı', 422);
$gecerliTurler = ['maas','prim','avans','ikramiye','mesai','diger'];
if (!in_array($odemeTuru, $gecerliTurler)) {
    json_error('Geçersiz ödeme türü. Geçerli: ' . implode(', ', $gecerliTurler), 422);
}

// Personel kontrol
$stmt = $db->prepare('SELECT id, ad_soyad FROM personel WHERE id = ?');
$stmt->execute([$personelId]);
$personel = $stmt->fetch();
if (!$personel) json_error('Personel bulunamadı', 404);

$db->beginTransaction();
try {
    // Kasa kontrol (FOR UPDATE — race condition koruma)
    $stmt = $db->prepare('SELECT id, ad, bakiye FROM kasalar WHERE id = ? AND aktif = 1 FOR UPDATE');
    $stmt->execute([$kasaId]);
    $kasa = $stmt->fetch();
    if (!$kasa) { $db->rollBack(); json_error('Kasa bulunamadı', 404); }
    if ($kasa['bakiye'] < $tutar) {
        $db->rollBack();
        json_error("Yetersiz bakiye! {$kasa['ad']}: " . number_format($kasa['bakiye'], 2, ',', '.') . ' ₺', 422);
    }

    // 1. Ödeme kaydı oluştur
    $stmt = $db->prepare("INSERT INTO personel_odemeler
        (personel_id, odeme_turu, tutar, donem, odeme_tarihi, kasa_id, aciklama, hakedis_id, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$personelId, $odemeTuru, $tutar, $donem, $bugun, $kasaId, $aciklama, $hakedisId, $user['id']]);
    $odemeId = (int)$db->lastInsertId();

    // 2. Kasa bakiyesini düş
    $yeniBakiye = $kasa['bakiye'] - $tutar;
    $db->prepare('UPDATE kasalar SET bakiye = ? WHERE id = ?')->execute([$yeniBakiye, $kasaId]);

    // 3. Kasa hareketi
    try {
        $kasaAciklama = "PERSONEL " . strtoupper($odemeTuru) . " ÖDEMESİ — " . $personel['ad_soyad'] . ($donem ? " ($donem)" : '') . ($aciklama ? " — $aciklama" : '');
        $db->prepare("INSERT INTO kasa_hareketleri
            (kasa_id, dosya_id, islem_turu, tutar, bakiye_sonrasi, aciklama, kullanici_id)
            VALUES (?, NULL, 'gider', ?, ?, ?, ?)")
           ->execute([$kasaId, $tutar, $yeniBakiye, $kasaAciklama, $user['id']]);
    } catch (\Exception $e) {
        error_log('[v2.4 personel/odeme-yap] kasa_hareketleri INSERT: ' . $e->getMessage());
    }

    // 4. Bağlı hakediş varsa ödendi yap
    if ($hakedisId) {
        try {
            $db->prepare("UPDATE personel_hakedis SET odeme_durumu = 'odendi', odeme_tarihi = ?, kasa_id = ?
                WHERE id = ? AND odeme_durumu <> 'odendi'")
               ->execute([$bugun, $kasaId, $hakedisId]);
        } catch (\Exception $e) {
            error_log('[v2.4 personel/odeme-yap] hakedis update: ' . $e->getMessage());
        }
    }

    $db->commit();
} catch (\Exception $e) {
    $db->rollBack();
    json_error('Ödeme hatası: ' . $e->getMessage(), 500);
}

log_action($user['id'], 'personel_odeme', "{$personel['ad_soyad']} - " . strtoupper($odemeTuru) . ": " . number_format($tutar, 2) . " ₺ ({$kasa['ad']})", 'personel_odemeler', $odemeId);

json_success([
    'odeme_id' => $odemeId,
    'kasa_yeni_bakiye' => $yeniBakiye,
    'mesaj' => 'Ödeme başarıyla yapıldı. Dekont yüklemek için /personel/evrak-yukle.php endpoint\'ini kullanın (odeme_id parametresi ile).'
], 'Ödeme başarıyla yapıldı', 201);
