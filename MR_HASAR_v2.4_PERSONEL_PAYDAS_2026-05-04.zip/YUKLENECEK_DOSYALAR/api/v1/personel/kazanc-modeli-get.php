<?php
/**
 * GET /api/v1/personel/kazanc-modeli-get.php?id=X
 * Personelin aktif kazanç modelini ve geçmişini döner
 */
require_once __DIR__ . '/../../config/helpers.php';
require_once __DIR__ . '/../../config/auth.php';

setup_headers();
require_method('GET');

$user = auth_required();
$db = getDB();
$personelId = (int)($_GET['id'] ?? 0);
if (!$personelId) json_error('Personel ID gerekli', 422);

// Aktif model
$stmt = $db->prepare("SELECT * FROM personel_kazanc_modelleri
    WHERE personel_id = ? AND aktif = 1
      AND (gecerlilik_bitis IS NULL OR gecerlilik_bitis >= CURDATE())
    ORDER BY gecerlilik_baslangic DESC LIMIT 1");
$stmt->execute([$personelId]);
$aktif = $stmt->fetch();

// JSON alanlarını parse et
if ($aktif) {
    $aktif['saha_kademe'] = json_decode($aktif['saha_kademe_json'] ?? '[]', true) ?: [];
    $aktif['ofis_kota'] = json_decode($aktif['ofis_kota_json'] ?? '{}', true) ?: new stdClass();
    $aktif['yillik_bonus'] = json_decode($aktif['yillik_bonus_json'] ?? '[]', true) ?: [];
}

// Geçmiş modeller
$stmt = $db->prepare('SELECT id, model_tipi, gecerlilik_baslangic, gecerlilik_bitis, sabit_maas, notlar
    FROM personel_kazanc_modelleri WHERE personel_id = ? ORDER BY gecerlilik_baslangic DESC');
$stmt->execute([$personelId]);
$gecmis = $stmt->fetchAll();

// Şablonlar
$sablonlar = [
    'sercan_saha' => [
        'etiket' => 'Saha — Sercan Tipi (40K + Kademeli)',
        'model_tipi' => 'kademeli_saha',
        'sabit_maas' => 40000,
        'yemek_gunluk' => 0,
        'saha_kademe' => [
            ['min'=>0,'max'=>10,'birim'=>0,'etiket'=>'Hedef Altı'],
            ['min'=>11,'max'=>15,'birim'=>2500,'etiket'=>'Kademe 1'],
            ['min'=>16,'max'=>20,'birim'=>3500,'etiket'=>'Kademe 2'],
            ['min'=>21,'max'=>999,'birim'=>5000,'etiket'=>'Kademe 3']
        ],
        'yillik_bonus' => [
            ['min'=>180,'max'=>199,'bonus'=>50000,'etiket'=>'Bronz'],
            ['min'=>200,'max'=>219,'bonus'=>75000,'etiket'=>'Gümüş'],
            ['min'=>220,'max'=>9999,'bonus'=>100000,'etiket'=>'Altın']
        ]
    ],
    'ofis_cagri' => [
        'etiket' => 'Ofis Çağrı Uzmanı (28K + Yemek + ADK/BH Kademeli)',
        'model_tipi' => 'kademeli_ofis',
        'sabit_maas' => 28076,
        'yemek_gunluk' => 250,
        'yemek_gun_sayisi' => 22,
        'ofis_kota' => [
            'adk_kota' => 5,
            'bh_kota' => 2,
            'adk_kademe' => [
                ['min'=>0,'max'=>4,'birim'=>0,'etiket'=>'Hedef Altı'],
                ['min'=>5,'max'=>7,'birim'=>1500,'etiket'=>'Kademe 1'],
                ['min'=>8,'max'=>10,'birim'=>1750,'etiket'=>'Kademe 2'],
                ['min'=>11,'max'=>14,'birim'=>2000,'etiket'=>'Kademe 3'],
                ['min'=>15,'max'=>999,'birim'=>2500,'etiket'=>'Kademe 4']
            ],
            'bh_kademe' => [
                ['min'=>0,'max'=>1,'birim'=>0,'etiket'=>'Hedef Altı'],
                ['min'=>2,'max'=>3,'birim'=>2500,'etiket'=>'Kademe 1'],
                ['min'=>4,'max'=>5,'birim'=>3000,'etiket'=>'Kademe 2'],
                ['min'=>6,'max'=>7,'birim'=>3500,'etiket'=>'Kademe 3'],
                ['min'=>8,'max'=>99,'birim'=>4500,'etiket'=>'Kademe 4']
            ]
        ],
        'yillik_bonus' => [
            ['min'=>84,'max'=>119,'bonus'=>25000,'etiket'=>'Bronz'],
            ['min'=>120,'max'=>167,'bonus'=>50000,'etiket'=>'Gümüş'],
            ['min'=>168,'max'=>9999,'bonus'=>100000,'etiket'=>'Altın']
        ]
    ],
    'sabit_prim' => [
        'etiket' => 'Basit (Sabit Maaş + Dosya Başı Prim)',
        'model_tipi' => 'sabit_prim',
        'sabit_maas' => 0,
        'prim_adk' => 0,
        'prim_bh' => 0
    ],
    'sabit' => [
        'etiket' => 'Sabit Maaş (Prim Yok)',
        'model_tipi' => 'sabit',
        'sabit_maas' => 0
    ]
];

json_success([
    'aktif_model' => $aktif,
    'gecmis_modeller' => $gecmis,
    'sablonlar' => $sablonlar
]);
