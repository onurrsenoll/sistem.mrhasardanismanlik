/**
 * MR HASAR — v2.4 KART MODÜLLERİ
 *
 * - PersonelKartModal      → Genel + Kazanç Modeli + Cari Hesap + Ödeme Yap + Evraklar
 * - PaydasKartModal        → Genel + Komisyon + Evraklar + Cari Hesap
 * - PersonelCariSayfasi    → Detaylı cari hesap dökümü (sayfa)
 * - PaydasCariSayfasi      → Detaylı cari hesap dökümü (sayfa)
 *
 * Mevcut personel.js ve ortaklar.js'ten import edilebilir global bileşenler.
 */
const MR = window.MR || (window.MR = {});
const {useState, useEffect, useCallback, useRef} = React;

/* ═══════════ PERSONEL KART MODAL ═══════════ */
MR.PersonelKartModal = ({open, onClose, personel, user, onUpdate}) => {
  const {C, S, api, hasYetki} = MR;
  const [tab, setTab] = useState('genel');
  const [cari, setCari] = useState(null);
  const [evraklar, setEvraklar] = useState([]);
  const [model, setModel] = useState(null);
  const [sablonlar, setSablonlar] = useState({});
  const [loading, setLoading] = useState(false);

  // Ödeme Yap modal state
  const [odemeOpen, setOdemeOpen] = useState(false);
  const [odemeData, setOdemeData] = useState({odeme_turu: 'maas', tutar: '', kasa_id: '', donem: '', aciklama: ''});
  const [kasalar, setKasalar] = useState([]);

  // Evrak yükleme state
  const [evrakOpen, setEvrakOpen] = useState(false);
  const [evrakFile, setEvrakFile] = useState(null);
  const [evrakTuru, setEvrakTuru] = useState('sozlesme');
  const [evrakEtiketi, setEvrakEtiketi] = useState('');

  // Kazanç modeli state
  const [modelDuzenle, setModelDuzenle] = useState(false);

  useEffect(() => {
    if (open && personel?.id) {
      yukle();
    }
  }, [open, personel?.id]);

  const yukle = async () => {
    setLoading(true);
    const [c, e, m, k] = await Promise.all([
      api.req('/personel/cari-hesap.php?id=' + personel.id),
      api.req('/personel/evrak-list.php?id=' + personel.id),
      api.req('/personel/kazanc-modeli-get.php?id=' + personel.id),
      api.kasaList()
    ]);
    if (c?.success) setCari(c.data);
    if (e?.success) setEvraklar(e.data || []);
    if (m?.success) { setModel(m.data); setSablonlar(m.data.sablonlar || {}); }
    if (k?.success) setKasalar(k.data || []);
    setLoading(false);
  };

  const odemeYap = async () => {
    if (!odemeData.tutar || !odemeData.kasa_id) {
      MR.toast('Tutar ve kasa zorunlu', 'error');
      return;
    }
    const r = await api.req('/personel/odeme-yap.php', {
      method: 'POST',
      body: JSON.stringify({...odemeData, personel_id: personel.id, tutar: parseFloat(odemeData.tutar)})
    });
    if (r?.success) {
      MR.toast('Ödeme başarıyla yapıldı', 'success');
      setOdemeOpen(false);
      setOdemeData({odeme_turu: 'maas', tutar: '', kasa_id: '', donem: '', aciklama: ''});
      yukle();
    } else {
      MR.toast(r?.error || 'Ödeme hatası', 'error');
    }
  };

  const evrakYukle = async () => {
    if (!evrakFile) { MR.toast('Dosya seçin', 'error'); return; }
    const fd = new FormData();
    fd.append('personel_id', personel.id);
    fd.append('evrak_turu', evrakTuru);
    fd.append('evrak_etiketi', evrakEtiketi);
    fd.append('file', evrakFile);
    const h = {}; if (api.token) h['Authorization'] = 'Bearer ' + api.token;
    const r = await fetch('/api/v1/personel/evrak-yukle.php', {method: 'POST', headers: h, body: fd}).then(r => r.json());
    if (r?.success) {
      MR.toast('Evrak yüklendi', 'success');
      setEvrakOpen(false); setEvrakFile(null); setEvrakEtiketi('');
      yukle();
    } else MR.toast(r?.error || 'Yükleme hatası', 'error');
  };

  const evrakSil = async (id) => {
    if (!confirm('Evrakı silmek istediğinize emin misiniz?')) return;
    const r = await api.req('/personel/evrak-sil.php?id=' + id, {method: 'DELETE'});
    if (r?.success) { MR.toast('Evrak silindi', 'success'); yukle(); }
    else MR.toast(r?.error || 'Silme hatası', 'error');
  };

  const sablonUygula = (key) => {
    const s = sablonlar[key];
    if (!s) return;
    setModel({...model, aktif_model: {
      ...s,
      saha_kademe_json: JSON.stringify(s.saha_kademe || []),
      ofis_kota_json: JSON.stringify(s.ofis_kota || {}),
      yillik_bonus_json: JSON.stringify(s.yillik_bonus || [])
    }});
    setModelDuzenle(true);
  };

  const modelKaydet = async () => {
    const m = model.aktif_model;
    const r = await api.req('/personel/kazanc-modeli-set.php', {
      method: 'POST',
      body: JSON.stringify({
        personel_id: personel.id,
        model_tipi: m.model_tipi,
        sabit_maas: parseFloat(m.sabit_maas) || 0,
        yemek_gunluk: parseFloat(m.yemek_gunluk) || 0,
        yemek_gun_sayisi: parseInt(m.yemek_gun_sayisi) || 22,
        prim_adk: parseFloat(m.prim_adk) || 0,
        prim_bh: parseFloat(m.prim_bh) || 0,
        saha_kademe: m.saha_kademe || [],
        ofis_kota: m.ofis_kota || {},
        yillik_bonus: m.yillik_bonus || [],
        gecerlilik_baslangic: m.gecerlilik_baslangic || new Date().toISOString().slice(0,10)
      })
    });
    if (r?.success) {
      MR.toast('Kazanç modeli kaydedildi', 'success');
      setModelDuzenle(false);
      yukle();
    } else MR.toast(r?.error || 'Kayıt hatası', 'error');
  };

  if (!open) return null;

  return (
    <MR.Modal open={open} onClose={onClose} title={`PERSONEL KARTI — ${personel?.ad_soyad || ''}`} width="950px">
      {/* TAB MENU */}
      <div style={{display:'flex', gap:4, borderBottom:`1px solid ${C.border}`, marginBottom:16, padding:'0 4px'}}>
        {[
          {id:'genel',  label:'GENEL BİLGİLER',  icon:'👤'},
          {id:'model',  label:'KAZANÇ MODELİ',  icon:'💰'},
          {id:'cari',   label:'CARİ HESAP',     icon:'📊'},
          {id:'odeme',  label:'ÖDEMELER',       icon:'💵'},
          {id:'evrak',  label:'EVRAKLAR',       icon:'📄'},
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            padding:'10px 16px', border:'none', background:tab===t.id?C.accent:'transparent',
            color:tab===t.id?'#fff':C.textSec, fontWeight:700, fontSize:11, letterSpacing:0.5,
            textTransform:'uppercase', cursor:'pointer', borderRadius:'7px 7px 0 0', transition:'all .15s'
          }}>{t.icon} {t.label}</button>
        ))}
      </div>

      {/* GENEL */}
      {tab === 'genel' && (
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:14}}>
          <div><div style={S.label}>AD SOYAD</div><div style={{fontWeight:700}}>{personel?.ad_soyad}</div></div>
          <div><div style={S.label}>DEPARTMAN</div><div style={{fontWeight:700}}>{personel?.departman || '-'}</div></div>
          <div><div style={S.label}>TELEFON</div><div style={{fontWeight:700}}>{personel?.telefon || '-'}</div></div>
          <div><div style={S.label}>EMAIL</div><div style={{fontWeight:700}}>{personel?.email || '-'}</div></div>
          <div><div style={S.label}>İŞE BAŞLAMA</div><div style={{fontWeight:700}}>{personel?.ise_baslama || '-'}</div></div>
          <div><div style={S.label}>DURUM</div><div style={{fontWeight:700}}>{personel?.durum || 'aktif'}</div></div>
        </div>
      )}

      {/* KAZANÇ MODELİ */}
      {tab === 'model' && (
        <div>
          {!modelDuzenle && model?.aktif_model && (
            <div>
              <div style={{padding:14, background:C.bgInput, borderRadius:8, marginBottom:14}}>
                <div style={{fontSize:11, fontWeight:700, color:C.textSec, marginBottom:6, textTransform:'uppercase'}}>AKTİF MODEL</div>
                <div style={{fontSize:14, fontWeight:700, color:C.text}}>{model.aktif_model.model_tipi?.toUpperCase()}</div>
                <div style={{fontSize:12, color:C.textSec, marginTop:4}}>
                  Sabit Maaş: <strong>{(model.aktif_model.sabit_maas || 0).toLocaleString('tr-TR')} TL</strong>
                  {model.aktif_model.yemek_gunluk > 0 && ` · Yemek: ${model.aktif_model.yemek_gunluk} TL × ${model.aktif_model.yemek_gun_sayisi} gün`}
                  · Geçerlilik: {model.aktif_model.gecerlilik_baslangic}
                </div>
              </div>
              <button style={{...S.btn, ...S.btnP}} onClick={() => setModelDuzenle(true)}>MODELİ DÜZENLE</button>
            </div>
          )}
          {!modelDuzenle && !model?.aktif_model && (
            <div style={{padding:24, textAlign:'center'}}>
              <div style={{fontSize:36, marginBottom:8}}>⚠️</div>
              <div style={{color:C.danger, fontWeight:700, marginBottom:14}}>HENÜZ KAZANÇ MODELİ TANIMLANMAMIŞ</div>
              <div style={{color:C.textSec, fontSize:12, marginBottom:14}}>Bir şablondan başlayın veya boş model oluşturun:</div>
              <div style={{display:'flex', gap:8, flexWrap:'wrap', justifyContent:'center'}}>
                {Object.entries(sablonlar).map(([key, s]) => (
                  <button key={key} style={{...S.btn, ...S.btnG, fontSize:11}} onClick={() => sablonUygula(key)}>{s.etiket}</button>
                ))}
              </div>
            </div>
          )}
          {modelDuzenle && (
            <div style={{display:'grid', gap:10}}>
              <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:10}}>
                <div>
                  <div style={S.label}>MODEL TİPİ</div>
                  <select style={S.select} value={model.aktif_model?.model_tipi || 'sabit'}
                    onChange={e => setModel({...model, aktif_model:{...model.aktif_model, model_tipi:e.target.value}})}>
                    <option value="sabit">Sabit Maaş</option>
                    <option value="sabit_prim">Sabit Maaş + Dosya Başı Prim</option>
                    <option value="kademeli_saha">Kademeli Saha (toplam dosya)</option>
                    <option value="kademeli_ofis">Kademeli Ofis (ADK + BH ayrı)</option>
                  </select>
                </div>
                <div>
                  <div style={S.label}>GEÇERLİLİK BAŞLANGIÇ</div>
                  <input type="date" style={S.input}
                    value={model.aktif_model?.gecerlilik_baslangic || new Date().toISOString().slice(0,10)}
                    onChange={e => setModel({...model, aktif_model:{...model.aktif_model, gecerlilik_baslangic:e.target.value}})}/>
                </div>
                <div>
                  <div style={S.label}>SABİT MAAŞ (TL)</div>
                  <input type="number" style={S.input}
                    value={model.aktif_model?.sabit_maas || 0}
                    onChange={e => setModel({...model, aktif_model:{...model.aktif_model, sabit_maas:e.target.value}})}/>
                </div>
                <div>
                  <div style={S.label}>YEMEK GÜNLÜK (TL)</div>
                  <input type="number" style={S.input}
                    value={model.aktif_model?.yemek_gunluk || 0}
                    onChange={e => setModel({...model, aktif_model:{...model.aktif_model, yemek_gunluk:e.target.value}})}/>
                </div>
              </div>

              {model.aktif_model?.model_tipi === 'sabit_prim' && (
                <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:10}}>
                  <div>
                    <div style={S.label}>PRİM ADK (TL/dosya)</div>
                    <input type="number" style={S.input}
                      value={model.aktif_model?.prim_adk || 0}
                      onChange={e => setModel({...model, aktif_model:{...model.aktif_model, prim_adk:e.target.value}})}/>
                  </div>
                  <div>
                    <div style={S.label}>PRİM BH (TL/dosya)</div>
                    <input type="number" style={S.input}
                      value={model.aktif_model?.prim_bh || 0}
                      onChange={e => setModel({...model, aktif_model:{...model.aktif_model, prim_bh:e.target.value}})}/>
                  </div>
                </div>
              )}

              {(model.aktif_model?.model_tipi === 'kademeli_saha' || model.aktif_model?.model_tipi === 'kademeli_ofis') && (
                <div style={{padding:10, background:C.bgInput, borderRadius:8, fontSize:11, color:C.textSec}}>
                  📌 Kademeli model parametreleri şablonda hazır. Detaylı düzenleme için JSON formatında kaydetmek gerek.
                  Mevcut: {model.aktif_model.model_tipi === 'kademeli_saha' ? 'Saha kademeleri' : 'Ofis ADK+BH kademeleri'} hazır şablondan yüklendi.
                </div>
              )}

              <div style={{display:'flex', gap:8, marginTop:14}}>
                <button style={{...S.btn, ...S.btnG}} onClick={() => setModelDuzenle(false)}>İPTAL</button>
                <button style={{...S.btn, ...S.btnS}} onClick={modelKaydet}>KAYDET</button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* CARİ HESAP */}
      {tab === 'cari' && cari && (
        <div>
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr 1fr', gap:8, marginBottom:14}}>
            {[
              {l:'TOPLAM ALACAK', v:cari.ozet?.toplam_alacak, c:C.success},
              {l:'TOPLAM ÖDEME', v:cari.ozet?.toplam_borc, c:C.danger},
              {l:'NET BAKİYE', v:cari.ozet?.net_bakiye, c:C.accent},
              {l:'BEKLEYEN PRİM', v:cari.ozet?.bekleyen_prim_sayisi + ' adet', c:C.warning, isText:true},
            ].map((s, i) => (
              <div key={i} style={{padding:10, background:C.bgInput, borderRadius:6}}>
                <div style={{fontSize:9, color:C.textSec, fontWeight:700, textTransform:'uppercase'}}>{s.l}</div>
                <div style={{fontSize:14, fontWeight:800, color:s.c, marginTop:3}}>
                  {s.isText ? s.v : (s.v || 0).toLocaleString('tr-TR') + ' ₺'}
                </div>
              </div>
            ))}
          </div>
          <div style={{maxHeight:280, overflowY:'auto'}}>
            <table style={{width:'100%', fontSize:11, borderCollapse:'collapse'}}>
              <thead style={{background:C.bgInput, position:'sticky', top:0}}>
                <tr><th style={{padding:6, textAlign:'left'}}>Tarih</th><th style={{padding:6, textAlign:'left'}}>Açıklama</th>
                  <th style={{padding:6, textAlign:'right'}}>+</th><th style={{padding:6, textAlign:'right'}}>-</th>
                  <th style={{padding:6, textAlign:'right'}}>Bakiye</th></tr>
              </thead>
              <tbody>
                {cari.hareketler?.map((h, i) => (
                  <tr key={i} style={{borderBottom:`1px solid ${C.border}`}}>
                    <td style={{padding:6}}>{(h.tarih || '').slice(0,10)}</td>
                    <td style={{padding:6}}>{h.aciklama}</td>
                    <td style={{padding:6, textAlign:'right', color:C.success}}>{h.alacak ? h.alacak.toLocaleString('tr-TR') : '-'}</td>
                    <td style={{padding:6, textAlign:'right', color:C.danger}}>{h.borc ? h.borc.toLocaleString('tr-TR') : '-'}</td>
                    <td style={{padding:6, textAlign:'right', fontWeight:700}}>{h.bakiye?.toLocaleString('tr-TR')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ÖDEMELER */}
      {tab === 'odeme' && (
        <div>
          <button style={{...S.btn, ...S.btnP, marginBottom:14}} onClick={() => setOdemeOpen(true)}>+ YENİ ÖDEME YAP</button>
          {odemeOpen && (
            <div style={{padding:14, background:C.bgInput, borderRadius:8, marginBottom:14}}>
              <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:10}}>
                <div>
                  <div style={S.label}>ÖDEME TÜRÜ</div>
                  <select style={S.select} value={odemeData.odeme_turu} onChange={e => setOdemeData({...odemeData, odeme_turu:e.target.value})}>
                    <option value="maas">Maaş</option>
                    <option value="prim">Prim</option>
                    <option value="avans">Avans</option>
                    <option value="ikramiye">İkramiye</option>
                    <option value="mesai">Mesai</option>
                    <option value="diger">Diğer</option>
                  </select>
                </div>
                <div>
                  <div style={S.label}>TUTAR (TL)</div>
                  <input type="number" style={S.input} value={odemeData.tutar} onChange={e => setOdemeData({...odemeData, tutar:e.target.value})}/>
                </div>
                <div>
                  <div style={S.label}>KASA</div>
                  <select style={S.select} value={odemeData.kasa_id} onChange={e => setOdemeData({...odemeData, kasa_id:e.target.value})}>
                    <option value="">Seçin...</option>
                    {kasalar.map(k => <option key={k.id} value={k.id}>{k.ad} ({(k.bakiye || 0).toLocaleString('tr-TR')} ₺)</option>)}
                  </select>
                </div>
                <div>
                  <div style={S.label}>DÖNEM (YYYY-MM, opsiyonel)</div>
                  <input type="text" style={S.input} placeholder="2026-05" value={odemeData.donem} onChange={e => setOdemeData({...odemeData, donem:e.target.value})}/>
                </div>
              </div>
              <div style={{marginTop:10}}>
                <div style={S.label}>AÇIKLAMA</div>
                <input type="text" style={S.input} value={odemeData.aciklama} onChange={e => setOdemeData({...odemeData, aciklama:e.target.value})}/>
              </div>
              <div style={{display:'flex', gap:8, marginTop:14}}>
                <button style={{...S.btn, ...S.btnG}} onClick={() => setOdemeOpen(false)}>İPTAL</button>
                <button style={{...S.btn, ...S.btnS}} onClick={odemeYap}>ÖDEMEYİ KAYDET</button>
              </div>
            </div>
          )}
          {/* Ödeme listesi (cari'den çek) */}
          <table style={{width:'100%', fontSize:11, borderCollapse:'collapse'}}>
            <thead style={{background:C.bgInput}}>
              <tr><th style={{padding:6, textAlign:'left'}}>Tarih</th><th style={{padding:6, textAlign:'left'}}>Tür</th>
                <th style={{padding:6, textAlign:'left'}}>Açıklama</th><th style={{padding:6, textAlign:'right'}}>Tutar</th></tr>
            </thead>
            <tbody>
              {(cari?.hareketler || []).filter(h => h.tur === 'odeme').map((h, i) => (
                <tr key={i} style={{borderBottom:`1px solid ${C.border}`}}>
                  <td style={{padding:6}}>{(h.tarih || '').slice(0,10)}</td>
                  <td style={{padding:6, fontWeight:700, textTransform:'uppercase'}}>{h.odeme_turu}</td>
                  <td style={{padding:6}}>{h.aciklama}</td>
                  <td style={{padding:6, textAlign:'right', color:C.danger, fontWeight:700}}>{h.borc?.toLocaleString('tr-TR')} ₺</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* EVRAKLAR */}
      {tab === 'evrak' && (
        <div>
          <button style={{...S.btn, ...S.btnP, marginBottom:14}} onClick={() => setEvrakOpen(true)}>+ EVRAK YÜKLE (PDF/JPG)</button>
          {evrakOpen && (
            <div style={{padding:14, background:C.bgInput, borderRadius:8, marginBottom:14}}>
              <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:10}}>
                <div>
                  <div style={S.label}>EVRAK TÜRÜ</div>
                  <select style={S.select} value={evrakTuru} onChange={e => setEvrakTuru(e.target.value)}>
                    <option value="sozlesme">İş Sözleşmesi</option>
                    <option value="kvkk">KVKK Taahhütnamesi</option>
                    <option value="arac_zimmet">Araç Zimmet</option>
                    <option value="maas_dekontu">Maaş Dekontu</option>
                    <option value="avans_dekontu">Avans Dekontu</option>
                    <option value="kimlik">Kimlik / Ehliyet</option>
                    <option value="diger">Diğer</option>
                  </select>
                </div>
                <div>
                  <div style={S.label}>ETİKET (opsiyonel)</div>
                  <input type="text" style={S.input} placeholder="örn: Mart 2026 Maaş" value={evrakEtiketi} onChange={e => setEvrakEtiketi(e.target.value)}/>
                </div>
              </div>
              <div style={{marginTop:10}}>
                <input type="file" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx" onChange={e => setEvrakFile(e.target.files[0])}/>
              </div>
              <div style={{display:'flex', gap:8, marginTop:14}}>
                <button style={{...S.btn, ...S.btnG}} onClick={() => setEvrakOpen(false)}>İPTAL</button>
                <button style={{...S.btn, ...S.btnS}} onClick={evrakYukle}>YÜKLE</button>
              </div>
            </div>
          )}
          <div style={{display:'grid', gap:8}}>
            {evraklar.length === 0 && <div style={{textAlign:'center', color:C.textSec, padding:24}}>Henüz evrak yok</div>}
            {evraklar.map(e => (
              <div key={e.id} style={{display:'flex', alignItems:'center', gap:10, padding:10, background:C.bgInput, borderRadius:6}}>
                <div style={{flex:1}}>
                  <div style={{fontWeight:700, fontSize:12}}>{e.evrak_etiketi || e.dosya_adi}</div>
                  <div style={{fontSize:10, color:C.textSec}}>{e.evrak_turu} · {e.boyut_okunabilir} · {(e.created_at || '').slice(0,10)}</div>
                </div>
                <a href={e.preview_url} target="_blank" style={{...S.btnMini, ...S.btnMiniP, textDecoration:'none'}}>👁 ÖNİZLE</a>
                <a href={e.download_url} style={{...S.btnMini, ...S.btnMiniS, textDecoration:'none'}}>⬇ İNDİR</a>
                <button style={{...S.btnMini, ...S.btnMiniD}} onClick={() => evrakSil(e.id)}>🗑</button>
              </div>
            ))}
          </div>
        </div>
      )}

      <div style={{display:'flex', justifyContent:'flex-end', marginTop:18}}>
        <button style={{...S.btn, ...S.btnG}} onClick={onClose}>KAPAT</button>
      </div>
    </MR.Modal>
  );
};

/* ═══════════ PAYDAŞ KART MODAL ═══════════ */
MR.PaydasKartModal = ({open, onClose, paydas, user}) => {
  const {C, S, api} = MR;
  const [tab, setTab] = useState('genel');
  const [cari, setCari] = useState(null);
  const [evraklar, setEvraklar] = useState([]);
  const [evrakOpen, setEvrakOpen] = useState(false);
  const [evrakFile, setEvrakFile] = useState(null);
  const [evrakTuru, setEvrakTuru] = useState('sozlesme');
  const [evrakEtiketi, setEvrakEtiketi] = useState('');

  useEffect(() => {
    if (open && paydas?.id) yukle();
  }, [open, paydas?.id]);

  const yukle = async () => {
    const [c, e] = await Promise.all([
      api.req('/paydas/cari-hesap.php?id=' + paydas.id),
      api.req('/paydas/evrak-list.php?id=' + paydas.id)
    ]);
    if (c?.success) setCari(c.data);
    if (e?.success) setEvraklar(e.data || []);
  };

  const evrakYukle = async () => {
    if (!evrakFile) { MR.toast('Dosya seçin', 'error'); return; }
    const fd = new FormData();
    fd.append('paydas_id', paydas.id);
    fd.append('evrak_turu', evrakTuru);
    fd.append('evrak_etiketi', evrakEtiketi);
    fd.append('file', evrakFile);
    const h = {}; if (api.token) h['Authorization'] = 'Bearer ' + api.token;
    const r = await fetch('/api/v1/paydas/evrak-yukle.php', {method: 'POST', headers: h, body: fd}).then(r => r.json());
    if (r?.success) {
      MR.toast('Evrak yüklendi', 'success');
      setEvrakOpen(false); setEvrakFile(null); setEvrakEtiketi('');
      yukle();
    } else MR.toast(r?.error || 'Yükleme hatası', 'error');
  };

  const evrakSil = async (id) => {
    if (!confirm('Evrakı silmek istediğinize emin misiniz?')) return;
    const r = await api.req('/paydas/evrak-sil.php?id=' + id, {method: 'DELETE'});
    if (r?.success) { MR.toast('Evrak silindi', 'success'); yukle(); }
    else MR.toast(r?.error || 'Silme hatası', 'error');
  };

  if (!open) return null;

  return (
    <MR.Modal open={open} onClose={onClose} title={`PAYDAŞ KARTI — ${paydas?.ad || ''}`} width="900px">
      <div style={{display:'flex', gap:4, borderBottom:`1px solid ${C.border}`, marginBottom:16, padding:'0 4px'}}>
        {[
          {id:'genel', label:'GENEL', icon:'🤝'},
          {id:'cari',  label:'CARİ HESAP', icon:'📊'},
          {id:'evrak', label:'EVRAKLAR', icon:'📄'},
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            padding:'10px 16px', border:'none', background:tab===t.id?C.accent:'transparent',
            color:tab===t.id?'#fff':C.textSec, fontWeight:700, fontSize:11, letterSpacing:0.5,
            textTransform:'uppercase', cursor:'pointer', borderRadius:'7px 7px 0 0'
          }}>{t.icon} {t.label}</button>
        ))}
      </div>

      {tab === 'genel' && (
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:14}}>
          <div><div style={S.label}>AD</div><div style={{fontWeight:700}}>{paydas?.ad}</div></div>
          <div><div style={S.label}>TELEFON</div><div style={{fontWeight:700}}>{paydas?.telefon || '-'}</div></div>
          <div><div style={S.label}>EMAİL</div><div style={{fontWeight:700}}>{paydas?.email || '-'}</div></div>
          <div><div style={S.label}>KOMİSYON ORANI</div><div style={{fontWeight:700}}>%{paydas?.komisyon_orani || 0}</div></div>
          <div><div style={S.label}>PRİM ADK</div><div style={{fontWeight:700}}>{(paydas?.prim_adk || 0).toLocaleString('tr-TR')} TL</div></div>
          <div><div style={S.label}>PRİM BH</div><div style={{fontWeight:700}}>{(paydas?.prim_bh || 0).toLocaleString('tr-TR')} TL</div></div>
        </div>
      )}

      {tab === 'cari' && cari && (
        <div>
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8, marginBottom:14}}>
            {[
              {l:'TOPLAM KOMİSYON', v:cari.ozet?.toplam_komisyon, c:C.accent},
              {l:'ÖDENEN', v:cari.ozet?.odenen, c:C.success},
              {l:'BEKLEYEN', v:cari.ozet?.bekleyen, c:C.warning},
            ].map((s, i) => (
              <div key={i} style={{padding:10, background:C.bgInput, borderRadius:6}}>
                <div style={{fontSize:9, color:C.textSec, fontWeight:700}}>{s.l}</div>
                <div style={{fontSize:14, fontWeight:800, color:s.c, marginTop:3}}>
                  {(s.v || 0).toLocaleString('tr-TR')} ₺
                </div>
              </div>
            ))}
          </div>
          <table style={{width:'100%', fontSize:11, borderCollapse:'collapse'}}>
            <thead style={{background:C.bgInput}}>
              <tr><th style={{padding:6, textAlign:'left'}}>Tarih</th><th style={{padding:6, textAlign:'left'}}>Açıklama</th>
                <th style={{padding:6, textAlign:'right'}}>Tutar</th><th style={{padding:6, textAlign:'center'}}>Durum</th></tr>
            </thead>
            <tbody>
              {cari.hareketler?.map((h, i) => (
                <tr key={i} style={{borderBottom:`1px solid ${C.border}`}}>
                  <td style={{padding:6}}>{(h.tarih || '').slice(0,10)}</td>
                  <td style={{padding:6}}>{h.aciklama}</td>
                  <td style={{padding:6, textAlign:'right', fontWeight:700}}>{h.tutar?.toLocaleString('tr-TR')} ₺</td>
                  <td style={{padding:6, textAlign:'center'}}>
                    <span style={{...S.badge(h.durum === 'odendi' ? C.success : C.warning), fontSize:9}}>
                      {h.durum === 'odendi' ? '✓ ÖDENDİ' : 'BEKLEYEN'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'evrak' && (
        <div>
          <button style={{...S.btn, ...S.btnP, marginBottom:14}} onClick={() => setEvrakOpen(true)}>+ EVRAK YÜKLE</button>
          {evrakOpen && (
            <div style={{padding:14, background:C.bgInput, borderRadius:8, marginBottom:14}}>
              <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:10}}>
                <div>
                  <div style={S.label}>EVRAK TÜRÜ</div>
                  <select style={S.select} value={evrakTuru} onChange={e => setEvrakTuru(e.target.value)}>
                    <option value="sozlesme">Sözleşme</option>
                    <option value="dekont">Dekont</option>
                    <option value="diger">Diğer</option>
                  </select>
                </div>
                <div>
                  <div style={S.label}>ETİKET</div>
                  <input type="text" style={S.input} value={evrakEtiketi} onChange={e => setEvrakEtiketi(e.target.value)}/>
                </div>
              </div>
              <div style={{marginTop:10}}>
                <input type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={e => setEvrakFile(e.target.files[0])}/>
              </div>
              <div style={{display:'flex', gap:8, marginTop:14}}>
                <button style={{...S.btn, ...S.btnG}} onClick={() => setEvrakOpen(false)}>İPTAL</button>
                <button style={{...S.btn, ...S.btnS}} onClick={evrakYukle}>YÜKLE</button>
              </div>
            </div>
          )}
          <div style={{display:'grid', gap:8}}>
            {evraklar.length === 0 && <div style={{textAlign:'center', color:C.textSec, padding:24}}>Henüz evrak yok</div>}
            {evraklar.map(e => (
              <div key={e.id} style={{display:'flex', alignItems:'center', gap:10, padding:10, background:C.bgInput, borderRadius:6}}>
                <div style={{flex:1}}>
                  <div style={{fontWeight:700, fontSize:12}}>{e.evrak_etiketi || e.dosya_adi}</div>
                  <div style={{fontSize:10, color:C.textSec}}>{e.evrak_turu} · {e.boyut_okunabilir}</div>
                </div>
                <a href={e.preview_url} target="_blank" style={{...S.btnMini, ...S.btnMiniP, textDecoration:'none'}}>👁</a>
                <a href={e.download_url} style={{...S.btnMini, ...S.btnMiniS, textDecoration:'none'}}>⬇</a>
                <button style={{...S.btnMini, ...S.btnMiniD}} onClick={() => evrakSil(e.id)}>🗑</button>
              </div>
            ))}
          </div>
        </div>
      )}

      <div style={{display:'flex', justifyContent:'flex-end', marginTop:18}}>
        <button style={{...S.btn, ...S.btnG}} onClick={onClose}>KAPAT</button>
      </div>
    </MR.Modal>
  );
};
