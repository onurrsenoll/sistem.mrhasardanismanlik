/**
 * MR HASAR — v2.4.1 KART MODÜLLERİ (HOTFIX)
 *
 * Düzeltmeler:
 * - Modal full-screen tarzı dashboard (95vw + zengin görsel)
 * - Evrak önizleme/indirme: fetch+blob (JWT yetkili)
 * - Genel bilgilerde grid + avatar + büyük kartlar
 * - Cari hesap dashboard kartları + hareket tablosu büyütüldü
 * - Kazanç modeli: kademe görsel grid + şablon kartları
 * - Ödeme modal renklendirildi
 * - Evrak: thumbnail + büyük önizle butonu
 */
const MR = window.MR || (window.MR = {});
const {useState, useEffect, useCallback, useRef} = React;

/* ═══════════ EVRAK ÖNİZLEME / İNDİRME (FETCH + BLOB) ═══════════ */
MR._evrakAc = async (url, mode = 'inline', filename = 'evrak.pdf') => {
  const h = {};
  if (MR.api.token) h['Authorization'] = 'Bearer ' + MR.api.token;
  try {
    const r = await fetch(url, {headers: h});
    if (!r.ok) {
      MR.toast('Evrak açılamadı: ' + r.status + ' ' + r.statusText, 'error');
      return;
    }
    const blob = await r.blob();
    const blobUrl = URL.createObjectURL(blob);
    if (mode === 'inline') {
      // Yeni sekmede aç (önizleme)
      window.open(blobUrl, '_blank');
      // 60 saniye sonra blob URL'i temizle
      setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
    } else {
      // İndirme — link tıklamasıyla
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(blobUrl), 5000);
    }
  } catch (e) {
    MR.toast('Bağlantı hatası: ' + e.message, 'error');
  }
};

/* ═══════════ KÜÇÜK YARDIMCI: ÖZET KART ═══════════ */
const OzetKart = ({label, value, color, icon, sub}) => {
  const {C} = MR;
  return (
    <div style={{
      background: C.bgCard, borderRadius: 12, padding: '16px 18px',
      border: `1px solid ${C.border}`, borderLeft: `4px solid ${color || C.accent}`,
      boxShadow: C.cardShadow, transition: 'all .2s'
    }}>
      <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start'}}>
        <div style={{flex: 1}}>
          <div style={{fontSize: 9.5, fontWeight: 800, color: C.textSec, letterSpacing: 1, textTransform: 'uppercase'}}>{label}</div>
          <div style={{fontSize: 22, fontWeight: 900, color: color || C.text, marginTop: 6, fontFamily: 'system-ui'}}>{value}</div>
          {sub && <div style={{fontSize: 10, color: C.textMuted, marginTop: 4}}>{sub}</div>}
        </div>
        {icon && <div style={{fontSize: 28, opacity: 0.6}}>{icon}</div>}
      </div>
    </div>
  );
};

/* ═══════════ PERSONEL KART MODAL — v2.4.1 GENİŞLETİLMİŞ ═══════════ */
MR.PersonelKartModal = ({open, onClose, personel, user, onUpdate}) => {
  const {C, S, api} = MR;
  const [tab, setTab] = useState('genel');
  const [cari, setCari] = useState(null);
  const [evraklar, setEvraklar] = useState([]);
  const [model, setModel] = useState(null);
  const [sablonlar, setSablonlar] = useState({});
  const [loading, setLoading] = useState(false);

  const [odemeOpen, setOdemeOpen] = useState(false);
  const [odemeData, setOdemeData] = useState({odeme_turu: 'maas', tutar: '', kasa_id: '', donem: '', aciklama: ''});
  const [kasalar, setKasalar] = useState([]);
  const [evrakOpen, setEvrakOpen] = useState(false);
  const [evrakFile, setEvrakFile] = useState(null);
  const [evrakTuru, setEvrakTuru] = useState('sozlesme');
  const [evrakEtiketi, setEvrakEtiketi] = useState('');
  const [modelDuzenle, setModelDuzenle] = useState(false);

  useEffect(() => { if (open && personel?.id) yukle(); }, [open, personel?.id]);

  const yukle = async () => {
    setLoading(true);
    const [c, e, m, k] = await Promise.all([
      api.req('/personel/cari-hesap.php?id=' + personel.id),
      api.req('/personel/evrak-list.php?id=' + personel.id),
      api.req('/personel/kazanc-modeli-get.php?id=' + personel.id),
      api.kasaList()
    ]);
    if (c?.success) setCari(c.data);
    if (e?.success) setEvraklar(e.data || []);
    if (m?.success) { setModel(m.data); setSablonlar(m.data.sablonlar || {}); }
    if (k?.success) setKasalar(k.data || []);
    setLoading(false);
  };

  const odemeYap = async () => {
    if (!odemeData.tutar || !odemeData.kasa_id) { MR.toast('Tutar ve kasa zorunlu', 'error'); return; }
    const r = await api.req('/personel/odeme-yap.php', {
      method: 'POST',
      body: JSON.stringify({...odemeData, personel_id: personel.id, tutar: parseFloat(odemeData.tutar)})
    });
    if (r?.success) {
      MR.toast('Ödeme başarıyla yapıldı', 'success');
      setOdemeOpen(false);
      setOdemeData({odeme_turu: 'maas', tutar: '', kasa_id: '', donem: '', aciklama: ''});
      yukle();
    } else MR.toast(r?.error || 'Ödeme hatası', 'error');
  };

  const evrakYukle = async () => {
    if (!evrakFile) { MR.toast('Dosya seçin', 'error'); return; }
    const fd = new FormData();
    fd.append('personel_id', personel.id);
    fd.append('evrak_turu', evrakTuru);
    fd.append('evrak_etiketi', evrakEtiketi);
    fd.append('file', evrakFile);
    const h = {}; if (api.token) h['Authorization'] = 'Bearer ' + api.token;
    const r = await fetch('/api/v1/personel/evrak-yukle.php', {method: 'POST', headers: h, body: fd}).then(r => r.json());
    if (r?.success) {
      MR.toast('Evrak yüklendi', 'success');
      setEvrakOpen(false); setEvrakFile(null); setEvrakEtiketi('');
      yukle();
    } else MR.toast(r?.error || 'Yükleme hatası', 'error');
  };

  const evrakSil = async (id) => {
    if (!confirm('Evrakı silmek istediğinize emin misiniz?')) return;
    const r = await api.req('/personel/evrak-sil.php?id=' + id, {method: 'DELETE'});
    if (r?.success) { MR.toast('Evrak silindi', 'success'); yukle(); }
    else MR.toast(r?.error || 'Silme hatası', 'error');
  };

  const sablonUygula = (key) => {
    const s = sablonlar[key];
    if (!s) return;
    setModel({...model, aktif_model: {
      ...s,
      saha_kademe_json: JSON.stringify(s.saha_kademe || []),
      ofis_kota_json: JSON.stringify(s.ofis_kota || {}),
      yillik_bonus_json: JSON.stringify(s.yillik_bonus || []),
      saha_kademe: s.saha_kademe || [],
      ofis_kota: s.ofis_kota || {},
      yillik_bonus: s.yillik_bonus || []
    }});
    setModelDuzenle(true);
  };

  const modelKaydet = async () => {
    const m = model.aktif_model;
    const r = await api.req('/personel/kazanc-modeli-set.php', {
      method: 'POST',
      body: JSON.stringify({
        personel_id: personel.id,
        model_tipi: m.model_tipi,
        sabit_maas: parseFloat(m.sabit_maas) || 0,
        yemek_gunluk: parseFloat(m.yemek_gunluk) || 0,
        yemek_gun_sayisi: parseInt(m.yemek_gun_sayisi) || 22,
        prim_adk: parseFloat(m.prim_adk) || 0,
        prim_bh: parseFloat(m.prim_bh) || 0,
        saha_kademe: m.saha_kademe || (m.saha_kademe_json ? JSON.parse(m.saha_kademe_json) : []),
        ofis_kota: m.ofis_kota || (m.ofis_kota_json ? JSON.parse(m.ofis_kota_json) : {}),
        yillik_bonus: m.yillik_bonus || (m.yillik_bonus_json ? JSON.parse(m.yillik_bonus_json) : []),
        gecerlilik_baslangic: m.gecerlilik_baslangic || new Date().toISOString().slice(0,10)
      })
    });
    if (r?.success) {
      MR.toast('Kazanç modeli kaydedildi', 'success');
      setModelDuzenle(false);
      yukle();
    } else MR.toast(r?.error || 'Kayıt hatası', 'error');
  };

  if (!open) return null;

  const odemeler = (cari?.hareketler || []).filter(h => h.tur === 'odeme');

  return (
    <MR.Modal open={open} onClose={onClose} title={`PERSONEL KARTI — ${personel?.ad_soyad || ''}`} width="95vw">
      <div style={{display:'flex', flexDirection:'column', height:'82vh'}}>

        {/* ÜST PROFIL ÇUBUĞU */}
        <div style={{display:'flex', alignItems:'center', gap:18, padding:'16px 20px', background:`linear-gradient(135deg, ${C.accent}11, ${C.accent}05)`, border:`1px solid ${C.border}`, borderRadius:12, marginBottom:14}}>
          <div style={{width:60, height:60, borderRadius:'50%', background:C.accent, color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:24, fontWeight:900}}>
            {(personel?.ad_soyad || '?').slice(0,1).toUpperCase()}
          </div>
          <div style={{flex:1}}>
            <div style={{fontSize:18, fontWeight:800, color:C.text}}>{personel?.ad_soyad}</div>
            <div style={{fontSize:12, color:C.textSec, marginTop:3}}>
              {personel?.departman || '-'} · {personel?.telefon || '-'}
              {personel?.durum && <span style={{marginLeft:10, padding:'2px 8px', borderRadius:9999, background:`${C.success}18`, color:C.success, fontSize:10, fontWeight:700, textTransform:'uppercase'}}>{personel.durum}</span>}
            </div>
          </div>
          {cari?.ozet && (
            <div style={{display:'flex', gap:14}}>
              <div style={{textAlign:'right'}}>
                <div style={{fontSize:9, color:C.textSec, fontWeight:700, textTransform:'uppercase'}}>NET BAKİYE</div>
                <div style={{fontSize:18, fontWeight:900, color:cari.ozet.net_bakiye >= 0 ? C.success : C.danger}}>
                  {(cari.ozet.net_bakiye || 0).toLocaleString('tr-TR')} ₺
                </div>
              </div>
            </div>
          )}
        </div>

        {/* TAB MENU */}
        <div style={{display:'flex', gap:4, borderBottom:`1px solid ${C.border}`, marginBottom:14}}>
          {[
            {id:'genel',  label:'GENEL BİLGİLER', icon:'👤'},
            {id:'model',  label:'KAZANÇ MODELİ', icon:'💰'},
            {id:'cari',   label:'CARİ HESAP', icon:'📊'},
            {id:'odeme',  label:'ÖDEMELER', icon:'💵'},
            {id:'evrak',  label:'EVRAKLAR', icon:'📄'},
          ].map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              padding:'12px 20px', border:'none', background:tab===t.id ? C.accent : 'transparent',
              color: tab===t.id ? '#fff' : C.textSec, fontWeight:700, fontSize:12, letterSpacing:0.5,
              textTransform:'uppercase', cursor:'pointer', borderRadius:'8px 8px 0 0', transition:'all .15s'
            }}>{t.icon} {t.label}</button>
          ))}
        </div>

        {/* İÇERİK SCROLL ALANI */}
        <div style={{flex:1, overflowY:'auto', paddingRight:6}}>

        {/* GENEL BİLGİLER */}
        {tab === 'genel' && (
          <div style={{display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:14}}>
            <OzetKart label="AD SOYAD" value={personel?.ad_soyad || '-'} color={C.accent} icon="👤"/>
            <OzetKart label="DEPARTMAN" value={personel?.departman || '-'} color={C.purple} icon="🏢"/>
            <OzetKart label="TELEFON" value={personel?.telefon || '-'} color={C.success} icon="📞"/>
            <OzetKart label="EMAIL" value={personel?.email || '-'} color={C.cyan} icon="✉️"/>
            <OzetKart label="İŞE BAŞLAMA" value={personel?.ise_baslama || '-'} color={C.warning} icon="📅"/>
            <OzetKart label="DURUM" value={personel?.durum || 'aktif'} color={C.success} icon="✓"/>
            {personel?.tc_kimlik && <OzetKart label="TC KİMLİK" value={personel.tc_kimlik} color={C.textSec} icon="🆔"/>}
            {personel?.adres && <OzetKart label="ADRES" value={personel.adres} color={C.textSec} icon="📍" sub={personel.il}/>}
            {personel?.iban && <OzetKart label="IBAN" value={personel.iban} color={C.accent} icon="🏦"/>}
          </div>
        )}

        {/* KAZANÇ MODELİ */}
        {tab === 'model' && (
          <div>
            {!modelDuzenle && model?.aktif_model && (
              <div>
                <div style={{display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:12, marginBottom:18}}>
                  <OzetKart label="MODEL TİPİ" value={(model.aktif_model.model_tipi || '').toUpperCase().replace('_',' ')} color={C.accent} icon="🎯"/>
                  <OzetKart label="SABİT MAAŞ" value={(parseFloat(model.aktif_model.sabit_maas) || 0).toLocaleString('tr-TR') + ' ₺'} color={C.success} icon="💰"/>
                  <OzetKart label="YEMEK GÜNLÜK" value={(parseFloat(model.aktif_model.yemek_gunluk) || 0) + ' ₺'} color={C.warning} icon="🍽️" sub={(model.aktif_model.yemek_gun_sayisi || 22) + ' iş günü'}/>
                  <OzetKart label="GEÇERLİLİK" value={model.aktif_model.gecerlilik_baslangic} color={C.purple} icon="📅" sub="başlangıç"/>
                </div>

                {/* Kademe tablosu görsel */}
                {model.aktif_model.model_tipi === 'kademeli_saha' && model.aktif_model.saha_kademe?.length > 0 && (
                  <div style={{marginBottom:18}}>
                    <div style={{fontSize:13, fontWeight:800, marginBottom:10, color:C.text, letterSpacing:0.5}}>📊 SAHA KADEMELERİ</div>
                    <div style={{display:'grid', gridTemplateColumns:`repeat(${model.aktif_model.saha_kademe.length}, 1fr)`, gap:8}}>
                      {model.aktif_model.saha_kademe.map((k, i) => (
                        <div key={i} style={{padding:14, background:C.bgCard, borderRadius:10, border:`2px solid ${k.birim > 0 ? C.success : C.border}`, textAlign:'center'}}>
                          <div style={{fontSize:10, color:C.textSec, fontWeight:700}}>{k.etiket}</div>
                          <div style={{fontSize:14, fontWeight:900, color:C.text, margin:'6px 0'}}>{k.min}-{k.max === 999 ? '+' : k.max} dosya</div>
                          <div style={{fontSize:18, fontWeight:900, color:k.birim > 0 ? C.success : C.textSec}}>
                            {k.birim > 0 ? k.birim.toLocaleString('tr-TR') + ' ₺' : '—'}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Yıllık bonus */}
                {model.aktif_model.yillik_bonus?.length > 0 && (
                  <div style={{marginBottom:18}}>
                    <div style={{fontSize:13, fontWeight:800, marginBottom:10, color:C.text}}>🏆 YILLIK BONUS</div>
                    <div style={{display:'grid', gridTemplateColumns:`repeat(${model.aktif_model.yillik_bonus.length}, 1fr)`, gap:8}}>
                      {model.aktif_model.yillik_bonus.map((b, i) => {
                        const renk = i === 0 ? '#cd7f32' : i === 1 ? '#c0c0c0' : '#ffd700';
                        const ikon = i === 0 ? '🥉' : i === 1 ? '🥈' : '🥇';
                        return (
                          <div key={i} style={{padding:14, background:C.bgCard, borderRadius:10, border:`2px solid ${renk}`, textAlign:'center'}}>
                            <div style={{fontSize:24}}>{ikon}</div>
                            <div style={{fontSize:11, color:renk, fontWeight:800, textTransform:'uppercase'}}>{b.etiket}</div>
                            <div style={{fontSize:10, color:C.textSec, margin:'4px 0'}}>{b.min}-{b.max} dosya/yıl</div>
                            <div style={{fontSize:16, fontWeight:900, color:renk}}>{b.bonus.toLocaleString('tr-TR')} ₺</div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                <button style={{...S.btn, ...S.btnP}} onClick={() => setModelDuzenle(true)}>✏️ MODELİ DÜZENLE</button>
              </div>
            )}

            {!modelDuzenle && !model?.aktif_model && (
              <div style={{padding:30, textAlign:'center'}}>
                <div style={{fontSize:48, marginBottom:14}}>⚠️</div>
                <div style={{color:C.warning, fontWeight:800, fontSize:16, marginBottom:8}}>HENÜZ KAZANÇ MODELİ TANIMLANMAMIŞ</div>
                <div style={{color:C.textSec, fontSize:13, marginBottom:24}}>Bir şablondan başlayın veya boş model oluşturun:</div>
                <div style={{display:'grid', gridTemplateColumns:'repeat(2, 1fr)', gap:12, maxWidth:760, margin:'0 auto'}}>
                  {Object.entries(sablonlar).map(([key, s]) => (
                    <div key={key} style={{padding:16, background:C.bgCard, borderRadius:12, border:`2px solid ${C.border}`, cursor:'pointer', transition:'all .2s'}}
                      onMouseEnter={e => {e.currentTarget.style.borderColor = C.accent; e.currentTarget.style.transform = 'translateY(-2px)';}}
                      onMouseLeave={e => {e.currentTarget.style.borderColor = C.border; e.currentTarget.style.transform = 'translateY(0)';}}
                      onClick={() => sablonUygula(key)}>
                      <div style={{fontSize:13, fontWeight:800, color:C.text, marginBottom:6}}>{s.etiket}</div>
                      <div style={{fontSize:10, color:C.textSec}}>
                        Tip: {s.model_tipi} · Maaş: {(s.sabit_maas || 0).toLocaleString('tr-TR')} TL
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {modelDuzenle && (
              <div style={{display:'grid', gap:14}}>
                <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:12}}>
                  <div>
                    <div style={S.label}>MODEL TİPİ</div>
                    <select style={S.select} value={model.aktif_model?.model_tipi || 'sabit'}
                      onChange={e => setModel({...model, aktif_model:{...model.aktif_model, model_tipi:e.target.value}})}>
                      <option value="sabit">Sabit Maaş</option>
                      <option value="sabit_prim">Sabit Maaş + Dosya Başı Prim</option>
                      <option value="kademeli_saha">Kademeli Saha (toplam dosya)</option>
                      <option value="kademeli_ofis">Kademeli Ofis (ADK + BH ayrı)</option>
                    </select>
                  </div>
                  <div>
                    <div style={S.label}>GEÇERLİLİK BAŞLANGIÇ</div>
                    <input type="date" style={S.input}
                      value={model.aktif_model?.gecerlilik_baslangic || new Date().toISOString().slice(0,10)}
                      onChange={e => setModel({...model, aktif_model:{...model.aktif_model, gecerlilik_baslangic:e.target.value}})}/>
                  </div>
                  <div>
                    <div style={S.label}>SABİT MAAŞ (TL)</div>
                    <input type="number" style={S.input}
                      value={model.aktif_model?.sabit_maas || 0}
                      onChange={e => setModel({...model, aktif_model:{...model.aktif_model, sabit_maas:e.target.value}})}/>
                  </div>
                  <div>
                    <div style={S.label}>YEMEK GÜNLÜK (TL)</div>
                    <input type="number" style={S.input}
                      value={model.aktif_model?.yemek_gunluk || 0}
                      onChange={e => setModel({...model, aktif_model:{...model.aktif_model, yemek_gunluk:e.target.value}})}/>
                  </div>
                </div>

                {model.aktif_model?.model_tipi === 'sabit_prim' && (
                  <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:12}}>
                    <div><div style={S.label}>PRİM ADK (TL/dosya)</div><input type="number" style={S.input} value={model.aktif_model?.prim_adk || 0} onChange={e => setModel({...model, aktif_model:{...model.aktif_model, prim_adk:e.target.value}})}/></div>
                    <div><div style={S.label}>PRİM BH (TL/dosya)</div><input type="number" style={S.input} value={model.aktif_model?.prim_bh || 0} onChange={e => setModel({...model, aktif_model:{...model.aktif_model, prim_bh:e.target.value}})}/></div>
                  </div>
                )}

                {(model.aktif_model?.model_tipi === 'kademeli_saha' || model.aktif_model?.model_tipi === 'kademeli_ofis') && (
                  <div style={{padding:14, background:C.bgInput, borderRadius:8, fontSize:11, color:C.textSec, lineHeight:1.6}}>
                    📌 Kademeli model parametreleri şablondan yüklendi. Kademe tablosu, yıllık bonus eşikleri otomatik hazır.
                    <br/>İleri seviye düzenleme (özel kademeler) için sistem yöneticisine danışın.
                  </div>
                )}

                <div style={{display:'flex', gap:8, marginTop:14}}>
                  <button style={{...S.btn, ...S.btnG}} onClick={() => setModelDuzenle(false)}>İPTAL</button>
                  <button style={{...S.btn, ...S.btnS}} onClick={modelKaydet}>💾 KAYDET</button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* CARİ HESAP */}
        {tab === 'cari' && cari && (
          <div>
            <div style={{display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:12, marginBottom:18}}>
              <OzetKart label="TOPLAM ALACAK" value={(cari.ozet?.toplam_alacak || 0).toLocaleString('tr-TR') + ' ₺'} color={C.success} icon="📈"/>
              <OzetKart label="TOPLAM ÖDEME" value={(cari.ozet?.toplam_borc || 0).toLocaleString('tr-TR') + ' ₺'} color={C.danger} icon="📉"/>
              <OzetKart label="NET BAKİYE" value={(cari.ozet?.net_bakiye || 0).toLocaleString('tr-TR') + ' ₺'} color={C.accent} icon="💼"/>
              <OzetKart label="BEKLEYEN PRİM" value={(cari.ozet?.bekleyen_prim_sayisi || 0) + ' adet'} color={C.warning} icon="⏳"/>
            </div>
            <div style={{background:C.bgCard, borderRadius:10, border:`1px solid ${C.border}`, overflow:'hidden'}}>
              <div style={{padding:'10px 14px', borderBottom:`1px solid ${C.border}`, fontSize:12, fontWeight:800, color:C.text, letterSpacing:0.5}}>
                📋 HAREKET DÖKÜMü ({cari.hareketler?.length || 0} kayıt)
              </div>
              <div style={{maxHeight:'40vh', overflowY:'auto'}}>
                <table style={{width:'100%', fontSize:11, borderCollapse:'collapse'}}>
                  <thead style={{background:C.bgInput, position:'sticky', top:0, zIndex:1}}>
                    <tr>
                      <th style={{padding:'8px 10px', textAlign:'left', fontWeight:700, color:C.textSec}}>TARİH</th>
                      <th style={{padding:'8px 10px', textAlign:'left', fontWeight:700, color:C.textSec}}>AÇIKLAMA</th>
                      <th style={{padding:'8px 10px', textAlign:'right', fontWeight:700, color:C.success}}>+ ALACAK</th>
                      <th style={{padding:'8px 10px', textAlign:'right', fontWeight:700, color:C.danger}}>- ÖDEME</th>
                      <th style={{padding:'8px 10px', textAlign:'right', fontWeight:700, color:C.accent}}>BAKİYE</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(cari.hareketler || []).map((h, i) => (
                      <tr key={i} style={{borderBottom:`1px solid ${C.border}`, background: i % 2 === 0 ? 'transparent' : C.bgHover + '30'}}>
                        <td style={{padding:'7px 10px', color:C.textSec}}>{(h.tarih || '').slice(0,10)}</td>
                        <td style={{padding:'7px 10px', color:C.text}}>{h.aciklama}</td>
                        <td style={{padding:'7px 10px', textAlign:'right', color:C.success, fontWeight:700}}>{h.alacak ? h.alacak.toLocaleString('tr-TR') : '-'}</td>
                        <td style={{padding:'7px 10px', textAlign:'right', color:C.danger, fontWeight:700}}>{h.borc ? h.borc.toLocaleString('tr-TR') : '-'}</td>
                        <td style={{padding:'7px 10px', textAlign:'right', fontWeight:800, color:C.accent}}>{h.bakiye?.toLocaleString('tr-TR')}</td>
                      </tr>
                    ))}
                    {(!cari.hareketler || cari.hareketler.length === 0) && (
                      <tr><td colSpan="5" style={{padding:30, textAlign:'center', color:C.textSec}}>Henüz hareket yok</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ÖDEMELER */}
        {tab === 'odeme' && (
          <div>
            <button style={{...S.btn, ...S.btnP, marginBottom:14}} onClick={() => setOdemeOpen(!odemeOpen)}>
              {odemeOpen ? '✕ İPTAL' : '+ YENİ ÖDEME YAP'}
            </button>
            {odemeOpen && (
              <div style={{padding:18, background:C.bgCard, border:`2px solid ${C.accent}`, borderRadius:10, marginBottom:18}}>
                <div style={{fontSize:13, fontWeight:800, marginBottom:14, color:C.accent}}>💵 YENİ ÖDEME OLUŞTUR</div>
                <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:12}}>
                  <div>
                    <div style={S.label}>ÖDEME TÜRÜ</div>
                    <select style={S.select} value={odemeData.odeme_turu} onChange={e => setOdemeData({...odemeData, odeme_turu:e.target.value})}>
                      <option value="maas">💰 Maaş</option>
                      <option value="prim">🎯 Prim</option>
                      <option value="avans">⚡ Avans</option>
                      <option value="ikramiye">🏆 İkramiye</option>
                      <option value="mesai">⏰ Mesai</option>
                      <option value="diger">📋 Diğer</option>
                    </select>
                  </div>
                  <div>
                    <div style={S.label}>TUTAR (TL)</div>
                    <input type="number" style={S.input} value={odemeData.tutar} onChange={e => setOdemeData({...odemeData, tutar:e.target.value})}/>
                  </div>
                  <div>
                    <div style={S.label}>KASA</div>
                    <select style={S.select} value={odemeData.kasa_id} onChange={e => setOdemeData({...odemeData, kasa_id:e.target.value})}>
                      <option value="">Seçin...</option>
                      {kasalar.map(k => <option key={k.id} value={k.id}>{k.ad} ({(parseFloat(k.bakiye) || 0).toLocaleString('tr-TR')} ₺)</option>)}
                    </select>
                  </div>
                  <div>
                    <div style={S.label}>DÖNEM (YYYY-MM)</div>
                    <input type="text" style={S.input} placeholder="örn: 2026-05" value={odemeData.donem} onChange={e => setOdemeData({...odemeData, donem:e.target.value})}/>
                  </div>
                </div>
                <div style={{marginTop:12}}>
                  <div style={S.label}>AÇIKLAMA</div>
                  <input type="text" style={S.input} value={odemeData.aciklama} onChange={e => setOdemeData({...odemeData, aciklama:e.target.value})}/>
                </div>
                <div style={{display:'flex', gap:10, marginTop:18, justifyContent:'flex-end'}}>
                  <button style={{...S.btn, ...S.btnG}} onClick={() => setOdemeOpen(false)}>İPTAL</button>
                  <button style={{...S.btn, ...S.btnS}} onClick={odemeYap}>✓ ÖDEMEYİ KAYDET</button>
                </div>
              </div>
            )}
            <div style={{background:C.bgCard, borderRadius:10, border:`1px solid ${C.border}`, overflow:'hidden'}}>
              <div style={{padding:'10px 14px', borderBottom:`1px solid ${C.border}`, fontSize:12, fontWeight:800, color:C.text}}>
                💵 ÖDEME GEÇMİŞİ ({odemeler.length} kayıt)
              </div>
              <table style={{width:'100%', fontSize:12, borderCollapse:'collapse'}}>
                <thead style={{background:C.bgInput}}>
                  <tr>
                    <th style={{padding:'8px 10px', textAlign:'left'}}>TARİH</th>
                    <th style={{padding:'8px 10px', textAlign:'left'}}>TÜR</th>
                    <th style={{padding:'8px 10px', textAlign:'left'}}>AÇIKLAMA</th>
                    <th style={{padding:'8px 10px', textAlign:'right'}}>TUTAR</th>
                  </tr>
                </thead>
                <tbody>
                  {odemeler.map((h, i) => (
                    <tr key={i} style={{borderBottom:`1px solid ${C.border}`}}>
                      <td style={{padding:'8px 10px', color:C.textSec}}>{(h.tarih || '').slice(0,10)}</td>
                      <td style={{padding:'8px 10px'}}>
                        <span style={{padding:'2px 8px', borderRadius:9999, background:`${C.accent}18`, color:C.accent, fontSize:10, fontWeight:700, textTransform:'uppercase'}}>{h.odeme_turu}</span>
                      </td>
                      <td style={{padding:'8px 10px', color:C.text}}>{h.aciklama}</td>
                      <td style={{padding:'8px 10px', textAlign:'right', color:C.danger, fontWeight:800}}>{h.borc?.toLocaleString('tr-TR')} ₺</td>
                    </tr>
                  ))}
                  {odemeler.length === 0 && <tr><td colSpan="4" style={{padding:30, textAlign:'center', color:C.textSec}}>Henüz ödeme yok</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* EVRAKLAR */}
        {tab === 'evrak' && (
          <div>
            <button style={{...S.btn, ...S.btnP, marginBottom:14}} onClick={() => setEvrakOpen(!evrakOpen)}>
              {evrakOpen ? '✕ İPTAL' : '+ EVRAK YÜKLE (PDF/JPG)'}
            </button>
            {evrakOpen && (
              <div style={{padding:18, background:C.bgCard, border:`2px solid ${C.accent}`, borderRadius:10, marginBottom:18}}>
                <div style={{fontSize:13, fontWeight:800, marginBottom:14, color:C.accent}}>📄 YENİ EVRAK YÜKLE</div>
                <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:12}}>
                  <div>
                    <div style={S.label}>EVRAK TÜRÜ</div>
                    <select style={S.select} value={evrakTuru} onChange={e => setEvrakTuru(e.target.value)}>
                      <option value="sozlesme">📜 İş Sözleşmesi</option>
                      <option value="kvkk">🔒 KVKK Taahhütnamesi</option>
                      <option value="arac_zimmet">🚗 Araç Zimmet</option>
                      <option value="maas_dekontu">💰 Maaş Dekontu</option>
                      <option value="avans_dekontu">⚡ Avans Dekontu</option>
                      <option value="kimlik">🆔 Kimlik / Ehliyet</option>
                      <option value="diger">📋 Diğer</option>
                    </select>
                  </div>
                  <div>
                    <div style={S.label}>ETİKET</div>
                    <input type="text" style={S.input} placeholder="örn: 2026 Mart Maaş Dekontu" value={evrakEtiketi} onChange={e => setEvrakEtiketi(e.target.value)}/>
                  </div>
                </div>
                <div style={{marginTop:12}}>
                  <div style={S.label}>DOSYA SEÇ</div>
                  <input type="file" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx" onChange={e => setEvrakFile(e.target.files[0])}
                    style={{padding:8, background:C.bgInput, border:`1px dashed ${C.border}`, borderRadius:6, width:'100%'}}/>
                </div>
                <div style={{display:'flex', gap:10, marginTop:18, justifyContent:'flex-end'}}>
                  <button style={{...S.btn, ...S.btnG}} onClick={() => setEvrakOpen(false)}>İPTAL</button>
                  <button style={{...S.btn, ...S.btnS}} onClick={evrakYukle}>✓ YÜKLE</button>
                </div>
              </div>
            )}
            <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(280px, 1fr))', gap:12}}>
              {evraklar.length === 0 && (
                <div style={{gridColumn:'1/-1', textAlign:'center', color:C.textSec, padding:40, background:C.bgCard, borderRadius:10, border:`1px dashed ${C.border}`}}>
                  📭 Henüz evrak yüklenmedi
                </div>
              )}
              {evraklar.map(ev => (
                <div key={ev.id} style={{padding:14, background:C.bgCard, border:`1px solid ${C.border}`, borderRadius:10, transition:'all .2s'}}>
                  <div style={{display:'flex', alignItems:'center', gap:10, marginBottom:10}}>
                    <div style={{width:42, height:42, borderRadius:8, background:`${C.accent}18`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:22}}>
                      {(ev.mime_type || '').includes('pdf') ? '📄' : (ev.mime_type || '').includes('image') ? '🖼️' : '📎'}
                    </div>
                    <div style={{flex:1, minWidth:0}}>
                      <div style={{fontSize:12, fontWeight:800, color:C.text, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap'}}>{ev.evrak_etiketi || ev.dosya_adi}</div>
                      <div style={{fontSize:10, color:C.textSec, marginTop:2}}>{ev.evrak_turu} · {ev.boyut_okunabilir}</div>
                    </div>
                  </div>
                  <div style={{fontSize:9, color:C.textMuted, marginBottom:10}}>
                    {(ev.created_at || '').slice(0,16)} · {ev.yukleyen_adi || 'Sistem'}
                  </div>
                  <div style={{display:'flex', gap:6}}>
                    <button style={{...S.btnMini, ...S.btnMiniP, flex:1}}
                      onClick={() => MR._evrakAc(ev.preview_url, 'inline', ev.dosya_adi)}>
                      👁 ÖNİZLE
                    </button>
                    <button style={{...S.btnMini, ...S.btnMiniS, flex:1}}
                      onClick={() => MR._evrakAc(ev.download_url, 'download', ev.dosya_adi)}>
                      ⬇ İNDİR
                    </button>
                    <button style={{...S.btnMini, ...S.btnMiniD}} onClick={() => evrakSil(ev.id)}>🗑</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        </div>

        {/* ALT — KAPAT BUTONU */}
        <div style={{display:'flex', justifyContent:'flex-end', marginTop:14, paddingTop:14, borderTop:`1px solid ${C.border}`}}>
          <button style={{...S.btn, ...S.btnG}} onClick={onClose}>KAPAT</button>
        </div>
      </div>
    </MR.Modal>
  );
};

/* ═══════════ PAYDAŞ KART MODAL — v2.4.1 GENİŞLETİLMİŞ ═══════════ */
MR.PaydasKartModal = ({open, onClose, paydas, user}) => {
  const {C, S, api} = MR;
  const [tab, setTab] = useState('genel');
  const [cari, setCari] = useState(null);
  const [evraklar, setEvraklar] = useState([]);
  const [evrakOpen, setEvrakOpen] = useState(false);
  const [evrakFile, setEvrakFile] = useState(null);
  const [evrakTuru, setEvrakTuru] = useState('sozlesme');
  const [evrakEtiketi, setEvrakEtiketi] = useState('');

  useEffect(() => { if (open && paydas?.id) yukle(); }, [open, paydas?.id]);

  const yukle = async () => {
    const [c, e] = await Promise.all([
      api.req('/paydas/cari-hesap.php?id=' + paydas.id),
      api.req('/paydas/evrak-list.php?id=' + paydas.id)
    ]);
    if (c?.success) setCari(c.data);
    if (e?.success) setEvraklar(e.data || []);
  };

  const evrakYukle = async () => {
    if (!evrakFile) { MR.toast('Dosya seçin', 'error'); return; }
    const fd = new FormData();
    fd.append('paydas_id', paydas.id);
    fd.append('evrak_turu', evrakTuru);
    fd.append('evrak_etiketi', evrakEtiketi);
    fd.append('file', evrakFile);
    const h = {}; if (api.token) h['Authorization'] = 'Bearer ' + api.token;
    const r = await fetch('/api/v1/paydas/evrak-yukle.php', {method: 'POST', headers: h, body: fd}).then(r => r.json());
    if (r?.success) {
      MR.toast('Evrak yüklendi', 'success');
      setEvrakOpen(false); setEvrakFile(null); setEvrakEtiketi('');
      yukle();
    } else MR.toast(r?.error || 'Yükleme hatası', 'error');
  };

  const evrakSil = async (id) => {
    if (!confirm('Evrakı silmek istediğinize emin misiniz?')) return;
    const r = await api.req('/paydas/evrak-sil.php?id=' + id, {method: 'DELETE'});
    if (r?.success) { MR.toast('Evrak silindi', 'success'); yukle(); }
    else MR.toast(r?.error || 'Silme hatası', 'error');
  };

  if (!open) return null;

  return (
    <MR.Modal open={open} onClose={onClose} title={`PAYDAŞ KARTI — ${paydas?.ad || ''}`} width="92vw">
      <div style={{display:'flex', flexDirection:'column', height:'80vh'}}>

        {/* ÜST PROFIL */}
        <div style={{display:'flex', alignItems:'center', gap:18, padding:'16px 20px', background:`linear-gradient(135deg, ${C.purple}11, ${C.purple}05)`, border:`1px solid ${C.border}`, borderRadius:12, marginBottom:14}}>
          <div style={{width:60, height:60, borderRadius:'50%', background:C.purple, color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:24, fontWeight:900}}>
            {(paydas?.ad || '?').slice(0,1).toUpperCase()}
          </div>
          <div style={{flex:1}}>
            <div style={{fontSize:18, fontWeight:800, color:C.text}}>{paydas?.ad}</div>
            <div style={{fontSize:12, color:C.textSec, marginTop:3}}>
              {paydas?.tur || '-'} · {paydas?.telefon || '-'}
            </div>
          </div>
          {cari?.ozet && (
            <div style={{display:'flex', gap:14}}>
              <div style={{textAlign:'right'}}>
                <div style={{fontSize:9, color:C.textSec, fontWeight:700, textTransform:'uppercase'}}>BEKLEYEN</div>
                <div style={{fontSize:18, fontWeight:900, color:cari.ozet.bekleyen > 0 ? C.warning : C.success}}>
                  {(cari.ozet.bekleyen || 0).toLocaleString('tr-TR')} ₺
                </div>
              </div>
            </div>
          )}
        </div>

        {/* TAB */}
        <div style={{display:'flex', gap:4, borderBottom:`1px solid ${C.border}`, marginBottom:14}}>
          {[
            {id:'genel', label:'GENEL', icon:'🤝'},
            {id:'cari',  label:'CARİ HESAP', icon:'📊'},
            {id:'evrak', label:'EVRAKLAR', icon:'📄'},
          ].map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              padding:'12px 20px', border:'none', background:tab===t.id ? C.purple : 'transparent',
              color: tab===t.id ? '#fff' : C.textSec, fontWeight:700, fontSize:12, letterSpacing:0.5,
              textTransform:'uppercase', cursor:'pointer', borderRadius:'8px 8px 0 0'
            }}>{t.icon} {t.label}</button>
          ))}
        </div>

        <div style={{flex:1, overflowY:'auto', paddingRight:6}}>

        {tab === 'genel' && (
          <div style={{display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:12}}>
            <OzetKart label="AD" value={paydas?.ad || '-'} color={C.purple} icon="🤝"/>
            <OzetKart label="YETKİLİ" value={paydas?.yetkili || '-'} color={C.accent} icon="👤"/>
            <OzetKart label="TÜR" value={paydas?.tur || '-'} color={C.cyan} icon="🏷️"/>
            <OzetKart label="TELEFON" value={paydas?.telefon || '-'} color={C.success} icon="📞"/>
            <OzetKart label="EMAIL" value={paydas?.email || '-'} color={C.cyan} icon="✉️"/>
            <OzetKart label="İL" value={paydas?.il || '-'} color={C.warning} icon="📍"/>
            <OzetKart label="KOMİSYON ORANI" value={'%' + (paydas?.komisyon_orani || 0)} color={C.accent} icon="📊"/>
            <OzetKart label="PRİM ADK" value={(parseFloat(paydas?.prim_adk) || 0).toLocaleString('tr-TR') + ' ₺'} color={C.success} icon="💰" sub="Dosya başı"/>
            <OzetKart label="PRİM BH" value={(parseFloat(paydas?.prim_bh) || 0).toLocaleString('tr-TR') + ' ₺'} color={C.success} icon="💰" sub="Dosya başı"/>
          </div>
        )}

        {tab === 'cari' && cari && (
          <div>
            <div style={{display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:12, marginBottom:18}}>
              <OzetKart label="TOPLAM KOMİSYON" value={(cari.ozet?.toplam_komisyon || 0).toLocaleString('tr-TR') + ' ₺'} color={C.accent} icon="💼"/>
              <OzetKart label="ÖDENEN" value={(cari.ozet?.odenen || 0).toLocaleString('tr-TR') + ' ₺'} color={C.success} icon="✓"/>
              <OzetKart label="BEKLEYEN" value={(cari.ozet?.bekleyen || 0).toLocaleString('tr-TR') + ' ₺'} color={C.warning} icon="⏳"/>
              <OzetKart label="İŞLEM SAYISI" value={cari.ozet?.islem_sayisi || 0} color={C.purple} icon="📋"/>
            </div>
            <div style={{background:C.bgCard, borderRadius:10, border:`1px solid ${C.border}`, overflow:'hidden'}}>
              <div style={{padding:'10px 14px', borderBottom:`1px solid ${C.border}`, fontSize:12, fontWeight:800}}>
                📋 KOMİSYON GEÇMİŞİ
              </div>
              <div style={{maxHeight:'42vh', overflowY:'auto'}}>
                <table style={{width:'100%', fontSize:11, borderCollapse:'collapse'}}>
                  <thead style={{background:C.bgInput, position:'sticky', top:0}}>
                    <tr>
                      <th style={{padding:'8px 10px', textAlign:'left'}}>TARİH</th>
                      <th style={{padding:'8px 10px', textAlign:'left'}}>AÇIKLAMA</th>
                      <th style={{padding:'8px 10px', textAlign:'right'}}>TUTAR</th>
                      <th style={{padding:'8px 10px', textAlign:'center'}}>DURUM</th>
                      <th style={{padding:'8px 10px', textAlign:'left'}}>KASA</th>
                    </tr>
                  </thead>
                  <tbody>
                    {cari.hareketler?.map((h, i) => (
                      <tr key={i} style={{borderBottom:`1px solid ${C.border}`}}>
                        <td style={{padding:'7px 10px', color:C.textSec}}>{(h.tarih || '').slice(0,10)}</td>
                        <td style={{padding:'7px 10px', color:C.text}}>{h.aciklama}</td>
                        <td style={{padding:'7px 10px', textAlign:'right', fontWeight:800, color:C.text}}>{h.tutar?.toLocaleString('tr-TR')} ₺</td>
                        <td style={{padding:'7px 10px', textAlign:'center'}}>
                          <span style={{padding:'2px 8px', borderRadius:9999, fontSize:9, fontWeight:700, textTransform:'uppercase',
                            background: h.durum === 'odendi' ? `${C.success}18` : `${C.warning}18`,
                            color: h.durum === 'odendi' ? C.success : C.warning}}>
                            {h.durum === 'odendi' ? '✓ ÖDENDİ' : 'BEKLİYOR'}
                          </span>
                        </td>
                        <td style={{padding:'7px 10px', color:C.textSec, fontSize:10}}>{h.kasa_adi || '-'}</td>
                      </tr>
                    ))}
                    {(!cari.hareketler || cari.hareketler.length === 0) && (
                      <tr><td colSpan="5" style={{padding:30, textAlign:'center', color:C.textSec}}>Henüz komisyon yok</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {tab === 'evrak' && (
          <div>
            <button style={{...S.btn, ...S.btnP, marginBottom:14}} onClick={() => setEvrakOpen(!evrakOpen)}>
              {evrakOpen ? '✕ İPTAL' : '+ EVRAK YÜKLE'}
            </button>
            {evrakOpen && (
              <div style={{padding:18, background:C.bgCard, border:`2px solid ${C.purple}`, borderRadius:10, marginBottom:18}}>
                <div style={{fontSize:13, fontWeight:800, marginBottom:14, color:C.purple}}>📄 YENİ EVRAK</div>
                <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:12}}>
                  <div>
                    <div style={S.label}>EVRAK TÜRÜ</div>
                    <select style={S.select} value={evrakTuru} onChange={e => setEvrakTuru(e.target.value)}>
                      <option value="sozlesme">📜 Sözleşme</option>
                      <option value="dekont">💰 Dekont</option>
                      <option value="diger">📋 Diğer</option>
                    </select>
                  </div>
                  <div>
                    <div style={S.label}>ETİKET</div>
                    <input type="text" style={S.input} value={evrakEtiketi} onChange={e => setEvrakEtiketi(e.target.value)}/>
                  </div>
                </div>
                <div style={{marginTop:12}}>
                  <input type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={e => setEvrakFile(e.target.files[0])}
                    style={{padding:8, background:C.bgInput, border:`1px dashed ${C.border}`, borderRadius:6, width:'100%'}}/>
                </div>
                <div style={{display:'flex', gap:10, marginTop:18, justifyContent:'flex-end'}}>
                  <button style={{...S.btn, ...S.btnG}} onClick={() => setEvrakOpen(false)}>İPTAL</button>
                  <button style={{...S.btn, ...S.btnS}} onClick={evrakYukle}>✓ YÜKLE</button>
                </div>
              </div>
            )}
            <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(280px, 1fr))', gap:12}}>
              {evraklar.length === 0 && (
                <div style={{gridColumn:'1/-1', textAlign:'center', color:C.textSec, padding:40, background:C.bgCard, borderRadius:10, border:`1px dashed ${C.border}`}}>
                  📭 Henüz evrak yok
                </div>
              )}
              {evraklar.map(ev => (
                <div key={ev.id} style={{padding:14, background:C.bgCard, border:`1px solid ${C.border}`, borderRadius:10}}>
                  <div style={{display:'flex', alignItems:'center', gap:10, marginBottom:10}}>
                    <div style={{width:42, height:42, borderRadius:8, background:`${C.purple}18`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:22}}>
                      {(ev.mime_type || '').includes('pdf') ? '📄' : '🖼️'}
                    </div>
                    <div style={{flex:1, minWidth:0}}>
                      <div style={{fontSize:12, fontWeight:800, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap'}}>{ev.evrak_etiketi || ev.dosya_adi}</div>
                      <div style={{fontSize:10, color:C.textSec, marginTop:2}}>{ev.evrak_turu} · {ev.boyut_okunabilir}</div>
                    </div>
                  </div>
                  <div style={{display:'flex', gap:6}}>
                    <button style={{...S.btnMini, ...S.btnMiniP, flex:1}}
                      onClick={() => MR._evrakAc(ev.preview_url, 'inline', ev.dosya_adi)}>👁 ÖNİZLE</button>
                    <button style={{...S.btnMini, ...S.btnMiniS, flex:1}}
                      onClick={() => MR._evrakAc(ev.download_url, 'download', ev.dosya_adi)}>⬇ İNDİR</button>
                    <button style={{...S.btnMini, ...S.btnMiniD}} onClick={() => evrakSil(ev.id)}>🗑</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        </div>

        <div style={{display:'flex', justifyContent:'flex-end', marginTop:14, paddingTop:14, borderTop:`1px solid ${C.border}`}}>
          <button style={{...S.btn, ...S.btnG}} onClick={onClose}>KAPAT</button>
        </div>
      </div>
    </MR.Modal>
  );
};
