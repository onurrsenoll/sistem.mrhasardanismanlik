# v2.4.1 HOTFIX — Kart Modal Genişletme + Evrak Önizleme Düzeltme
**Tarih:** 04 Mayıs 2026
**Süre:** 2 dakika
**Risk:** SIFIR (sadece 1 dosya)

## DÜZELTMELER

### 1. Modal Genişletildi
- 950px → **95vw** (ekran genişliği %95)
- Yükseklik: 82vh
- Üstte profil çubuğu (avatar + isim + net bakiye)
- 4 kolon dashboard kartları
- Kademe görsel tablosu (Sercan örneği gibi büyük renkli)
- Yıllık bonus madalya kartları (Bronz/Gümüş/Altın)
- Kazanç modeli şablonları görsel kartlar

### 2. Evrak Önizleme Çalışıyor
- **Sebep:** `<a href>` ile JWT Authorization header gönderilemiyordu (401)
- **Çözüm:** Fetch + Blob URL — JS yetkili istek atıp blob URL üretir
- Önizleme: yeni sekmede açılır
- İndirme: download attribute ile dosya iner

### 3. Bonus İyileştirmeler
- Ödeme türü emoji'leri (💰 Maaş, 🎯 Prim, ⚡ Avans...)
- Evrak grid layout (auto-fill, minmax 280px)
- Boş durumlarda anlamlı mesajlar
- Hover efektleri + dashed border (boş alanlar için)

## YÜKLEME

**Tek dosya değişti:** `js/pages/kart-modulleri.js`

1. cPanel > File Manager > sistem.mrhasardanismanlik.com
2. ZIP'i yükle, Extract, Replace
3. Cache temizle (Ctrl+Shift+Delete)
4. Personel/Paydaş kartını yeniden aç
