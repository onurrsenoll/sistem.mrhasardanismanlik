# MR HASAR — v2.1.2 + v2.1.3 + GÜVENLİK BİRLEŞİK YAMA KURULUM KILAVUZU
**Tarih:** 03 Mayıs 2026
**Hedef:** sistem.mrhasardanismanlik.com
**Tahmini süre:** 8-10 dakika

---

## 📦 BU PAKET NE GETİRİYOR

### v2.1.2 — Bildirim Modülü Aktivasyonu
- Bildirim modülünde önceki şema tutarsızlığı düzeltildi (kullanici_id → alici_id, mesaj → icerik)
- Yeni dosya açıldığında atanan kişilere otomatik sistem bildirimi gönderir
- Atama değiştirildiğinde hem yeni atanana hem eski atanmışa bildirim gider
- 3 yardımcı fonksiyon eklendi (`bildirim_olustur`, `ortak_user_id_bul`, `bildirim_alici_gecerli`)

### v2.1.3 — Mesajlar Sayfası Routing
- "Sistem Bildirimleri" sayfasındaki **GELEN KUTUSU**, **GİDEN KUTUSU**, **YENİ MESAJ** sekmeleri **çalışıyor** (önceden boş geliyordu)
- Breadcrumb düzeltildi: "MESAJLAR > GELEN KUTUSU" gibi görünür

### Güvenlik #3 — CORS Sıkılaştırma
- `Access-Control-Allow-Origin: *` (her domaine açık) → **whitelist** (sadece `https://sistem.mrhasardanismanlik.com`)
- Yeni güvenlik başlıkları: `X-Frame-Options`, `X-XSS-Protection`, `Referrer-Policy`

### Güvenlik #5 — Form Focus-Loss
- **v2.1 yamasında zaten çözüldü** (BildirimBadge React.memo). Bu pakette korunuyor.

---

## ⚠️ ÖNEMLİ — v2.1 YAMASINDAN SONRA HAZIRLANDI

Bu paket **v2.1 yamasının ÜZERİNE** uygulanmak için manuel olarak birleştirildi:
- v2.1'in oturum kaydı + refresh token özellikleri **korundu**
- v2.1'in production-safe error özelliği **korundu**
- v2.1'in BildirimBadge React.memo focus-loss fix'i **korundu**

> Eğer v2.1 yamasını **henüz yüklemedi**ysen, önce **`MR_HASAR_v2.1_GUVENLIK_FINAL_2026-05-02.zip`** yüklenmiş olmalı.

---

## 📋 ÖN HAZIRLIK

- [ ] **Veritabanı yedeği** (cPanel > phpMyAdmin > mrhasard_dosyatakip > Export > Quick > Go)
- [ ] **Sistem dosyaları yedeği** (cPanel > File Manager > sistem.mrhasardanismanlik.com > Compress)
- [ ] **Sistem boş** (kimse şu anda kullanmıyor)
- [ ] **Bu zip indirildi** (`MR_HASAR_v2.1.2-3-CORS_BIRLESIK_2026-05-03.zip`)

---

## 🎯 KURULUM ADIMLARI

### ADIM 1 — DOSYA YAMASINI YÜKLE (3 dakika)

**Yer:** cPanel > File Manager > **sistem.mrhasardanismanlik.com**

1. Sol menüden `sistem.mrhasardanismanlik.com` klasörüne tıkla
2. Üst menüde **Yükle** (Upload)
3. ZIP'i seç (`MR_HASAR_v2.1.2-3-CORS_BIRLESIK_2026-05-03.zip`)
4. Yükleme bittikten sonra ZIP'e sağ tık > **Extract** (Çıkar)
5. **Hedef yol:** Aynı klasör (sistem.mrhasardanismanlik.com)
6. **"Replace existing files"** sorulduğunda **EVET / Yes / Replace** seç
7. ZIP'i sil

**Üzerine yazılan dosyalar:**
```
api/v1/auth/login.php          ← bildirim_olustur ile birleştirildi
api/config/helpers.php         ← CORS whitelist + bildirim fonksiyonları
api/v1/dosya/create.php        ← yeni atama bildirimi
api/v1/dosya/update.php        ← atama değişiminde bildirim
js/app.js                      ← mesajlar routing + breadcrumb (focus-loss korundu)
```

> **NOT:** Diğer dosyalar (auth.php, database.php vb.) v2.1 ile aynı — pakete eklendi ama içerik değişmedi.

---

### ADIM 2 — `.env` GÜNCELLEME (İSTEĞE BAĞLI)

CORS whitelist'i `helpers.php` içine **kod olarak gömülü** ayarlandı (sadece `https://sistem.mrhasardanismanlik.com`). `.env`'e ek bir şey yazmaya gerek **YOK**.

> İleride başka domain eklenecekse: `helpers.php`'nin başındaki `$allowedOrigins` listesine ekle.

---

### ADIM 3 — TARAYICI CACHE TEMİZLE (1 dakika)

JS değiştiği için **mutlaka cache temizlenmeli**.

1. **Ctrl + Shift + Delete**
2. Zaman: **Tüm zamanlar**
3. İşaretle: **Önbelleğe alınmış görüntüler ve dosyalar**
4. **Verileri Temizle**

---

### ADIM 4 — TEST (3 dakika)

#### Test 1 — Login & Mesajlar
1. `https://sistem.mrhasardanismanlik.com/` aç
2. Login (mevcut hesabınla)
3. **Sistem menüsü** > **Sistem Bildirimleri** tıkla
4. Üstteki sekmeleri tek tek dene:
   - [ ] **GELEN KUTUSU** → açılıyor (boş veya mesaj listesi)
   - [ ] **GİDEN KUTUSU** → açılıyor
   - [ ] **YENİ MESAJ** → form açılıyor
   - [ ] **SİSTEM BİLDİRİMLERİ** → çalışmaya devam ediyor
5. Breadcrumb'ta "MESAJLAR > GELEN KUTUSU" gibi yol gözüküyor

#### Test 2 — Yeni Dosya Bildirimi
1. **Dosyalar** > **Yeni Dosya**
2. Bir dosya aç, **avukat** veya **sorumlu** ata
3. Atadığın kişinin hesabıyla giriş yap
4. Sağ üstte 🔔 üzerinde **kırmızı badge (1)** görünmeli
5. **Bildirimler** sayfasında yeni atama bildirimi var

#### Test 3 — Form Focus-Loss
1. Bir form aç (örn. yeni dosya, yeni masraf)
2. Bir input'a tıkla, yazmaya başla
3. **60 saniye bekle** (bildirim sayacının güncellendiği aralık)
4. Input odağı **kaybolmamalı** — yazmaya devam edebilmelisin

#### Test 4 — CORS Sıkılaştırma
1. Tarayıcı Konsol'u aç (F12)
2. Dosya listesini aç (normal sayfa)
3. **Network sekmesinde** API istekleri:
   - Response Headers'da `Access-Control-Allow-Origin: https://sistem.mrhasardanismanlik.com` (yıldız değil, tam domain)
   - `X-Frame-Options: SAMEORIGIN` görünmeli

---

## 🚨 SORUN ÇIKARSA

| Belirti | Olası Sebep | Çözüm |
|---|---|---|
| Mesajlar sekmeleri yine boş | Cache temizlenmedi | Ctrl+Shift+Delete → tekrar dene |
| Login sonrası beyaz sayfa | helpers.php yanlış yüklendi | Yedekten dosyayı geri yükle |
| Yeni dosya açma hata veriyor | bildirim_olustur fonksiyonu eksik | helpers.php'de `function bildirim_olustur` aratacak |
| CORS hatası ("blocked by CORS") | Whitelist'de domain eksik | `helpers.php` ilk satırlarındaki `$allowedOrigins` dizisine ekle |
| Form focus-loss yine var | js/app.js eski yüklendi | Yeni app.js'i tekrar yükle |

---

## 🔄 GERİ ALMA (ROLLBACK)

Sorun olursa:

1. **Dosya yedeği** geri yükle (yamadan önce aldığın .zip)
2. Cache temizle
3. Login dene

---

## 📊 BU YAMADA NELER ÇÖZÜLDÜ

| # | Konu | Durum |
|---|---|---|
| **v2.1.2** | Bildirim modülü gerçek anlamda etkin | ✅ |
| **v2.1.2** | Yeni dosya açıldığında atanan kişiye bildirim | ✅ |
| **v2.1.2** | Atama değiştiğinde bildirim | ✅ |
| **v2.1.3** | Mesajlar sayfası alt sekmeleri çalışıyor | ✅ |
| **v2.1.3** | Mesajlar breadcrumb'ı doğru gösterilir | ✅ |
| **#3** | CORS wildcard kaldırıldı, whitelist'e geçildi | ✅ |
| **#3** | Yeni güvenlik başlıkları (X-Frame, X-XSS, Referrer) | ✅ |

**Toplam: 7 madde tamam**

---

## 📞 DOĞRULAMA — Bana Bildirilecekler

Yamayı bitirdiğinde şu 4 şeyi test et ve bana yaz:

1. ✅ "Mesajlar sekmeleri (gelen/giden/yeni) çalışıyor"
2. ✅ "Yeni dosya açtım, atadığım kişide bildirim göründü"
3. ✅ "Form'a yazarken 60 sn'de odak kaybolmadı"
4. ✅ "Login + dashboard sorunsuz"

Sorun olduğunda hata kodunu / ekran görüntüsünü paylaş.

---

**HAZIR! Adımları sırasıyla uygula. Bu pakette SQL migration YOK — sadece dosya yükleme.**
