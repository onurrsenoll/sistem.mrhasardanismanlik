<?php
/** POST /api/v1/eksper/create.php */
require_once __DIR__ . '/../../config/helpers.php';
require_once __DIR__ . '/../../config/auth.php';
setup_headers();
require_method('POST');
$user = auth_required(['admin', 'uzman']);
$body = get_json_body();
require_fields($body, ['firma_adi', 'eksper_adi']);
$db = getDB();

try {
    $stmt = $db->prepare("INSERT INTO eksper_firmalari (firma_adi, eksper_adi, eksper_cep, sabit_telefon, ofis_cep, eposta, durum, notlar, created_by)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        clean($body['firma_adi']),
        clean($body['eksper_adi']),
        clean($body['eksper_cep'] ?? ''),
        clean($body['sabit_telefon'] ?? ''),
        clean($body['ofis_cep'] ?? ''),
        clean($body['eposta'] ?? ''),
        in_array(($body['durum'] ?? 'aktif'), ['aktif','pasif'], true) ? $body['durum'] : 'aktif',
        clean($body['notlar'] ?? ''),
        $user['id']
    ]);
    $id = (int)$db->lastInsertId();
    log_action($user['id'], 'eksper_olustur', 'Eksper firması: ' . $body['firma_adi'] . ' / ' . $body['eksper_adi'], 'eksper_firmalari', $id);
    json_success(['id' => $id], 'Eksper firması eklendi', 201);
} catch (\Exception $e) {
    if (strpos($e->getMessage(), 'Duplicate') !== false) {
        json_error('Aynı firma + eksper adı kayıtlı', 409);
    }
    json_error('Kayıt hatası: ' . $e->getMessage(), 500);
}
