<?php
/** GET /api/v1/eksper/list.php?durum=aktif */
require_once __DIR__ . '/../../config/helpers.php';
require_once __DIR__ . '/../../config/auth.php';
setup_headers();
require_method('GET');
$user = auth_required();
$db = getDB();

// Defansif tablo
try {
    $db->exec("CREATE TABLE IF NOT EXISTS eksper_firmalari (
        id INT AUTO_INCREMENT PRIMARY KEY,
        firma_adi VARCHAR(150) NOT NULL,
        eksper_adi VARCHAR(150) NOT NULL,
        eksper_cep VARCHAR(20) DEFAULT NULL,
        sabit_telefon VARCHAR(20) DEFAULT NULL,
        ofis_cep VARCHAR(20) DEFAULT NULL,
        eposta VARCHAR(150) DEFAULT NULL,
        durum ENUM('aktif','pasif') NOT NULL DEFAULT 'aktif',
        notlar TEXT DEFAULT NULL,
        created_by INT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uq_firma_eksper (firma_adi, eksper_adi),
        INDEX idx_durum (durum)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");
} catch (\Exception $e) {}

$durum = clean($_GET['durum'] ?? '');
$arama = clean($_GET['q'] ?? '');

$where = ['1=1'];
$params = [];
if ($durum) { $where[] = 'durum = ?'; $params[] = $durum; }
if ($arama) {
    $where[] = '(firma_adi LIKE ? OR eksper_adi LIKE ? OR eksper_cep LIKE ? OR eposta LIKE ?)';
    $like = '%' . $arama . '%';
    $params[] = $like; $params[] = $like; $params[] = $like; $params[] = $like;
}

try {
    $stmt = $db->prepare("SELECT * FROM eksper_firmalari WHERE " . implode(' AND ', $where) . " ORDER BY eksper_adi ASC");
    $stmt->execute($params);
    json_success(['items' => $stmt->fetchAll()]);
} catch (\Exception $e) {
    json_error('Liste hatası: ' . $e->getMessage(), 500);
}
