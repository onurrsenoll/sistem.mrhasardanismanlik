<?php
/** PUT /api/v1/eksper/update.php */
require_once __DIR__ . '/../../config/helpers.php';
require_once __DIR__ . '/../../config/auth.php';
setup_headers();
require_method('PUT');
$user = auth_required(['admin', 'uzman']);
$body = get_json_body();
require_fields($body, ['id']);
$db = getDB();
$id = (int)$body['id'];

try {
    $fields = ['firma_adi', 'eksper_adi', 'eksper_cep', 'sabit_telefon', 'ofis_cep', 'eposta', 'durum', 'notlar'];
    $sets = [];
    $params = [];
    foreach ($fields as $f) {
        if (array_key_exists($f, $body)) {
            $sets[] = "$f = ?";
            if ($f === 'durum') {
                $params[] = in_array($body[$f], ['aktif','pasif'], true) ? $body[$f] : 'aktif';
            } else {
                $params[] = clean($body[$f]);
            }
        }
    }
    if (empty($sets)) json_error('Güncellenecek alan yok', 422);
    $params[] = $id;
    $stmt = $db->prepare("UPDATE eksper_firmalari SET " . implode(', ', $sets) . " WHERE id = ?");
    $stmt->execute($params);
    log_action($user['id'], 'eksper_guncelle', 'Eksper firması güncellendi #' . $id, 'eksper_firmalari', $id);
    json_success(['id' => $id], 'Güncellendi');
} catch (\Exception $e) {
    json_error('Güncelleme hatası: ' . $e->getMessage(), 500);
}
