<?php
/** DELETE /api/v1/eksper/delete.php?id=N */
require_once __DIR__ . '/../../config/helpers.php';
require_once __DIR__ . '/../../config/auth.php';
setup_headers();
require_method('DELETE');
$user = auth_required(['admin']);
$id = (int)($_GET['id'] ?? 0);
if (!$id) json_error('id gerekli', 422);
$db = getDB();

try {
    $stmt = $db->prepare("SELECT firma_adi, eksper_adi FROM eksper_firmalari WHERE id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) json_error('Eksper firması bulunamadı', 404);

    // Bağlı dosya var mı?
    $stmt = $db->prepare("SELECT COUNT(*) FROM dosyalar WHERE eksper_id = ? AND (silindi IS NULL OR silindi = 0)");
    $stmt->execute([$id]);
    $bagli = (int)$stmt->fetchColumn();
    if ($bagli > 0) {
        // Silme yerine pasif yap
        $db->prepare("UPDATE eksper_firmalari SET durum='pasif' WHERE id = ?")->execute([$id]);
        log_action($user['id'], 'eksper_pasif', 'Bağlı dosyası var, pasif yapıldı: ' . $row['firma_adi'], 'eksper_firmalari', $id);
        json_success(['id' => $id, 'pasif' => true], 'Eksper firmasının ' . $bagli . ' bağlı dosyası var, pasif yapıldı');
    } else {
        $db->prepare("DELETE FROM eksper_firmalari WHERE id = ?")->execute([$id]);
        log_action($user['id'], 'eksper_sil', 'Eksper silindi: ' . $row['firma_adi'], 'eksper_firmalari', $id);
        json_success(['id' => $id], 'Silindi');
    }
} catch (\Exception $e) {
    json_error('Silme hatası: ' . $e->getMessage(), 500);
}
