<?php
/** DELETE /api/v1/sigorta/delete.php?id=N */
require_once __DIR__ . '/../../config/helpers.php';
require_once __DIR__ . '/../../config/auth.php';
setup_headers();
require_method('DELETE');
$user = auth_required(['admin']);
$id = (int)($_GET['id'] ?? 0);
if (!$id) json_error('id gerekli', 422);
$db = getDB();

try {
    $stmt = $db->prepare("SELECT sirket_adi FROM sigorta_sirketleri WHERE id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) json_error('Sigorta şirketi bulunamadı', 404);

    $stmt = $db->prepare("SELECT COUNT(*) FROM dosyalar WHERE sigorta_id = ? AND (silindi IS NULL OR silindi = 0)");
    $stmt->execute([$id]);
    $bagli = (int)$stmt->fetchColumn();
    if ($bagli > 0) {
        $db->prepare("UPDATE sigorta_sirketleri SET durum='pasif' WHERE id = ?")->execute([$id]);
        log_action($user['id'], 'sigorta_pasif', 'Bağlı dosyası var, pasif yapıldı: ' . $row['sirket_adi'], 'sigorta_sirketleri', $id);
        json_success(['id' => $id, 'pasif' => true], 'Bu sigorta şirketinin ' . $bagli . ' bağlı dosyası var, pasif yapıldı');
    } else {
        $db->prepare("DELETE FROM sigorta_sirketleri WHERE id = ?")->execute([$id]);
        log_action($user['id'], 'sigorta_sil', 'Sigorta silindi: ' . $row['sirket_adi'], 'sigorta_sirketleri', $id);
        json_success(['id' => $id], 'Silindi');
    }
} catch (\Exception $e) {
    json_error('Silme hatası: ' . $e->getMessage(), 500);
}
