<?php
/** POST /api/v1/sigorta/create.php */
require_once __DIR__ . '/../../config/helpers.php';
require_once __DIR__ . '/../../config/auth.php';
setup_headers();
require_method('POST');
$user = auth_required(['admin', 'uzman']);
$body = get_json_body();
require_fields($body, ['sirket_adi']);
$db = getDB();

try {
    $stmt = $db->prepare("INSERT INTO sigorta_sirketleri (sirket_adi, iletisim_no, hasar_eposta, web_portal, durum, notlar, created_by)
                         VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        clean($body['sirket_adi']),
        clean($body['iletisim_no'] ?? ''),
        clean($body['hasar_eposta'] ?? ''),
        clean($body['web_portal'] ?? ''),
        in_array(($body['durum'] ?? 'aktif'), ['aktif','pasif'], true) ? $body['durum'] : 'aktif',
        clean($body['notlar'] ?? ''),
        $user['id']
    ]);
    $id = (int)$db->lastInsertId();
    log_action($user['id'], 'sigorta_olustur', 'Sigorta şirketi: ' . $body['sirket_adi'], 'sigorta_sirketleri', $id);
    json_success(['id' => $id], 'Sigorta şirketi eklendi', 201);
} catch (\Exception $e) {
    if (strpos($e->getMessage(), 'Duplicate') !== false) {
        json_error('Bu sigorta şirketi zaten kayıtlı', 409);
    }
    json_error('Kayıt hatası: ' . $e->getMessage(), 500);
}
