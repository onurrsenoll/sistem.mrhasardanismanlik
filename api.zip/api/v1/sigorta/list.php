<?php
/** GET /api/v1/sigorta/list.php?durum=aktif */
require_once __DIR__ . '/../../config/helpers.php';
require_once __DIR__ . '/../../config/auth.php';
setup_headers();
require_method('GET');
$user = auth_required();
$db = getDB();

try {
    $db->exec("CREATE TABLE IF NOT EXISTS sigorta_sirketleri (
        id INT AUTO_INCREMENT PRIMARY KEY,
        sirket_adi VARCHAR(150) NOT NULL,
        iletisim_no VARCHAR(20) DEFAULT NULL,
        hasar_eposta VARCHAR(150) DEFAULT NULL,
        web_portal VARCHAR(255) DEFAULT NULL,
        durum ENUM('aktif','pasif') NOT NULL DEFAULT 'aktif',
        notlar TEXT DEFAULT NULL,
        created_by INT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uq_sirket_adi (sirket_adi),
        INDEX idx_durum (durum)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");
} catch (\Exception $e) {}

$durum = clean($_GET['durum'] ?? '');
$arama = clean($_GET['q'] ?? '');

$where = ['1=1'];
$params = [];
if ($durum) { $where[] = 'durum = ?'; $params[] = $durum; }
if ($arama) {
    $where[] = '(sirket_adi LIKE ? OR hasar_eposta LIKE ?)';
    $like = '%' . $arama . '%';
    $params[] = $like; $params[] = $like;
}

try {
    $stmt = $db->prepare("SELECT * FROM sigorta_sirketleri WHERE " . implode(' AND ', $where) . " ORDER BY sirket_adi ASC");
    $stmt->execute($params);
    json_success(['items' => $stmt->fetchAll()]);
} catch (\Exception $e) {
    json_error('Liste hatası: ' . $e->getMessage(), 500);
}
