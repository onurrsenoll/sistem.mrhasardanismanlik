<?php
/**
 * PUT /api/v1/dosya/update.php
 * Dosya güncelle (aşama, bilgi, mağdur, araç)
 *
 * v2.18: Mağdur whitelist'inden TAMAMEN kaldırıldı — telefon2, email, adres,
 * il, ilce, cinsiyet, meslek. DB kolonları yerinde kalır, gelse de yok sayılır.
 *
 * v2.17: noter_vekalet alanı whitelist'te (idempotent ALTER ile garanti).
 * komisyon_orani ve noter_vekalet için boş string -> NULL'a düşürülür.
 *
 * v2.15: FK GUARD. sorumlu_id/avukat_id (users), ortak_id (ortaklar),
 * paydas_id (paydaslar) için INSERT öncesi varlık kontrolü; geçersiz ID
 * hata vermek yerine sessiz NULL'a düşürülür. SQLSTATE[23000] FK ihlali
 * artık DÜZENLE → KAYDET'i kırmıyor.
 *
 * Body: { "id": 1, "asama": "Dava Açıldı", "sigorta_sirket": "...", ... }
 */

require_once __DIR__ . '/../../config/helpers.php';
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/sms_helper.php';

setup_headers();
require_method('PUT');

$user = auth_required(['admin', 'uzman', 'personel', 'avukat']);
$body = get_json_body();
require_fields($body, ['id']);

$db = getDB();

// DDL Migration: araç ek sütunları
try {
    $db->exec("ALTER TABLE araclar ADD COLUMN IF NOT EXISTS belge_tescil_no VARCHAR(50) DEFAULT NULL");
    $db->exec("ALTER TABLE araclar ADD COLUMN IF NOT EXISTS onarim_gun_suresi INT DEFAULT NULL");
    $db->exec("ALTER TABLE araclar ADD COLUMN IF NOT EXISTS gecmis_hasar ENUM('var','yok') DEFAULT NULL");
    $db->exec("ALTER TABLE araclar ADD COLUMN IF NOT EXISTS surucu_ad VARCHAR(100) DEFAULT NULL");
    $db->exec("ALTER TABLE araclar ADD COLUMN IF NOT EXISTS surucu_tc_kimlik VARCHAR(11) DEFAULT NULL");
    $db->exec("ALTER TABLE araclar ADD COLUMN IF NOT EXISTS ruhsat_sahibi_surucu ENUM('ayni','farkli') DEFAULT NULL");
} catch (\Exception $e) {}

// DDL Migration: dosyalar tablosu eksik kolonlar
try {
    $db->exec("ALTER TABLE dosyalar ADD COLUMN IF NOT EXISTS sigorta_brans VARCHAR(50) DEFAULT NULL");
    $db->exec("ALTER TABLE dosyalar ADD COLUMN IF NOT EXISTS eksper_firma VARCHAR(100) DEFAULT NULL");
    $db->exec("ALTER TABLE dosyalar ADD COLUMN IF NOT EXISTS onarim_servisi VARCHAR(100) DEFAULT NULL");
    $db->exec("ALTER TABLE dosyalar ADD COLUMN IF NOT EXISTS bh_kasko TINYINT(1) DEFAULT 0");
    $db->exec("ALTER TABLE dosyalar ADD COLUMN IF NOT EXISTS kapanis_tazminat DECIMAL(12,2) DEFAULT NULL");
    $db->exec("ALTER TABLE dosyalar ADD COLUMN IF NOT EXISTS kapanis_komisyon DECIMAL(12,2) DEFAULT NULL");
    $db->exec("ALTER TABLE dosyalar ADD COLUMN IF NOT EXISTS kapanis_noter DECIMAL(12,2) DEFAULT NULL");
    $db->exec("ALTER TABLE dosyalar ADD COLUMN IF NOT EXISTS kapanis_vekalet DECIMAL(12,2) DEFAULT NULL");
    $db->exec("ALTER TABLE dosyalar ADD COLUMN IF NOT EXISTS kapanis_faiz DECIMAL(12,2) DEFAULT NULL");
    $db->exec("ALTER TABLE dosyalar ADD COLUMN IF NOT EXISTS kapanis_stopaj DECIMAL(12,2) DEFAULT NULL");
    $db->exec("ALTER TABLE dosyalar ADD COLUMN IF NOT EXISTS kapanis_toplam_kazanc DECIMAL(12,2) DEFAULT NULL");
    $db->exec("ALTER TABLE dosyalar ADD COLUMN IF NOT EXISTS kapanis_mr_kazanc DECIMAL(12,2) DEFAULT NULL");
    $db->exec("ALTER TABLE dosyalar ADD COLUMN IF NOT EXISTS kapanis_mahsup DECIMAL(12,2) DEFAULT NULL");
} catch (\Exception $e) {}
$id = (int)$body['id'];

$stmt = $db->prepare('SELECT * FROM dosyalar WHERE id = ?');
$stmt->execute([$id]);
$dosya = $stmt->fetch();
if (!$dosya) json_error('Dosya bulunamadı', 404);

try {
    $db->beginTransaction();

    // Frontend alias'ları backend alanlarına map et
    if (!isset($body['dosya_kaynagi']) && isset($body['dosya_kaynak'])) {
        $body['dosya_kaynagi'] = $body['dosya_kaynak'];
    }
    if (!isset($body['komisyon_orani']) && isset($body['komisyon'])) {
        $body['komisyon_orani'] = $body['komisyon'];
    }

    /* ═══ v2.15: FK GÜVENLİK KONTROLÜ ═══
     * sorumlu_id/avukat_id (users), ortak_id (ortaklar), paydas_id (paydaslar)
     * için INSERT/UPDATE öncesi varlık kontrolü. Geçersiz ID gelirse hata
     * vermek yerine sessiz NULL'a düşürülür. Bu sayede:
     *  - Eski dosyalarda hayalet ID'ler kaynaklı FK hatası yaşanmaz
     *  - Frontend dropdown'unda silinmiş user/ortak/paydaş seçilirse hata yerine NULL kaydedilir
     *  - ON DELETE SET NULL davranışıyla tutarlı
     * Hangi alan NULL'a düşürüldü → response'ta fk_temizlenenler dizisine eklenir. */
    $fkChecks = [
        'sorumlu_id' => 'users',
        'avukat_id'  => 'users',
        'ortak_id'   => 'ortaklar',
        'paydas_id'  => 'paydaslar'
    ];
    $fkTemizlenenler = [];
    foreach ($fkChecks as $fkField => $fkTable) {
        if (array_key_exists($fkField, $body) && !empty($body[$fkField])) {
            $fkVal = (int)$body[$fkField];
            if ($fkVal > 0) {
                try {
                    $fkCheck = $db->prepare("SELECT id FROM `{$fkTable}` WHERE id = ? LIMIT 1");
                    $fkCheck->execute([$fkVal]);
                    if (!$fkCheck->fetch()) {
                        /* Referans tabloda yok → NULL'a düşür */
                        $body[$fkField] = null;
                        $fkTemizlenenler[] = $fkField . '(' . $fkVal . ')';
                    }
                } catch (\Exception $fkErr) {
                    /* Referans tablo yoksa (örn. ortaklar/paydaslar tablosu kurulmamış) NULL'a düşür */
                    $body[$fkField] = null;
                    $fkTemizlenenler[] = $fkField . '(' . $fkVal . ',tablo-yok)';
                }
            } else {
                $body[$fkField] = null;
            }
        }
    }

    /* v2.17: noter_vekalet kolonu yoksa idempotent ekle */
    try { $db->exec("ALTER TABLE dosyalar ADD COLUMN IF NOT EXISTS noter_vekalet DECIMAL(12,2) DEFAULT NULL"); } catch (\Exception $e) {}

    // Dosya güncelle (v2.17: noter_vekalet whitelist'e eklendi)
    $dosyaFields = ['asama', 'dosya_turu', 'talep_turu', 'sigorta_sirket', 'police_no', 'sigorta_turu',
        'dosya_kaynagi', 'avukat_id', 'ortak_id', 'sorumlu_id', 'paydas_id', 'haklilik', 'komisyon_orani',
        'kaza_tarihi', 'kaza_il', 'kaza_ilce', 'pozisyon', 'kusur_durumu', 'hasar_no',
        'sakatlik_aciklama', 'notlar', 'kapanma_tarihi', 'plaka', 'hak_mahrumiyet',
        'acilis_tarihi', 'sorumlu_sigorta', 'surucu_ad', 'surucu_ehliyet', 'surucu_kusur',
        'sigorta_brans', 'eksper_firma', 'onarim_servisi', 'noter_vekalet'];

    $sets = [];
    $params = [];

    foreach ($dosyaFields as $field) {
        if (array_key_exists($field, $body)) {
            $sets[] = "$field = ?";
            if (in_array($field, ['avukat_id', 'ortak_id', 'sorumlu_id', 'paydas_id'])) {
                /* v2.15: $body[$field] null ise null, değilse int — FK kontrolü yukarıda yapıldı */
                $params[] = ($body[$field] === null || $body[$field] === '' || $body[$field] === 0)
                    ? null
                    : (int)$body[$field];
            } elseif (in_array($field, ['haklilik', 'hak_mahrumiyet'])) {
                $params[] = (int)$body[$field];
            } elseif (in_array($field, ['komisyon_orani', 'noter_vekalet'])) {
                $params[] = ($body[$field] === null || $body[$field] === '') ? null : (float)$body[$field];
            } elseif (in_array($field, ['kaza_tarihi', 'kapanma_tarihi', 'acilis_tarihi'])) {
                $params[] = !empty($body[$field]) ? $body[$field] : null;
            } else {
                $params[] = clean($body[$field]);
            }
        }
    }

    if (!empty($sets)) {
        $params[] = $id;
        $stmt = $db->prepare('UPDATE dosyalar SET ' . implode(', ', $sets) . ' WHERE id = ?');
        $stmt->execute($params);
    }

    // Mağdur güncelle (v2.18: telefon2, email, adres, il, ilce, cinsiyet, meslek
    // whitelist'ten TAMAMEN çıkarıldı — frontend artık göndermiyor, gelse de yok sayılır)
    $magdurFields = ['tc_kimlik', 'ad_soyad', 'telefon', 'iban',
        'dogum_tarihi', 'gelir_durumu', 'gelir_tutari'];

    $mSets = [];
    $mParams = [];
    $hasMagdurData = false;

    foreach ($magdurFields as $field) {
        $key = "magdur_$field";
        if (array_key_exists($key, $body)) {
            $hasMagdurData = true;
            $mSets[] = "$field = ?";
            if ($field === 'gelir_tutari') {
                $mParams[] = !empty($body[$key]) ? (float)$body[$key] : null;
            } elseif ($field === 'dogum_tarihi') {
                $mParams[] = !empty($body[$key]) ? $body[$key] : null;
            } elseif ($field === 'cinsiyet') {
                $mParams[] = !empty($body[$key]) ? $body[$key] : null;
            } else {
                $mParams[] = clean($body[$key]);
            }
        }
    }

    if ($hasMagdurData && !empty($mSets)) {
        $mParams[] = $id;
        $stmt = $db->prepare('UPDATE magdurlar SET ' . implode(', ', $mSets) . ' WHERE dosya_id = ?');
        $stmt->execute($mParams);
    }

    // ═══ ARAÇ BİLGİLERİ GÜNCELLE ═══
    // Mağdur araç güncelle
    $magdurAracFields = ['plaka','ruhsat_sahibi','tc_kimlik','marka','model','model_yili','belge_tescil_no','onarim_gun_suresi','gecmis_hasar','kasko'];
    $maPrefix = 'ma_';
    $maSets = [];
    $maParams = [];
    $hasMagdurArac = false;

    foreach ($magdurAracFields as $field) {
        $key = $maPrefix . $field;
        if (array_key_exists($key, $body)) {
            $hasMagdurArac = true;
            $maSets[] = "$field = ?";
            if (in_array($field, ['model_yili', 'onarim_gun_suresi'])) {
                $maParams[] = !empty($body[$key]) ? (int)$body[$key] : null;
            } elseif ($field === 'kasko') {
                $maParams[] = !empty($body[$key]) && $body[$key] !== '0' ? 1 : 0;
            } else {
                $maParams[] = clean($body[$key]);
            }
        }
    }

    if ($hasMagdurArac && !empty($maSets)) {
        // Önce mevcut kayıt var mı kontrol et
        $stmtCheck = $db->prepare('SELECT id FROM araclar WHERE dosya_id = ? AND taraf = ?');
        $stmtCheck->execute([$id, 'magdur']);
        $mevcutArac = $stmtCheck->fetch();

        if ($mevcutArac) {
            $maParams[] = $id;
            $maParams[] = 'magdur';
            $stmt = $db->prepare('UPDATE araclar SET ' . implode(', ', $maSets) . ' WHERE dosya_id = ? AND taraf = ?');
            $stmt->execute($maParams);
        } else {
            // Yeni kayıt oluştur
            $insertFields = [];
            $insertValues = [];
            $insertParams = [];
            foreach ($magdurAracFields as $field) {
                $key = $maPrefix . $field;
                if (array_key_exists($key, $body)) {
                    $insertFields[] = $field;
                    $insertValues[] = '?';
                    if (in_array($field, ['model_yili', 'onarim_gun_suresi'])) {
                        $insertParams[] = !empty($body[$key]) ? (int)$body[$key] : null;
                    } else {
                        $insertParams[] = clean($body[$key]);
                    }
                }
            }
            $insertFields[] = 'dosya_id';
            $insertValues[] = '?';
            $insertParams[] = $id;
            $insertFields[] = 'taraf';
            $insertValues[] = '?';
            $insertParams[] = 'magdur';
            $stmt = $db->prepare('INSERT INTO araclar (' . implode(', ', $insertFields) . ') VALUES (' . implode(', ', $insertValues) . ')');
            $stmt->execute($insertParams);
        }
    }

    // Karşı araç güncelle
    $karsiAracFields = ['plaka','ruhsat_sahibi','tc_kimlik','marka','model','model_yili','belge_tescil_no','trafik_sirket','trafik_police','kasko','ruhsat_sahibi_surucu','surucu_ad','surucu_tc_kimlik'];
    $kaPrefix = 'ka_';
    $kaSets = [];
    $kaParams = [];
    $hasKarsiArac = false;

    foreach ($karsiAracFields as $field) {
        $key = $kaPrefix . $field;
        if (array_key_exists($key, $body)) {
            $hasKarsiArac = true;
            $kaSets[] = "$field = ?";
            if (in_array($field, ['model_yili'])) {
                $kaParams[] = !empty($body[$key]) ? (int)$body[$key] : null;
            } elseif ($field === 'kasko') {
                $kaParams[] = !empty($body[$key]) && $body[$key] !== '0' ? 1 : 0;
            } else {
                $kaParams[] = clean($body[$key]);
            }
        }
    }

    if ($hasKarsiArac && !empty($kaSets)) {
        $stmtCheck = $db->prepare('SELECT id FROM araclar WHERE dosya_id = ? AND taraf = ?');
        $stmtCheck->execute([$id, 'karsi']);
        $mevcutKarsi = $stmtCheck->fetch();

        if ($mevcutKarsi) {
            $kaParams[] = $id;
            $kaParams[] = 'karsi';
            $stmt = $db->prepare('UPDATE araclar SET ' . implode(', ', $kaSets) . ' WHERE dosya_id = ? AND taraf = ?');
            $stmt->execute($kaParams);
        } else {
            $insertFields = [];
            $insertValues = [];
            $insertParams = [];
            foreach ($karsiAracFields as $field) {
                $key = $kaPrefix . $field;
                if (array_key_exists($key, $body)) {
                    $insertFields[] = $field;
                    $insertValues[] = '?';
                    if (in_array($field, ['model_yili'])) {
                        $insertParams[] = !empty($body[$key]) ? (int)$body[$key] : null;
                    } elseif ($field === 'kasko') {
                        $insertParams[] = !empty($body[$key]) ? 1 : 0;
                    } else {
                        $insertParams[] = clean($body[$key]);
                    }
                }
            }
            $insertFields[] = 'dosya_id';
            $insertValues[] = '?';
            $insertParams[] = $id;
            $insertFields[] = 'taraf';
            $insertValues[] = '?';
            $insertParams[] = 'karsi';
            $stmt = $db->prepare('INSERT INTO araclar (' . implode(', ', $insertFields) . ') VALUES (' . implode(', ', $insertValues) . ')');
            $stmt->execute($insertParams);
        }
    }

    // ═══ AŞAMA DEĞİŞTİĞİNDE PORTAL SÜREÇ KAYDI ═══
    if (array_key_exists('asama', $body) && $body['asama'] !== $dosya['asama']) {
        try {
            require_once __DIR__ . '/../portal/migration.php';
            ensure_portal_tables();
            $stmtSurec = $db->prepare("INSERT INTO dosya_surecler (dosya_id, baslik, detay, islem_tipi, created_at) VALUES (?, ?, ?, 'asama_degisikligi', NOW())");
            $stmtSurec->execute([
                $id,
                'AŞAMA DEĞİŞTİRİLDİ: ' . $body['asama'],
                'Önceki Aşama: ' . $dosya['asama'] . ' → Yeni Aşama: ' . $body['asama']
            ]);
        } catch (\Exception $e) {}
    }

    $db->commit();

    log_action($user['id'], 'dosya_guncelle', "Dosya güncellendi: {$dosya['dosya_no']}", 'dosyalar', $id);

    // ═══ AŞAMA DEĞİŞTİĞİNDE OTOMATİK SMS GÖNDER ═══
    $smsGonderildi = false;
    $smsSonuc = null;
    if (array_key_exists('asama', $body) && $body['asama'] !== $dosya['asama']) {
        try {
            $smsSonuc = sms_durum_degisikligi_evrakli($id, $dosya['asama'], $body['asama'], $user['id']);
            $smsGonderildi = ($smsSonuc && !empty($smsSonuc['basarili']));
        } catch (Exception $e) {
            // SMS hatası dosya güncellemeyi engellemez
        }
    }

    // ═══ AVUKAT (İŞ ORTAĞI) DEĞİŞTİĞİNDE SMS BİLDİRİMİ ═══
    $avukatSmsBilgi = null;
    if (array_key_exists('ortak_id', $body) && (int)($body['ortak_id'] ?? 0) !== (int)($dosya['ortak_id'] ?? 0) && !empty($body['ortak_id'])) {
        try {
            $yeniOrtakId = (int)$body['ortak_id'];
            $stmtAv = $db->prepare("SELECT id, ad_soyad, telefon, firma FROM ortaklar WHERE id = ? AND durum = 'aktif'");
            $stmtAv->execute([$yeniOrtakId]);
            $avukat = $stmtAv->fetch();

            if ($avukat && !empty($avukat['telefon'])) {
                $firmaAdiAv = 'MR HASAR DANISMANLIK';
                try {
                    $stmtFav = $db->query("SELECT deger FROM ayarlar WHERE anahtar = 'firma_adi' LIMIT 1");
                    $favRow = $stmtFav->fetch();
                    if ($favRow && !empty($favRow['deger'])) $firmaAdiAv = $favRow['deger'];
                } catch (\Exception $e) {}

                // Müşteri adını çek
                $stmtMag = $db->prepare("SELECT ad_soyad FROM magdurlar WHERE dosya_id = ? LIMIT 1");
                $stmtMag->execute([$id]);
                $mag = $stmtMag->fetch();
                $musteriAdi = $mag ? $mag['ad_soyad'] : '-';

                $dosyaTuruKisa = $dosya['dosya_turu'] ?? '';
                $dosyaTuruTam = $dosyaTuruKisa === 'ADK' ? 'Arac Deger Kaybi' : ($dosyaTuruKisa === 'BH' ? 'Bedeni Hasar' : $dosyaTuruKisa);
                $sigortaSirket = $dosya['sigorta_sirket'] ?? '-';
                $mevcutAsama = $body['asama'] ?? $dosya['asama'] ?? 'Dosya Acik';

                $avTelNorm = sms_telefon_normalize($avukat['telefon']);
                $avukatMesaj = "Sayin {$avukat['ad_soyad']}, tarafiniza yeni bir dosya atanmistir. Dosya No: {$dosya['dosya_no']} | Tur: {$dosyaTuruTam} | Musteri: {$musteriAdi} | Sigorta: {$sigortaSirket} | Asama: {$mevcutAsama} - {$firmaAdiAv}";

                $avukatSms = sms_gonder($avTelNorm ?: $avukat['telefon'], $avukatMesaj, $id, $user['id']);

                $avukatSmsBilgi = [
                    'avukat_adi' => $avukat['ad_soyad'],
                    'sms_gonderildi' => $avukatSms['basarili'] ?? false
                ];
            }
        } catch (\Exception $e) {
            // Avukat SMS hatası güncellemeyi engellemez
        }
    }

    $guncMesaj = 'Dosya güncellendi';
    if (!empty($avukatSmsBilgi['sms_gonderildi'])) {
        $guncMesaj .= ' | AVUKATA SMS BİLDİRİMİ GÖNDERİLDİ (' . $avukatSmsBilgi['avukat_adi'] . ')';
    }
    /* v2.15: FK temizliği info */
    if (!empty($fkTemizlenenler)) {
        $guncMesaj .= ' | Geçersiz referanslar NULL yapıldı: ' . implode(', ', $fkTemizlenenler);
    }

    /* v2.24: PERSONEL PRİM KAYDI HOOK — sorumlu/aşama değişimini cari'ye yansıt */
    try {
        require_once __DIR__ . '/../personel/_dosya_prim_hook.php';
        if (function_exists('sync_dosya_prim')) sync_dosya_prim($db, (int)$id, 'update');
    } catch (\Throwable $e) {
        error_log('[v2.24 dosya/update prim hook] ' . $e->getMessage());
    }

    json_success([
        'dosya_no' => $dosya['dosya_no'],
        'sms_gonderildi' => $smsGonderildi,
        'sms_sonuc' => $smsSonuc,
        'avukat_sms' => $avukatSmsBilgi,
        'fk_temizlenenler' => $fkTemizlenenler
    ], $guncMesaj);

} catch (\Exception $e) {
    $db->rollBack();
    json_error('Güncelleme hatası: ' . $e->getMessage(), 500);
}
