<?php
/**
 * DELETE /api/v1/masraf/delete.php?id=1
 * Masraf sil + ÖDEMİŞSE kasa bakiyesini manuel geri yükle (v2.2 fix #017)
 *
 * v2.2 düzeltmesi:
 *   FOREIGN_KEY_CHECKS=0 trigger'ı bypass ettiği için kasa bakiyesi
 *   geri yüklenmiyordu. Artık masraf ödenmişse, silmeden ÖNCE manuel
 *   olarak kasa bakiyesi tutara göre artırılır ve kasa_hareketleri'ne
 *   "iptal" hareketi yazılır.
 */

require_once __DIR__ . '/../../config/helpers.php';
require_once __DIR__ . '/../../config/auth.php';

setup_headers();
require_method('DELETE');

$user = auth_required(['admin', 'muhasebe']);
$db = getDB();

$id = (int)($_GET['id'] ?? 0);
if (!$id) json_error('Masraf ID gerekli', 422);

$stmt = $db->prepare('SELECT m.*, d.dosya_no FROM masraflar m LEFT JOIN dosyalar d ON d.id = m.dosya_id WHERE m.id = ?');
$stmt->execute([$id]);
$masraf = $stmt->fetch();
if (!$masraf) json_error('Masraf bulunamadı', 404);

try {
    $db->beginTransaction();

    // ═══ v2.2 #017: ÖDENMİŞSE KASA BAKİYESİ GERİ YÜKLE ═══
    $odemeDurumu = $masraf['odeme_durumu'] ?? 'odenmedi';
    $kasaId = !empty($masraf['kasa_id']) ? (int)$masraf['kasa_id'] : 0;
    $tutar = (float)$masraf['tutar'];

    if ($odemeDurumu === 'odendi' && $kasaId > 0 && $tutar > 0) {
        // Kasa bakiyesini tutar kadar artır
        $db->prepare('UPDATE kasalar SET bakiye = bakiye + ? WHERE id = ?')
           ->execute([$tutar, $kasaId]);

        // Kasa hareket geçmişine "iptal" kaydı yaz
        try {
            $aciklama = "MASRAF SİLİNDİ - " . ($masraf['masraf_kalemi'] ?? 'Masraf') . " (Dosya: " . ($masraf['dosya_no'] ?? '-') . ")";
            $db->prepare("INSERT INTO kasa_hareketleri (kasa_id, dosya_id, tutar, hareket_tipi, aciklama, kullanici_id, islem_tarihi)
                          VALUES (?, ?, ?, 'gelir', ?, ?, NOW())")
               ->execute([$kasaId, $masraf['dosya_id'] ?? null, $tutar, $aciklama, $user['id']]);
        } catch (\Exception $e) {
            // kasa_hareketleri INSERT şeması sürüm farklılığı olabilir, sessiz geç
            error_log('[mr_hasar v2.2] masraf delete kasa_hareketleri INSERT: ' . $e->getMessage());
        }
    }

    // Bağlı paydaş komisyonu varsa onu da sil
    $paydasKomisyonId = $masraf['paydas_komisyon_id'] ?? null;
    if ($paydasKomisyonId) {
        try {
            $db->prepare('DELETE FROM paydas_komisyonlari WHERE id = ?')->execute([$paydasKomisyonId]);
        } catch (\Exception $e) {}
    }

    $db->exec("SET FOREIGN_KEY_CHECKS = 0");
    $stmt = $db->prepare('DELETE FROM masraflar WHERE id = ?');
    $stmt->execute([$id]);
    $db->exec("SET FOREIGN_KEY_CHECKS = 1");

    $db->commit();
} catch (Exception $e) {
    $db->rollBack();
    $db->exec("SET FOREIGN_KEY_CHECKS = 1");
    json_error('Silme hatası: ' . $e->getMessage(), 500);
}

log_action($user['id'], 'masraf_sil', "{$masraf['dosya_no']} - {$masraf['masraf_kalemi']}: " . number_format($masraf['tutar'], 2) . " ₺ (v2.2 fix: kasa rollback)", 'masraflar', $id);

json_success(null, 'Masraf silindi (kasa bakiyesi güncel)');
