/**
 * MR HASAR — v2.4.2 KART MODÜLLERİ (PROFESYONEL)
 *
 * Yenileme:
 * - Sade tipografi, sistem LIcon yapısı
 * - Genel Bilgiler: form-tablo görünümü, INLINE düzenleme (DÜZENLE butonu)
 * - Kazanç Modeli: 4 şablon kartı GARANTİ (JS hardcoded), aktif model net kademe
 * - Cari Hesap: temiz tablo, bekleyen primler vurgu
 * - Ödemeler: profesyonel form + tablo
 * - Evraklar: liste, fetch+blob önizleme
 * - Tüm alanlar görüntülenir (TC, IBAN, adres, doğum, kan grubu vs.)
 */
const MR = window.MR || (window.MR = {});
const {useState, useEffect} = React;

/* ═══════════ HARDCODED ŞABLONLAR (PHP başarısız olsa bile çalışsın) ═══════════ */
const SABLON_LISTESI = {
  sercan_saha: {
    etiket: 'Saha Personeli — Kademeli Prim',
    aciklama: 'Sabit 40K maaş + 1-10 hedef altı, 11-15/16-20/21+ kademe',
    model_tipi: 'kademeli_saha',
    sabit_maas: 40000,
    yemek_gunluk: 0,
    yemek_gun_sayisi: 22,
    saha_kademe: [
      {min:0,  max:10, birim:0,    etiket:'Hedef Altı'},
      {min:11, max:15, birim:2500, etiket:'Kademe 1'},
      {min:16, max:20, birim:3500, etiket:'Kademe 2'},
      {min:21, max:999,birim:5000, etiket:'Kademe 3'}
    ],
    yillik_bonus: [
      {min:180,max:199, bonus:50000, etiket:'Bronz'},
      {min:200,max:219, bonus:75000, etiket:'Gümüş'},
      {min:220,max:9999,bonus:100000,etiket:'Altın'}
    ]
  },
  ofis_cagri: {
    etiket: 'Ofis Çağrı Uzmanı — ADK + BH Kademeli',
    aciklama: '28K maaş + günlük yemek + ADK/BH ayrı kademe + kota sistemi',
    model_tipi: 'kademeli_ofis',
    sabit_maas: 28076,
    yemek_gunluk: 250,
    yemek_gun_sayisi: 22,
    ofis_kota: {
      adk_kota: 5,
      bh_kota: 2,
      adk_kademe: [
        {min:0, max:4,  birim:0,   etiket:'Hedef Altı'},
        {min:5, max:7,  birim:1500,etiket:'Kademe 1'},
        {min:8, max:10, birim:1750,etiket:'Kademe 2'},
        {min:11,max:14, birim:2000,etiket:'Kademe 3'},
        {min:15,max:999,birim:2500,etiket:'Kademe 4'}
      ],
      bh_kademe: [
        {min:0,max:1, birim:0,   etiket:'Hedef Altı'},
        {min:2,max:3, birim:2500,etiket:'Kademe 1'},
        {min:4,max:5, birim:3000,etiket:'Kademe 2'},
        {min:6,max:7, birim:3500,etiket:'Kademe 3'},
        {min:8,max:99,birim:4500,etiket:'Kademe 4'}
      ]
    },
    yillik_bonus: [
      {min:84, max:119, bonus:25000,  etiket:'Bronz'},
      {min:120,max:167, bonus:50000,  etiket:'Gümüş'},
      {min:168,max:9999,bonus:100000, etiket:'Altın'}
    ]
  },
  sabit_prim: {
    etiket: 'Standart — Sabit Maaş + Dosya Başı Prim',
    aciklama: 'Aylık sabit maaş + her ADK/BH dosya için belirli prim',
    model_tipi: 'sabit_prim',
    sabit_maas: 0,
    prim_adk: 0,
    prim_bh: 0
  },
  sabit: {
    etiket: 'Sade — Sadece Sabit Maaş',
    aciklama: 'Prim yok, aylık sabit maaş ödemesi',
    model_tipi: 'sabit',
    sabit_maas: 0
  }
};

/* ═══════════ EVRAK ÖNİZLEME / İNDİRME (FETCH + BLOB) ═══════════ */
MR._evrakAc = async (url, mode = 'inline', filename = 'evrak.pdf') => {
  const h = {};
  if (MR.api.token) h['Authorization'] = 'Bearer ' + MR.api.token;
  try {
    const r = await fetch(url, {headers: h});
    if (!r.ok) { MR.toast('Evrak açılamadı: ' + r.status, 'error'); return; }
    const blob = await r.blob();
    const blobUrl = URL.createObjectURL(blob);
    if (mode === 'inline') {
      window.open(blobUrl, '_blank');
      setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
    } else {
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(blobUrl), 5000);
    }
  } catch (e) { MR.toast('Bağlantı hatası: ' + e.message, 'error'); }
};

/* ═══════════ BİLGİ SATIRI BİLEŞENİ — sade form-tablo ═══════════ */
const BilgiSatir = ({label, value, dgVal, edit, onChange, type='text', placeholder='', options}) => {
  const {C} = MR;
  return (
    <div style={{
      display:'grid', gridTemplateColumns:'180px 1fr', gap:16,
      padding:'10px 14px', borderBottom:`1px solid ${C.border}`,
      alignItems:'center', minHeight:42
    }}>
      <div style={{fontSize:11, fontWeight:700, color:C.textSec, letterSpacing:0.5, textTransform:'uppercase'}}>{label}</div>
      {edit ? (
        options ? (
          <select value={dgVal ?? ''} onChange={e => onChange?.(e.target.value)}
            style={{padding:'7px 10px', background:C.bgInput, border:`1px solid ${C.border}`, borderRadius:6, color:C.text, fontSize:12, fontWeight:600}}>
            <option value="">— Seçin —</option>
            {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        ) : (
          <input type={type} value={dgVal ?? ''} onChange={e => onChange?.(e.target.value)} placeholder={placeholder}
            style={{padding:'7px 10px', background:C.bgInput, border:`1px solid ${C.border}`, borderRadius:6, color:C.text, fontSize:12, fontWeight:600}}/>
        )
      ) : (
        <div style={{fontSize:13, fontWeight:600, color: value ? C.text : C.textMuted}}>
          {value || '—'}
        </div>
      )}
    </div>
  );
};

/* ═══════════ PERSONEL KART MODAL ═══════════ */
MR.PersonelKartModal = ({open, onClose, personel, user, onUpdate}) => {
  const {C, S, LIcon, api} = MR;
  const [tab, setTab] = useState('genel');
  const [pData, setPData] = useState(personel || {});
  const [edit, setEdit] = useState(false);
  const [draft, setDraft] = useState({});
  const [cari, setCari] = useState(null);
  const [evraklar, setEvraklar] = useState([]);
  const [model, setModel] = useState(null);
  const [kasalar, setKasalar] = useState([]);
  const [loading, setLoading] = useState(false);

  const [odemeOpen, setOdemeOpen] = useState(false);
  const [odemeData, setOdemeData] = useState({odeme_turu: 'maas', tutar: '', kasa_id: '', donem: '', aciklama: ''});
  const [evrakOpen, setEvrakOpen] = useState(false);
  const [evrakFile, setEvrakFile] = useState(null);
  const [evrakTuru, setEvrakTuru] = useState('sozlesme');
  const [evrakEtiketi, setEvrakEtiketi] = useState('');
  const [modelDuzenle, setModelDuzenle] = useState(false);

  useEffect(() => {
    if (open && personel?.id) { setPData(personel); setDraft({}); setEdit(false); yukle(); }
  }, [open, personel?.id]);

  const yukle = async () => {
    setLoading(true);
    const [c, e, m, k] = await Promise.all([
      api.req('/personel/cari-hesap.php?id=' + personel.id),
      api.req('/personel/evrak-list.php?id=' + personel.id),
      api.req('/personel/kazanc-modeli-get.php?id=' + personel.id),
      api.kasaList()
    ]);
    console.log('[v2.4.3 yukle] kazanc-modeli-get response:', m);
    if (c?.success) setCari(c.data);
    if (e?.success) setEvraklar(e.data || []);
    // v2.4.3: Backend'den aktif_model gelmiyorsa, mevcut state'deki optimistic'i koru
    if (m?.success && m.data?.aktif_model) {
      setModel(m.data);
    } else if (m?.success && m.data) {
      // aktif_model null geldi ama sablonlar/gecmis var — sadece o ikisini güncelle
      setModel(prev => ({
        aktif_model: prev?.aktif_model || null,
        gecmis_modeller: m.data.gecmis_modeller || [],
        sablonlar: m.data.sablonlar || {}
      }));
    }
    if (k?.success) setKasalar(k.data || []);
    setLoading(false);
  };

  const editAc = () => { setDraft({...pData}); setEdit(true); };
  const editIptal = () => { setDraft({}); setEdit(false); };
  const editKaydet = async () => {
    const r = await api.personelUpdate({id: pData.id, ...draft});
    if (r?.success) {
      MR.toast('Bilgiler güncellendi', 'success');
      setPData({...pData, ...draft});
      setEdit(false);
      onUpdate?.();
    } else MR.toast(r?.error || 'Güncelleme hatası', 'error');
  };
  const setD = (k, v) => setDraft(p => ({...p, [k]: v}));

  const odemeYap = async () => {
    if (!odemeData.tutar || !odemeData.kasa_id) { MR.toast('Tutar ve kasa zorunlu', 'error'); return; }
    const r = await api.req('/personel/odeme-yap.php', {
      method: 'POST',
      body: JSON.stringify({...odemeData, personel_id: pData.id, tutar: parseFloat(odemeData.tutar)})
    });
    if (r?.success) {
      MR.toast('Ödeme başarıyla yapıldı', 'success');
      setOdemeOpen(false);
      setOdemeData({odeme_turu: 'maas', tutar: '', kasa_id: '', donem: '', aciklama: ''});
      yukle();
    } else MR.toast(r?.error || 'Ödeme hatası', 'error');
  };

  const evrakYukle = async () => {
    if (!evrakFile) { MR.toast('Dosya seçin', 'error'); return; }
    const fd = new FormData();
    fd.append('personel_id', pData.id);
    fd.append('evrak_turu', evrakTuru);
    fd.append('evrak_etiketi', evrakEtiketi);
    fd.append('file', evrakFile);
    const h = {}; if (api.token) h['Authorization'] = 'Bearer ' + api.token;
    const r = await fetch('/api/v1/personel/evrak-yukle.php', {method: 'POST', headers: h, body: fd}).then(r => r.json());
    if (r?.success) {
      MR.toast('Evrak yüklendi', 'success');
      setEvrakOpen(false); setEvrakFile(null); setEvrakEtiketi('');
      yukle();
    } else MR.toast(r?.error || 'Yükleme hatası', 'error');
  };

  const evrakSil = async (id) => {
    if (!confirm('Evrakı silmek istediğinize emin misiniz?')) return;
    const r = await api.req('/personel/evrak-sil.php?id=' + id, {method: 'DELETE'});
    if (r?.success) { MR.toast('Evrak silindi', 'success'); yukle(); }
    else MR.toast(r?.error || 'Silme hatası', 'error');
  };

  const sablonUygula = async (key) => {
    const s = SABLON_LISTESI[key];
    if (!s) return;
    const payload = {
      personel_id: pData.id,
      model_tipi: s.model_tipi,
      sabit_maas: s.sabit_maas || 0,
      yemek_gunluk: s.yemek_gunluk || 0,
      yemek_gun_sayisi: s.yemek_gun_sayisi || 22,
      prim_adk: s.prim_adk || 0,
      prim_bh: s.prim_bh || 0,
      saha_kademe: s.saha_kademe || [],
      ofis_kota: s.ofis_kota || {},
      yillik_bonus: s.yillik_bonus || [],
      gecerlilik_baslangic: new Date().toISOString().slice(0, 10)
    };
    const r = await api.req('/personel/kazanc-modeli-set.php', {method: 'POST', body: JSON.stringify(payload)});
    console.log('[v2.4.3] kazanc-modeli-set response:', r);
    if (r?.success) {
      MR.toast(s.etiket + ' uygulandı', 'success');
      // v2.4.3 OPTIMISTIC UPDATE — Backend success, model'i hemen göster
      // (yukle backend'den doğrulayacak ama UI takılmasın)
      setModel(prev => ({
        ...(prev || {}),
        aktif_model: {
          id: r.data?.model_id,
          model_tipi: s.model_tipi,
          sabit_maas: s.sabit_maas || 0,
          yemek_gunluk: s.yemek_gunluk || 0,
          yemek_gun_sayisi: s.yemek_gun_sayisi || 22,
          prim_adk: s.prim_adk || 0,
          prim_bh: s.prim_bh || 0,
          saha_kademe: s.saha_kademe || [],
          ofis_kota: s.ofis_kota || {},
          yillik_bonus: s.yillik_bonus || [],
          saha_kademe_json: JSON.stringify(s.saha_kademe || []),
          ofis_kota_json: JSON.stringify(s.ofis_kota || {}),
          yillik_bonus_json: JSON.stringify(s.yillik_bonus || []),
          gecerlilik_baslangic: payload.gecerlilik_baslangic
        }
      }));
      // Backend'den de yenile (geri uyumluluk)
      setTimeout(() => yukle(), 300);
    } else {
      MR.toast(r?.error || 'Şablon uygulanamadı', 'error');
      console.error('[v2.4.3] SET hata:', r);
    }
  };

  if (!open) return null;

  const aktifModel = model?.aktif_model;
  // Defensive JSON parse — string veya array/obj olabilir
  const safeParse = (val, fallback) => {
    if (!val) return fallback;
    if (typeof val === 'string') {
      try { return JSON.parse(val); } catch(e) { return fallback; }
    }
    return val;
  };
  const sahaKademe = safeParse(aktifModel?.saha_kademe, safeParse(aktifModel?.saha_kademe_json, []));
  const ofisKota = safeParse(aktifModel?.ofis_kota, safeParse(aktifModel?.ofis_kota_json, null));
  const yillikBonus = safeParse(aktifModel?.yillik_bonus, safeParse(aktifModel?.yillik_bonus_json, []));
  const odemeler = (cari?.hareketler || []).filter(h => h.tur === 'odeme');

  const tabs = [
    {id:'genel',  label:'Genel Bilgiler', icon:'User'},
    {id:'model',  label:'Kazanç Modeli',  icon:'TrendingUp'},
    {id:'cari',   label:'Cari Hesap',     icon:'FileText'},
    {id:'odeme',  label:'Ödemeler',       icon:'CreditCard'},
    {id:'evrak',  label:'Evraklar',       icon:'Folder'},
  ];

  return (
    <MR.Modal open={open} onClose={onClose} title={`Personel Kartı — ${pData?.ad_soyad || ''}`} width="95vw">
      <div style={{display:'flex', flexDirection:'column', height:'85vh'}}>

        {/* ÜST KISA BİLGİ ÇUBUĞU */}
        <div style={{display:'flex', alignItems:'center', gap:14, padding:'12px 16px', background:C.bgCard, border:`1px solid ${C.border}`, borderRadius:8, marginBottom:14}}>
          <div style={{width:44, height:44, borderRadius:8, background:C.accent, color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:16, fontWeight:800, flexShrink:0}}>
            {(pData?.ad_soyad || '?').slice(0,2).toUpperCase()}
          </div>
          <div style={{flex:1}}>
            <div style={{fontSize:14, fontWeight:700, color:C.text}}>{pData?.ad_soyad}</div>
            <div style={{fontSize:11, color:C.textSec, marginTop:2}}>
              {pData?.departman || '-'} · {pData?.email || '-'} · {pData?.telefon || '-'}
            </div>
          </div>
          {cari?.ozet && (
            <div style={{display:'flex', gap:18}}>
              <div style={{textAlign:'right'}}>
                <div style={{fontSize:9, color:C.textSec, fontWeight:700, textTransform:'uppercase', letterSpacing:0.5}}>Net Bakiye</div>
                <div style={{fontSize:14, fontWeight:800, color:cari.ozet.net_bakiye >= 0 ? C.success : C.danger}}>
                  {(cari.ozet.net_bakiye || 0).toLocaleString('tr-TR')} ₺
                </div>
              </div>
              <div style={{textAlign:'right'}}>
                <div style={{fontSize:9, color:C.textSec, fontWeight:700, textTransform:'uppercase', letterSpacing:0.5}}>Bekleyen</div>
                <div style={{fontSize:14, fontWeight:800, color:C.warning}}>
                  {cari.ozet.bekleyen_prim_sayisi || 0} prim
                </div>
              </div>
            </div>
          )}
        </div>

        {/* TAB MENU */}
        <div style={{display:'flex', gap:2, borderBottom:`1px solid ${C.border}`, marginBottom:14}}>
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              padding:'10px 16px', border:'none',
              background: tab === t.id ? C.bgCard : 'transparent',
              color: tab === t.id ? C.accent : C.textSec,
              fontWeight: tab === t.id ? 700 : 500,
              fontSize: 12, letterSpacing: 0.3,
              cursor:'pointer', borderRadius:'6px 6px 0 0',
              borderBottom: tab === t.id ? `2px solid ${C.accent}` : '2px solid transparent',
              display:'flex', alignItems:'center', gap:6,
              transition:'all .15s'
            }}>
              <LIcon name={t.icon} size={14}/>
              {t.label}
            </button>
          ))}
        </div>

        <div style={{flex:1, overflowY:'auto', paddingRight:6}}>

        {/* GENEL BİLGİLER */}
        {tab === 'genel' && (
          <div>
            <div style={{display:'flex', justifyContent:'flex-end', marginBottom:10, gap:8}}>
              {!edit ? (
                <button style={{...S.btn, ...S.btnP, fontSize:12, padding:'8px 14px'}} onClick={editAc}>
                  <LIcon name="Edit2" size={13}/> DÜZENLE
                </button>
              ) : (
                <>
                  <button style={{...S.btn, ...S.btnG, fontSize:12, padding:'8px 14px'}} onClick={editIptal}>
                    <LIcon name="X" size={13}/> İPTAL
                  </button>
                  <button style={{...S.btn, ...S.btnS, fontSize:12, padding:'8px 14px'}} onClick={editKaydet}>
                    <LIcon name="Check" size={13}/> KAYDET
                  </button>
                </>
              )}
            </div>

            <div style={{background:C.bgCard, borderRadius:8, border:`1px solid ${C.border}`, overflow:'hidden'}}>
              <div style={{padding:'10px 14px', background:C.bgInput, borderBottom:`1px solid ${C.border}`, fontSize:11, fontWeight:700, color:C.textSec, letterSpacing:0.5, textTransform:'uppercase'}}>
                Kişisel Bilgiler
              </div>
              <BilgiSatir label="Ad Soyad" value={pData?.ad_soyad} edit={edit} dgVal={draft.ad_soyad} onChange={v => setD('ad_soyad', v)}/>
              <BilgiSatir label="TC Kimlik" value={pData?.tc_kimlik} edit={edit} dgVal={draft.tc_kimlik} onChange={v => setD('tc_kimlik', v)}/>
              <BilgiSatir label="Doğum Tarihi" value={pData?.dogum_tarihi} edit={edit} dgVal={draft.dogum_tarihi} type="date" onChange={v => setD('dogum_tarihi', v)}/>
              <BilgiSatir label="Telefon" value={pData?.telefon} edit={edit} dgVal={draft.telefon} onChange={v => setD('telefon', v)}/>
              <BilgiSatir label="Telefon 2" value={pData?.telefon2} edit={edit} dgVal={draft.telefon2} onChange={v => setD('telefon2', v)}/>
              <BilgiSatir label="E-Posta" value={pData?.email} edit={edit} dgVal={draft.email} type="email" onChange={v => setD('email', v)}/>
              <BilgiSatir label="Adres" value={pData?.adres} edit={edit} dgVal={draft.adres} onChange={v => setD('adres', v)}/>
              <BilgiSatir label="İl" value={pData?.il} edit={edit} dgVal={draft.il} onChange={v => setD('il', v)}/>
              <BilgiSatir label="İlçe" value={pData?.ilce} edit={edit} dgVal={draft.ilce} onChange={v => setD('ilce', v)}/>
              <BilgiSatir label="Kan Grubu" value={pData?.kan_grubu} edit={edit} dgVal={draft.kan_grubu} onChange={v => setD('kan_grubu', v)}/>
            </div>

            <div style={{height:14}}/>

            <div style={{background:C.bgCard, borderRadius:8, border:`1px solid ${C.border}`, overflow:'hidden'}}>
              <div style={{padding:'10px 14px', background:C.bgInput, borderBottom:`1px solid ${C.border}`, fontSize:11, fontWeight:700, color:C.textSec, letterSpacing:0.5, textTransform:'uppercase'}}>
                İş Bilgileri
              </div>
              <BilgiSatir label="Pozisyon / Görev" value={pData?.pozisyon || pData?.gorev} edit={edit} dgVal={draft.pozisyon || draft.gorev} onChange={v => setD('pozisyon', v)}/>
              <BilgiSatir label="Departman" value={pData?.departman} edit={edit} dgVal={draft.departman} onChange={v => setD('departman', v)}
                options={[{value:'saha',label:'Saha'},{value:'ofis',label:'Ofis'},{value:'crm',label:'CRM'},{value:'muhasebe',label:'Muhasebe'},{value:'avukat',label:'Avukat'},{value:'yonetim',label:'Yönetim'}]}/>
              <BilgiSatir label="İşe Başlama Tarihi" value={pData?.ise_baslama} edit={edit} dgVal={draft.ise_baslama} type="date" onChange={v => setD('ise_baslama', v)}/>
              <BilgiSatir label="Ehliyet Sınıfı" value={pData?.ehliyet} edit={edit} dgVal={draft.ehliyet} onChange={v => setD('ehliyet', v)}/>
              <BilgiSatir label="SGK No" value={pData?.sgk_no} edit={edit} dgVal={draft.sgk_no} onChange={v => setD('sgk_no', v)}/>
              <BilgiSatir label="Durum" value={pData?.durum} edit={edit} dgVal={draft.durum} onChange={v => setD('durum', v)}
                options={[{value:'aktif',label:'Aktif'},{value:'pasif',label:'Pasif'},{value:'izinli',label:'İzinli'}]}/>
            </div>

            <div style={{height:14}}/>

            <div style={{background:C.bgCard, borderRadius:8, border:`1px solid ${C.border}`, overflow:'hidden'}}>
              <div style={{padding:'10px 14px', background:C.bgInput, borderBottom:`1px solid ${C.border}`, fontSize:11, fontWeight:700, color:C.textSec, letterSpacing:0.5, textTransform:'uppercase'}}>
                Banka / Maaş
              </div>
              <BilgiSatir label="IBAN" value={pData?.iban} edit={edit} dgVal={draft.iban} onChange={v => setD('iban', v)}/>
              <BilgiSatir label="Banka" value={pData?.banka} edit={edit} dgVal={draft.banka} onChange={v => setD('banka', v)}/>
              <BilgiSatir label="Sabit Maaş (TL)" value={pData?.maas ? parseFloat(pData.maas).toLocaleString('tr-TR') + ' ₺' : '—'} edit={edit} dgVal={draft.maas} type="number" onChange={v => setD('maas', v)}/>
            </div>
          </div>
        )}

        {/* KAZANÇ MODELİ */}
        {tab === 'model' && (
          <div>
            {/* AKTİF MODEL VARSA — özet */}
            {aktifModel && (
              <div style={{background:C.bgCard, borderRadius:8, border:`1px solid ${C.border}`, padding:'14px 16px', marginBottom:18}}>
                <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12}}>
                  <div>
                    <div style={{fontSize:11, color:C.textSec, fontWeight:700, letterSpacing:0.5, textTransform:'uppercase'}}>Aktif Model</div>
                    <div style={{fontSize:15, fontWeight:700, color:C.text, marginTop:3}}>
                      {(aktifModel.model_tipi || '').replace('_', ' ').toUpperCase()}
                    </div>
                  </div>
                  <div style={{display:'flex', gap:18}}>
                    <div><div style={{fontSize:9, color:C.textSec, fontWeight:700, letterSpacing:0.5, textTransform:'uppercase'}}>Sabit Maaş</div><div style={{fontSize:14, fontWeight:700, color:C.text, marginTop:2}}>{(parseFloat(aktifModel.sabit_maas) || 0).toLocaleString('tr-TR')} ₺</div></div>
                    {parseFloat(aktifModel.yemek_gunluk) > 0 && <div><div style={{fontSize:9, color:C.textSec, fontWeight:700, letterSpacing:0.5, textTransform:'uppercase'}}>Yemek Günlük</div><div style={{fontSize:14, fontWeight:700, color:C.text, marginTop:2}}>{aktifModel.yemek_gunluk} ₺ × {aktifModel.yemek_gun_sayisi || 22} gün</div></div>}
                    <div><div style={{fontSize:9, color:C.textSec, fontWeight:700, letterSpacing:0.5, textTransform:'uppercase'}}>Geçerlilik</div><div style={{fontSize:14, fontWeight:700, color:C.text, marginTop:2}}>{aktifModel.gecerlilik_baslangic}</div></div>
                  </div>
                </div>

                {/* SAHA Kademe tablosu */}
                {aktifModel.model_tipi === 'kademeli_saha' && sahaKademe.length > 0 && (
                  <div style={{marginTop:14}}>
                    <div style={{fontSize:11, fontWeight:700, color:C.textSec, marginBottom:8, letterSpacing:0.5, textTransform:'uppercase'}}>Saha Kademeleri</div>
                    <table style={{width:'100%', fontSize:12, borderCollapse:'collapse'}}>
                      <thead><tr style={{background:C.bgInput}}>
                        <th style={{padding:'8px 12px', textAlign:'left', fontWeight:600, color:C.textSec}}>Kademe</th>
                        <th style={{padding:'8px 12px', textAlign:'left', fontWeight:600, color:C.textSec}}>Aralık</th>
                        <th style={{padding:'8px 12px', textAlign:'right', fontWeight:600, color:C.textSec}}>Birim Prim (TL/dosya)</th>
                      </tr></thead>
                      <tbody>
                        {sahaKademe.map((k, i) => (
                          <tr key={i} style={{borderBottom:`1px solid ${C.border}`}}>
                            <td style={{padding:'8px 12px', fontWeight:600}}>{k.etiket}</td>
                            <td style={{padding:'8px 12px', color:C.textSec}}>{k.min}–{k.max === 999 ? '∞' : k.max} dosya</td>
                            <td style={{padding:'8px 12px', textAlign:'right', fontWeight:700, color: k.birim > 0 ? C.success : C.textMuted}}>
                              {k.birim > 0 ? k.birim.toLocaleString('tr-TR') + ' ₺' : 'Prim Yok'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {/* OFİS Kademe (ADK + BH) */}
                {aktifModel.model_tipi === 'kademeli_ofis' && ofisKota && (
                  <div style={{marginTop:14}}>
                    <div style={{fontSize:11, fontWeight:700, color:C.textSec, marginBottom:8, letterSpacing:0.5, textTransform:'uppercase'}}>
                      Ofis Kademeleri (Kota: ADK ≥ {ofisKota.adk_kota}, BH ≥ {ofisKota.bh_kota})
                    </div>
                    <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:14}}>
                      <div>
                        <div style={{fontSize:10, fontWeight:700, marginBottom:6, color:C.accent}}>ADK KADEMELERİ</div>
                        <table style={{width:'100%', fontSize:12, borderCollapse:'collapse'}}>
                          <tbody>
                            {(ofisKota.adk_kademe || []).map((k, i) => (
                              <tr key={i} style={{borderBottom:`1px solid ${C.border}`}}>
                                <td style={{padding:'6px 10px', fontWeight:600}}>{k.etiket}</td>
                                <td style={{padding:'6px 10px', color:C.textSec}}>{k.min}–{k.max === 999 ? '∞' : k.max}</td>
                                <td style={{padding:'6px 10px', textAlign:'right', fontWeight:700, color: k.birim > 0 ? C.success : C.textMuted}}>{k.birim > 0 ? k.birim.toLocaleString('tr-TR') + ' ₺' : '—'}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      <div>
                        <div style={{fontSize:10, fontWeight:700, marginBottom:6, color:C.warning}}>BH KADEMELERİ</div>
                        <table style={{width:'100%', fontSize:12, borderCollapse:'collapse'}}>
                          <tbody>
                            {(ofisKota.bh_kademe || []).map((k, i) => (
                              <tr key={i} style={{borderBottom:`1px solid ${C.border}`}}>
                                <td style={{padding:'6px 10px', fontWeight:600}}>{k.etiket}</td>
                                <td style={{padding:'6px 10px', color:C.textSec}}>{k.min}–{k.max === 99 ? '∞' : k.max}</td>
                                <td style={{padding:'6px 10px', textAlign:'right', fontWeight:700, color: k.birim > 0 ? C.success : C.textMuted}}>{k.birim > 0 ? k.birim.toLocaleString('tr-TR') + ' ₺' : '—'}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                )}

                {/* SABİT_PRIM */}
                {aktifModel.model_tipi === 'sabit_prim' && (
                  <div style={{marginTop:14, display:'grid', gridTemplateColumns:'1fr 1fr', gap:14}}>
                    <div style={{padding:12, background:C.bgInput, borderRadius:6}}>
                      <div style={{fontSize:10, color:C.textSec, fontWeight:700, textTransform:'uppercase'}}>ADK Birim Primi</div>
                      <div style={{fontSize:18, fontWeight:800, color:C.success, marginTop:4}}>{(parseFloat(aktifModel.prim_adk) || 0).toLocaleString('tr-TR')} ₺ <span style={{fontSize:11, fontWeight:500, color:C.textSec}}>/ dosya</span></div>
                    </div>
                    <div style={{padding:12, background:C.bgInput, borderRadius:6}}>
                      <div style={{fontSize:10, color:C.textSec, fontWeight:700, textTransform:'uppercase'}}>BH Birim Primi</div>
                      <div style={{fontSize:18, fontWeight:800, color:C.warning, marginTop:4}}>{(parseFloat(aktifModel.prim_bh) || 0).toLocaleString('tr-TR')} ₺ <span style={{fontSize:11, fontWeight:500, color:C.textSec}}>/ dosya</span></div>
                    </div>
                  </div>
                )}

                {/* Yıllık Bonus */}
                {yillikBonus.length > 0 && (
                  <div style={{marginTop:14}}>
                    <div style={{fontSize:11, fontWeight:700, color:C.textSec, marginBottom:8, letterSpacing:0.5, textTransform:'uppercase'}}>Yıllık Bonus Eşikleri</div>
                    <div style={{display:'grid', gridTemplateColumns:`repeat(${yillikBonus.length}, 1fr)`, gap:8}}>
                      {yillikBonus.map((b, i) => (
                        <div key={i} style={{padding:'10px 12px', background:C.bgInput, borderRadius:6, borderLeft:`3px solid ${i === 0 ? '#cd7f32' : i === 1 ? '#94a3b8' : '#fbbf24'}`}}>
                          <div style={{fontSize:10, fontWeight:700, color:C.textSec, textTransform:'uppercase'}}>{b.etiket}</div>
                          <div style={{fontSize:11, color:C.textSec, marginTop:2}}>{b.min}–{b.max === 9999 ? '∞' : b.max} dosya/yıl</div>
                          <div style={{fontSize:14, fontWeight:800, color:C.text, marginTop:4}}>{b.bonus.toLocaleString('tr-TR')} ₺</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* ŞABLON LİSTESİ */}
            <div style={{background:C.bgCard, borderRadius:8, border:`1px solid ${C.border}`, padding:'14px 16px'}}>
              <div style={{fontSize:11, color:C.textSec, fontWeight:700, letterSpacing:0.5, textTransform:'uppercase', marginBottom:10}}>
                {aktifModel ? 'Modeli Değiştir / Yeni Şablon Uygula' : 'Şablonlardan Birini Seçin'}
              </div>
              <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:10}}>
                {Object.entries(SABLON_LISTESI).map(([key, s]) => (
                  <div key={key} onClick={() => sablonUygula(key)}
                    style={{padding:'12px 14px', background:C.bgInput, border:`1px solid ${C.border}`, borderRadius:6, cursor:'pointer', transition:'all .15s'}}
                    onMouseEnter={e => { e.currentTarget.style.borderColor = C.accent; e.currentTarget.style.background = C.bgHover; }}
                    onMouseLeave={e => { e.currentTarget.style.borderColor = C.border; e.currentTarget.style.background = C.bgInput; }}>
                    <div style={{display:'flex', alignItems:'center', gap:8, marginBottom:6}}>
                      <LIcon name={s.model_tipi === 'kademeli_saha' ? 'TrendingUp' : s.model_tipi === 'kademeli_ofis' ? 'Phone' : s.model_tipi === 'sabit_prim' ? 'Calculator' : 'DollarSign'} size={14} color={C.accent}/>
                      <div style={{fontSize:12, fontWeight:700, color:C.text}}>{s.etiket}</div>
                    </div>
                    <div style={{fontSize:10, color:C.textSec, lineHeight:1.5}}>{s.aciklama}</div>
                    {s.sabit_maas > 0 && <div style={{fontSize:10, color:C.success, marginTop:4, fontWeight:600}}>Sabit Maaş: {s.sabit_maas.toLocaleString('tr-TR')} ₺</div>}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* CARİ HESAP */}
        {tab === 'cari' && cari && (
          <div>
            <div style={{display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:10, marginBottom:14}}>
              <div style={{padding:'12px 14px', background:C.bgCard, borderRadius:6, border:`1px solid ${C.border}`, borderLeft:`3px solid ${C.success}`}}>
                <div style={{fontSize:9, color:C.textSec, fontWeight:700, textTransform:'uppercase', letterSpacing:0.5}}>Toplam Alacak</div>
                <div style={{fontSize:16, fontWeight:800, color:C.success, marginTop:4}}>{(cari.ozet?.toplam_alacak || 0).toLocaleString('tr-TR')} ₺</div>
              </div>
              <div style={{padding:'12px 14px', background:C.bgCard, borderRadius:6, border:`1px solid ${C.border}`, borderLeft:`3px solid ${C.danger}`}}>
                <div style={{fontSize:9, color:C.textSec, fontWeight:700, textTransform:'uppercase', letterSpacing:0.5}}>Toplam Ödeme</div>
                <div style={{fontSize:16, fontWeight:800, color:C.danger, marginTop:4}}>{(cari.ozet?.toplam_borc || 0).toLocaleString('tr-TR')} ₺</div>
              </div>
              <div style={{padding:'12px 14px', background:C.bgCard, borderRadius:6, border:`1px solid ${C.border}`, borderLeft:`3px solid ${C.accent}`}}>
                <div style={{fontSize:9, color:C.textSec, fontWeight:700, textTransform:'uppercase', letterSpacing:0.5}}>Net Bakiye</div>
                <div style={{fontSize:16, fontWeight:800, color:C.accent, marginTop:4}}>{(cari.ozet?.net_bakiye || 0).toLocaleString('tr-TR')} ₺</div>
              </div>
              <div style={{padding:'12px 14px', background:C.bgCard, borderRadius:6, border:`1px solid ${C.border}`, borderLeft:`3px solid ${C.warning}`}}>
                <div style={{fontSize:9, color:C.textSec, fontWeight:700, textTransform:'uppercase', letterSpacing:0.5}}>Bekleyen Prim</div>
                <div style={{fontSize:16, fontWeight:800, color:C.warning, marginTop:4}}>{cari.ozet?.bekleyen_prim_sayisi || 0} adet</div>
              </div>
            </div>
            <div style={{background:C.bgCard, borderRadius:6, border:`1px solid ${C.border}`, overflow:'hidden'}}>
              <div style={{maxHeight:'42vh', overflowY:'auto'}}>
                <table style={{width:'100%', fontSize:12, borderCollapse:'collapse'}}>
                  <thead style={{background:C.bgInput, position:'sticky', top:0}}>
                    <tr>
                      <th style={{padding:'8px 12px', textAlign:'left', fontWeight:600, color:C.textSec}}>Tarih</th>
                      <th style={{padding:'8px 12px', textAlign:'left', fontWeight:600, color:C.textSec}}>Açıklama</th>
                      <th style={{padding:'8px 12px', textAlign:'right', fontWeight:600, color:C.textSec}}>Alacak</th>
                      <th style={{padding:'8px 12px', textAlign:'right', fontWeight:600, color:C.textSec}}>Ödeme</th>
                      <th style={{padding:'8px 12px', textAlign:'right', fontWeight:600, color:C.textSec}}>Bakiye</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(cari.hareketler || []).map((h, i) => (
                      <tr key={i} style={{borderBottom:`1px solid ${C.border}`}}>
                        <td style={{padding:'7px 12px', color:C.textSec}}>{(h.tarih || '').slice(0,10)}</td>
                        <td style={{padding:'7px 12px', color:C.text}}>{h.aciklama}</td>
                        <td style={{padding:'7px 12px', textAlign:'right', color:C.success, fontWeight:600}}>{h.alacak ? h.alacak.toLocaleString('tr-TR') : '—'}</td>
                        <td style={{padding:'7px 12px', textAlign:'right', color:C.danger, fontWeight:600}}>{h.borc ? h.borc.toLocaleString('tr-TR') : '—'}</td>
                        <td style={{padding:'7px 12px', textAlign:'right', fontWeight:700, color:C.text}}>{h.bakiye?.toLocaleString('tr-TR')}</td>
                      </tr>
                    ))}
                    {(cari.hareketler || []).length === 0 && <tr><td colSpan="5" style={{padding:30, textAlign:'center', color:C.textSec}}>Henüz hareket yok</td></tr>}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ÖDEMELER */}
        {tab === 'odeme' && (
          <div>
            <div style={{display:'flex', justifyContent:'flex-end', marginBottom:12}}>
              <button style={{...S.btn, ...S.btnP, fontSize:12, padding:'8px 14px'}} onClick={() => setOdemeOpen(!odemeOpen)}>
                <LIcon name={odemeOpen ? 'X' : 'Plus'} size={13}/>
                {odemeOpen ? ' İPTAL' : ' YENİ ÖDEME'}
              </button>
            </div>
            {odemeOpen && (
              <div style={{padding:14, background:C.bgCard, border:`1px solid ${C.accent}`, borderRadius:6, marginBottom:14}}>
                <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:10}}>
                  <div>
                    <div style={S.label}>ÖDEME TÜRÜ</div>
                    <select style={S.select} value={odemeData.odeme_turu} onChange={e => setOdemeData({...odemeData, odeme_turu:e.target.value})}>
                      <option value="maas">Maaş</option>
                      <option value="prim">Prim</option>
                      <option value="avans">Avans</option>
                      <option value="ikramiye">İkramiye</option>
                      <option value="mesai">Mesai</option>
                      <option value="diger">Diğer</option>
                    </select>
                  </div>
                  <div>
                    <div style={S.label}>TUTAR (TL)</div>
                    <input type="number" style={S.input} value={odemeData.tutar} onChange={e => setOdemeData({...odemeData, tutar:e.target.value})}/>
                  </div>
                  <div>
                    <div style={S.label}>KASA</div>
                    <select style={S.select} value={odemeData.kasa_id} onChange={e => setOdemeData({...odemeData, kasa_id:e.target.value})}>
                      <option value="">Seçin...</option>
                      {kasalar.map(k => <option key={k.id} value={k.id}>{k.ad} ({(parseFloat(k.bakiye) || 0).toLocaleString('tr-TR')} ₺)</option>)}
                    </select>
                  </div>
                  <div>
                    <div style={S.label}>DÖNEM (YYYY-MM)</div>
                    <input type="text" style={S.input} placeholder="2026-05" value={odemeData.donem} onChange={e => setOdemeData({...odemeData, donem:e.target.value})}/>
                  </div>
                </div>
                <div style={{marginTop:10}}>
                  <div style={S.label}>AÇIKLAMA</div>
                  <input type="text" style={S.input} value={odemeData.aciklama} onChange={e => setOdemeData({...odemeData, aciklama:e.target.value})}/>
                </div>
                <div style={{display:'flex', gap:8, marginTop:14, justifyContent:'flex-end'}}>
                  <button style={{...S.btn, ...S.btnG}} onClick={() => setOdemeOpen(false)}>İPTAL</button>
                  <button style={{...S.btn, ...S.btnS}} onClick={odemeYap}>KAYDET</button>
                </div>
              </div>
            )}
            <div style={{background:C.bgCard, borderRadius:6, border:`1px solid ${C.border}`, overflow:'hidden'}}>
              <table style={{width:'100%', fontSize:12, borderCollapse:'collapse'}}>
                <thead style={{background:C.bgInput}}>
                  <tr>
                    <th style={{padding:'8px 12px', textAlign:'left', fontWeight:600, color:C.textSec}}>Tarih</th>
                    <th style={{padding:'8px 12px', textAlign:'left', fontWeight:600, color:C.textSec}}>Tür</th>
                    <th style={{padding:'8px 12px', textAlign:'left', fontWeight:600, color:C.textSec}}>Açıklama</th>
                    <th style={{padding:'8px 12px', textAlign:'right', fontWeight:600, color:C.textSec}}>Tutar</th>
                  </tr>
                </thead>
                <tbody>
                  {odemeler.map((h, i) => (
                    <tr key={i} style={{borderBottom:`1px solid ${C.border}`}}>
                      <td style={{padding:'7px 12px', color:C.textSec}}>{(h.tarih || '').slice(0,10)}</td>
                      <td style={{padding:'7px 12px'}}>
                        <span style={{padding:'2px 8px', borderRadius:4, background:`${C.accent}18`, color:C.accent, fontSize:10, fontWeight:700, textTransform:'uppercase'}}>{h.odeme_turu}</span>
                      </td>
                      <td style={{padding:'7px 12px', color:C.text}}>{h.aciklama}</td>
                      <td style={{padding:'7px 12px', textAlign:'right', color:C.danger, fontWeight:700}}>{h.borc?.toLocaleString('tr-TR')} ₺</td>
                    </tr>
                  ))}
                  {odemeler.length === 0 && <tr><td colSpan="4" style={{padding:30, textAlign:'center', color:C.textSec}}>Henüz ödeme yok</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* EVRAKLAR */}
        {tab === 'evrak' && (
          <div>
            <div style={{display:'flex', justifyContent:'flex-end', marginBottom:12}}>
              <button style={{...S.btn, ...S.btnP, fontSize:12, padding:'8px 14px'}} onClick={() => setEvrakOpen(!evrakOpen)}>
                <LIcon name={evrakOpen ? 'X' : 'Upload'} size={13}/>
                {evrakOpen ? ' İPTAL' : ' EVRAK YÜKLE'}
              </button>
            </div>
            {evrakOpen && (
              <div style={{padding:14, background:C.bgCard, border:`1px solid ${C.accent}`, borderRadius:6, marginBottom:14}}>
                <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:10}}>
                  <div>
                    <div style={S.label}>EVRAK TÜRÜ</div>
                    <select style={S.select} value={evrakTuru} onChange={e => setEvrakTuru(e.target.value)}>
                      <option value="sozlesme">İş Sözleşmesi</option>
                      <option value="kvkk">KVKK Taahhütnamesi</option>
                      <option value="arac_zimmet">Araç Zimmet</option>
                      <option value="maas_dekontu">Maaş Dekontu</option>
                      <option value="avans_dekontu">Avans Dekontu</option>
                      <option value="kimlik">Kimlik / Ehliyet</option>
                      <option value="diger">Diğer</option>
                    </select>
                  </div>
                  <div>
                    <div style={S.label}>ETİKET</div>
                    <input type="text" style={S.input} placeholder="örn: Mart 2026 Maaş Dekontu" value={evrakEtiketi} onChange={e => setEvrakEtiketi(e.target.value)}/>
                  </div>
                </div>
                <div style={{marginTop:10}}>
                  <input type="file" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx" onChange={e => setEvrakFile(e.target.files[0])}
                    style={{padding:8, background:C.bgInput, border:`1px dashed ${C.border}`, borderRadius:6, width:'100%', color:C.text, fontSize:12}}/>
                </div>
                <div style={{display:'flex', gap:8, marginTop:14, justifyContent:'flex-end'}}>
                  <button style={{...S.btn, ...S.btnG}} onClick={() => setEvrakOpen(false)}>İPTAL</button>
                  <button style={{...S.btn, ...S.btnS}} onClick={evrakYukle}>YÜKLE</button>
                </div>
              </div>
            )}
            <div style={{background:C.bgCard, borderRadius:6, border:`1px solid ${C.border}`, overflow:'hidden'}}>
              <table style={{width:'100%', fontSize:12, borderCollapse:'collapse'}}>
                <thead style={{background:C.bgInput}}>
                  <tr>
                    <th style={{padding:'8px 12px', textAlign:'left', fontWeight:600, color:C.textSec, width:42}}></th>
                    <th style={{padding:'8px 12px', textAlign:'left', fontWeight:600, color:C.textSec}}>Etiket / Dosya Adı</th>
                    <th style={{padding:'8px 12px', textAlign:'left', fontWeight:600, color:C.textSec}}>Tür</th>
                    <th style={{padding:'8px 12px', textAlign:'left', fontWeight:600, color:C.textSec}}>Boyut</th>
                    <th style={{padding:'8px 12px', textAlign:'left', fontWeight:600, color:C.textSec}}>Tarih</th>
                    <th style={{padding:'8px 12px', textAlign:'right', fontWeight:600, color:C.textSec}}>İşlem</th>
                  </tr>
                </thead>
                <tbody>
                  {evraklar.map(ev => (
                    <tr key={ev.id} style={{borderBottom:`1px solid ${C.border}`}}>
                      <td style={{padding:'7px 12px'}}>
                        <LIcon name={(ev.mime_type || '').includes('pdf') ? 'FileText' : 'Image'} size={16} color={C.accent}/>
                      </td>
                      <td style={{padding:'7px 12px', fontWeight:600, color:C.text}}>{ev.evrak_etiketi || ev.dosya_adi}</td>
                      <td style={{padding:'7px 12px', color:C.textSec}}>{ev.evrak_turu}</td>
                      <td style={{padding:'7px 12px', color:C.textSec}}>{ev.boyut_okunabilir}</td>
                      <td style={{padding:'7px 12px', color:C.textSec}}>{(ev.created_at || '').slice(0,10)}</td>
                      <td style={{padding:'7px 12px', textAlign:'right'}}>
                        <button style={{...S.btnMini, ...S.btnMiniP, marginRight:4}} onClick={() => MR._evrakAc(ev.preview_url, 'inline', ev.dosya_adi)} title="Önizle">
                          <LIcon name="Eye" size={11}/>
                        </button>
                        <button style={{...S.btnMini, ...S.btnMiniS, marginRight:4}} onClick={() => MR._evrakAc(ev.download_url, 'download', ev.dosya_adi)} title="İndir">
                          <LIcon name="Download" size={11}/>
                        </button>
                        <button style={{...S.btnMini, ...S.btnMiniD}} onClick={() => evrakSil(ev.id)} title="Sil">
                          <LIcon name="Trash2" size={11}/>
                        </button>
                      </td>
                    </tr>
                  ))}
                  {evraklar.length === 0 && <tr><td colSpan="6" style={{padding:30, textAlign:'center', color:C.textSec}}>Henüz evrak yok</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        )}
        </div>

        <div style={{display:'flex', justifyContent:'flex-end', marginTop:14, paddingTop:14, borderTop:`1px solid ${C.border}`}}>
          <button style={{...S.btn, ...S.btnG}} onClick={onClose}>KAPAT</button>
        </div>
      </div>
    </MR.Modal>
  );
};

/* ═══════════ PAYDAŞ KART MODAL — Aynı sade stil ═══════════ */
MR.PaydasKartModal = ({open, onClose, paydas, user}) => {
  const {C, S, LIcon, api} = MR;
  const [tab, setTab] = useState('genel');
  const [pData, setPData] = useState(paydas || {});
  const [edit, setEdit] = useState(false);
  const [draft, setDraft] = useState({});
  const [cari, setCari] = useState(null);
  const [evraklar, setEvraklar] = useState([]);
  const [evrakOpen, setEvrakOpen] = useState(false);
  const [evrakFile, setEvrakFile] = useState(null);
  const [evrakTuru, setEvrakTuru] = useState('sozlesme');
  const [evrakEtiketi, setEvrakEtiketi] = useState('');

  useEffect(() => {
    if (open && paydas?.id) { setPData(paydas); setDraft({}); setEdit(false); yukle(); }
  }, [open, paydas?.id]);

  const yukle = async () => {
    const [c, e] = await Promise.all([
      api.req('/paydas/cari-hesap.php?id=' + paydas.id),
      api.req('/paydas/evrak-list.php?id=' + paydas.id)
    ]);
    if (c?.success) setCari(c.data);
    if (e?.success) setEvraklar(e.data || []);
  };

  const editAc = () => { setDraft({...pData}); setEdit(true); };
  const editIptal = () => { setDraft({}); setEdit(false); };
  const editKaydet = async () => {
    const r = await api.paydasUpdate({id: pData.id, ...draft});
    if (r?.success) { MR.toast('Bilgiler güncellendi', 'success'); setPData({...pData, ...draft}); setEdit(false); }
    else MR.toast(r?.error || 'Güncelleme hatası', 'error');
  };
  const setD = (k, v) => setDraft(p => ({...p, [k]: v}));

  const evrakYukle = async () => {
    if (!evrakFile) { MR.toast('Dosya seçin', 'error'); return; }
    const fd = new FormData();
    fd.append('paydas_id', pData.id);
    fd.append('evrak_turu', evrakTuru);
    fd.append('evrak_etiketi', evrakEtiketi);
    fd.append('file', evrakFile);
    const h = {}; if (api.token) h['Authorization'] = 'Bearer ' + api.token;
    const r = await fetch('/api/v1/paydas/evrak-yukle.php', {method: 'POST', headers: h, body: fd}).then(r => r.json());
    if (r?.success) { MR.toast('Evrak yüklendi', 'success'); setEvrakOpen(false); setEvrakFile(null); setEvrakEtiketi(''); yukle(); }
    else MR.toast(r?.error || 'Yükleme hatası', 'error');
  };

  const evrakSil = async (id) => {
    if (!confirm('Evrakı silmek istediğinize emin misiniz?')) return;
    const r = await api.req('/paydas/evrak-sil.php?id=' + id, {method: 'DELETE'});
    if (r?.success) { MR.toast('Evrak silindi', 'success'); yukle(); }
    else MR.toast(r?.error || 'Silme hatası', 'error');
  };

  if (!open) return null;

  const tabs = [
    {id:'genel', label:'Genel Bilgiler', icon:'User'},
    {id:'cari',  label:'Cari Hesap',     icon:'FileText'},
    {id:'evrak', label:'Evraklar',       icon:'Folder'},
  ];

  return (
    <MR.Modal open={open} onClose={onClose} title={`Paydaş Kartı — ${pData?.ad || ''}`} width="92vw">
      <div style={{display:'flex', flexDirection:'column', height:'82vh'}}>

        <div style={{display:'flex', alignItems:'center', gap:14, padding:'12px 16px', background:C.bgCard, border:`1px solid ${C.border}`, borderRadius:8, marginBottom:14}}>
          <div style={{width:44, height:44, borderRadius:8, background:C.purple, color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:16, fontWeight:800}}>
            {(pData?.ad || '?').slice(0,2).toUpperCase()}
          </div>
          <div style={{flex:1}}>
            <div style={{fontSize:14, fontWeight:700}}>{pData?.ad}</div>
            <div style={{fontSize:11, color:C.textSec, marginTop:2}}>{pData?.tur || '-'} · {pData?.telefon || '-'}</div>
          </div>
          {cari?.ozet && (
            <div style={{textAlign:'right'}}>
              <div style={{fontSize:9, color:C.textSec, fontWeight:700, textTransform:'uppercase', letterSpacing:0.5}}>Bekleyen</div>
              <div style={{fontSize:14, fontWeight:800, color:cari.ozet.bekleyen > 0 ? C.warning : C.success}}>
                {(cari.ozet.bekleyen || 0).toLocaleString('tr-TR')} ₺
              </div>
            </div>
          )}
        </div>

        <div style={{display:'flex', gap:2, borderBottom:`1px solid ${C.border}`, marginBottom:14}}>
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              padding:'10px 16px', border:'none',
              background: tab === t.id ? C.bgCard : 'transparent',
              color: tab === t.id ? C.purple : C.textSec,
              fontWeight: tab === t.id ? 700 : 500, fontSize:12,
              cursor:'pointer', borderRadius:'6px 6px 0 0',
              borderBottom: tab === t.id ? `2px solid ${C.purple}` : '2px solid transparent',
              display:'flex', alignItems:'center', gap:6
            }}>
              <LIcon name={t.icon} size={14}/>
              {t.label}
            </button>
          ))}
        </div>

        <div style={{flex:1, overflowY:'auto', paddingRight:6}}>

        {tab === 'genel' && (
          <div>
            <div style={{display:'flex', justifyContent:'flex-end', marginBottom:10, gap:8}}>
              {!edit ? (
                <button style={{...S.btn, ...S.btnP, fontSize:12, padding:'8px 14px'}} onClick={editAc}>
                  <LIcon name="Edit2" size={13}/> DÜZENLE
                </button>
              ) : (
                <>
                  <button style={{...S.btn, ...S.btnG, fontSize:12, padding:'8px 14px'}} onClick={editIptal}>İPTAL</button>
                  <button style={{...S.btn, ...S.btnS, fontSize:12, padding:'8px 14px'}} onClick={editKaydet}>KAYDET</button>
                </>
              )}
            </div>
            <div style={{background:C.bgCard, borderRadius:8, border:`1px solid ${C.border}`, overflow:'hidden'}}>
              <BilgiSatir label="Ad / Ünvan" value={pData?.ad} edit={edit} dgVal={draft.ad} onChange={v => setD('ad', v)}/>
              <BilgiSatir label="Yetkili Kişi" value={pData?.yetkili} edit={edit} dgVal={draft.yetkili} onChange={v => setD('yetkili', v)}/>
              <BilgiSatir label="Tür" value={pData?.tur} edit={edit} dgVal={draft.tur} onChange={v => setD('tur', v)}
                options={[{value:'servis',label:'Servis'},{value:'kaportaci',label:'Kaportacı'},{value:'eksper',label:'Eksper'},{value:'avukat',label:'Avukat'},{value:'sahis',label:'Şahıs'},{value:'diger',label:'Diğer'}]}/>
              <BilgiSatir label="Telefon" value={pData?.telefon} edit={edit} dgVal={draft.telefon} onChange={v => setD('telefon', v)}/>
              <BilgiSatir label="E-Posta" value={pData?.email} edit={edit} dgVal={draft.email} type="email" onChange={v => setD('email', v)}/>
              <BilgiSatir label="İl" value={pData?.il} edit={edit} dgVal={draft.il} onChange={v => setD('il', v)}/>
              <BilgiSatir label="Adres" value={pData?.adres} edit={edit} dgVal={draft.adres} onChange={v => setD('adres', v)}/>
              <BilgiSatir label="Komisyon Oranı (%)" value={pData?.komisyon_orani ? '%' + pData.komisyon_orani : '—'} edit={edit} dgVal={draft.komisyon_orani} type="number" onChange={v => setD('komisyon_orani', v)}/>
              <BilgiSatir label="Prim ADK (TL/dosya)" value={pData?.prim_adk ? parseFloat(pData.prim_adk).toLocaleString('tr-TR') + ' ₺' : '—'} edit={edit} dgVal={draft.prim_adk} type="number" onChange={v => setD('prim_adk', v)}/>
              <BilgiSatir label="Prim BH (TL/dosya)" value={pData?.prim_bh ? parseFloat(pData.prim_bh).toLocaleString('tr-TR') + ' ₺' : '—'} edit={edit} dgVal={draft.prim_bh} type="number" onChange={v => setD('prim_bh', v)}/>
              <BilgiSatir label="Notlar" value={pData?.notlar} edit={edit} dgVal={draft.notlar} onChange={v => setD('notlar', v)}/>
            </div>
          </div>
        )}

        {tab === 'cari' && cari && (
          <div>
            <div style={{display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:10, marginBottom:14}}>
              <div style={{padding:'12px 14px', background:C.bgCard, borderRadius:6, border:`1px solid ${C.border}`, borderLeft:`3px solid ${C.accent}`}}>
                <div style={{fontSize:9, color:C.textSec, fontWeight:700, textTransform:'uppercase'}}>Toplam Komisyon</div>
                <div style={{fontSize:16, fontWeight:800, color:C.accent, marginTop:4}}>{(cari.ozet?.toplam_komisyon || 0).toLocaleString('tr-TR')} ₺</div>
              </div>
              <div style={{padding:'12px 14px', background:C.bgCard, borderRadius:6, border:`1px solid ${C.border}`, borderLeft:`3px solid ${C.success}`}}>
                <div style={{fontSize:9, color:C.textSec, fontWeight:700, textTransform:'uppercase'}}>Ödenen</div>
                <div style={{fontSize:16, fontWeight:800, color:C.success, marginTop:4}}>{(cari.ozet?.odenen || 0).toLocaleString('tr-TR')} ₺</div>
              </div>
              <div style={{padding:'12px 14px', background:C.bgCard, borderRadius:6, border:`1px solid ${C.border}`, borderLeft:`3px solid ${C.warning}`}}>
                <div style={{fontSize:9, color:C.textSec, fontWeight:700, textTransform:'uppercase'}}>Bekleyen</div>
                <div style={{fontSize:16, fontWeight:800, color:C.warning, marginTop:4}}>{(cari.ozet?.bekleyen || 0).toLocaleString('tr-TR')} ₺</div>
              </div>
              <div style={{padding:'12px 14px', background:C.bgCard, borderRadius:6, border:`1px solid ${C.border}`, borderLeft:`3px solid ${C.purple}`}}>
                <div style={{fontSize:9, color:C.textSec, fontWeight:700, textTransform:'uppercase'}}>İşlem</div>
                <div style={{fontSize:16, fontWeight:800, color:C.purple, marginTop:4}}>{cari.ozet?.islem_sayisi || 0}</div>
              </div>
            </div>
            <div style={{background:C.bgCard, borderRadius:6, border:`1px solid ${C.border}`, overflow:'hidden'}}>
              <div style={{maxHeight:'42vh', overflowY:'auto'}}>
                <table style={{width:'100%', fontSize:12, borderCollapse:'collapse'}}>
                  <thead style={{background:C.bgInput, position:'sticky', top:0}}>
                    <tr>
                      <th style={{padding:'8px 12px', textAlign:'left'}}>Tarih</th>
                      <th style={{padding:'8px 12px', textAlign:'left'}}>Açıklama</th>
                      <th style={{padding:'8px 12px', textAlign:'right'}}>Tutar</th>
                      <th style={{padding:'8px 12px', textAlign:'center'}}>Durum</th>
                      <th style={{padding:'8px 12px', textAlign:'left'}}>Kasa</th>
                    </tr>
                  </thead>
                  <tbody>
                    {cari.hareketler?.map((h, i) => (
                      <tr key={i} style={{borderBottom:`1px solid ${C.border}`}}>
                        <td style={{padding:'7px 12px', color:C.textSec}}>{(h.tarih || '').slice(0,10)}</td>
                        <td style={{padding:'7px 12px'}}>{h.aciklama}</td>
                        <td style={{padding:'7px 12px', textAlign:'right', fontWeight:700}}>{h.tutar?.toLocaleString('tr-TR')} ₺</td>
                        <td style={{padding:'7px 12px', textAlign:'center'}}>
                          <span style={{padding:'2px 8px', borderRadius:4, fontSize:10, fontWeight:700, textTransform:'uppercase',
                            background: h.durum === 'odendi' ? `${C.success}18` : `${C.warning}18`,
                            color: h.durum === 'odendi' ? C.success : C.warning}}>
                            {h.durum === 'odendi' ? 'ÖDENDİ' : 'BEKLİYOR'}
                          </span>
                        </td>
                        <td style={{padding:'7px 12px', color:C.textSec, fontSize:11}}>{h.kasa_adi || '—'}</td>
                      </tr>
                    ))}
                    {(cari.hareketler || []).length === 0 && <tr><td colSpan="5" style={{padding:30, textAlign:'center', color:C.textSec}}>Henüz komisyon yok</td></tr>}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {tab === 'evrak' && (
          <div>
            <div style={{display:'flex', justifyContent:'flex-end', marginBottom:12}}>
              <button style={{...S.btn, ...S.btnP, fontSize:12, padding:'8px 14px'}} onClick={() => setEvrakOpen(!evrakOpen)}>
                <LIcon name={evrakOpen ? 'X' : 'Upload'} size={13}/>
                {evrakOpen ? ' İPTAL' : ' EVRAK YÜKLE'}
              </button>
            </div>
            {evrakOpen && (
              <div style={{padding:14, background:C.bgCard, border:`1px solid ${C.purple}`, borderRadius:6, marginBottom:14}}>
                <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:10}}>
                  <div>
                    <div style={S.label}>EVRAK TÜRÜ</div>
                    <select style={S.select} value={evrakTuru} onChange={e => setEvrakTuru(e.target.value)}>
                      <option value="sozlesme">Sözleşme</option>
                      <option value="dekont">Dekont</option>
                      <option value="diger">Diğer</option>
                    </select>
                  </div>
                  <div>
                    <div style={S.label}>ETİKET</div>
                    <input type="text" style={S.input} value={evrakEtiketi} onChange={e => setEvrakEtiketi(e.target.value)}/>
                  </div>
                </div>
                <div style={{marginTop:10}}>
                  <input type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={e => setEvrakFile(e.target.files[0])}
                    style={{padding:8, background:C.bgInput, border:`1px dashed ${C.border}`, borderRadius:6, width:'100%', color:C.text, fontSize:12}}/>
                </div>
                <div style={{display:'flex', gap:8, marginTop:14, justifyContent:'flex-end'}}>
                  <button style={{...S.btn, ...S.btnG}} onClick={() => setEvrakOpen(false)}>İPTAL</button>
                  <button style={{...S.btn, ...S.btnS}} onClick={evrakYukle}>YÜKLE</button>
                </div>
              </div>
            )}
            <div style={{background:C.bgCard, borderRadius:6, border:`1px solid ${C.border}`, overflow:'hidden'}}>
              <table style={{width:'100%', fontSize:12, borderCollapse:'collapse'}}>
                <thead style={{background:C.bgInput}}>
                  <tr>
                    <th style={{padding:'8px 12px', textAlign:'left', width:42}}></th>
                    <th style={{padding:'8px 12px', textAlign:'left'}}>Etiket / Dosya</th>
                    <th style={{padding:'8px 12px', textAlign:'left'}}>Tür</th>
                    <th style={{padding:'8px 12px', textAlign:'left'}}>Boyut</th>
                    <th style={{padding:'8px 12px', textAlign:'left'}}>Tarih</th>
                    <th style={{padding:'8px 12px', textAlign:'right'}}>İşlem</th>
                  </tr>
                </thead>
                <tbody>
                  {evraklar.map(ev => (
                    <tr key={ev.id} style={{borderBottom:`1px solid ${C.border}`}}>
                      <td style={{padding:'7px 12px'}}><LIcon name={(ev.mime_type || '').includes('pdf') ? 'FileText' : 'Image'} size={16} color={C.purple}/></td>
                      <td style={{padding:'7px 12px', fontWeight:600}}>{ev.evrak_etiketi || ev.dosya_adi}</td>
                      <td style={{padding:'7px 12px', color:C.textSec}}>{ev.evrak_turu}</td>
                      <td style={{padding:'7px 12px', color:C.textSec}}>{ev.boyut_okunabilir}</td>
                      <td style={{padding:'7px 12px', color:C.textSec}}>{(ev.created_at || '').slice(0,10)}</td>
                      <td style={{padding:'7px 12px', textAlign:'right'}}>
                        <button style={{...S.btnMini, ...S.btnMiniP, marginRight:4}} onClick={() => MR._evrakAc(ev.preview_url, 'inline', ev.dosya_adi)} title="Önizle"><LIcon name="Eye" size={11}/></button>
                        <button style={{...S.btnMini, ...S.btnMiniS, marginRight:4}} onClick={() => MR._evrakAc(ev.download_url, 'download', ev.dosya_adi)} title="İndir"><LIcon name="Download" size={11}/></button>
                        <button style={{...S.btnMini, ...S.btnMiniD}} onClick={() => evrakSil(ev.id)} title="Sil"><LIcon name="Trash2" size={11}/></button>
                      </td>
                    </tr>
                  ))}
                  {evraklar.length === 0 && <tr><td colSpan="6" style={{padding:30, textAlign:'center', color:C.textSec}}>Henüz evrak yok</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        )}
        </div>

        <div style={{display:'flex', justifyContent:'flex-end', marginTop:14, paddingTop:14, borderTop:`1px solid ${C.border}`}}>
          <button style={{...S.btn, ...S.btnG}} onClick={onClose}>KAPAT</button>
        </div>
      </div>
    </MR.Modal>
  );
};
