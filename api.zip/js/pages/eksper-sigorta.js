/* ═══════════════════════════════════════════════════════════════════
   PAYDAŞLAR > EKSPER & SİGORTA — 04.05.2026
   2 sekmeli: EKSPER FİRMALARI / SİGORTA ŞİRKETLERİ
   ═══════════════════════════════════════════════════════════════════ */
const MR = window.MR || (window.MR = {});
const {useState, useEffect} = React;

MR.EksperSigortaPage = ({setPage, user}) => {
  const {C, S, LIcon, SectionTitle, FormGroup, Modal, api} = MR;
  const [tab, setTab] = useState('eksper'); // 'eksper' | 'sigorta'
  return React.createElement('div', {className:'fade-in'},
    React.createElement(SectionTitle, {icon:'Network', title:'EKSPER & SİGORTA TANIMLARI', sub:'DOSYA AÇILIŞ DROPDOWN VE OTOMATİK MAİL ALTYAPISI'}),
    /* SEKME KARTLARI */
    React.createElement('div', {style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12,marginBottom:18}},
      React.createElement('div', {onClick:()=>setTab('eksper'),
        style:{padding:18,borderRadius:12,cursor:'pointer',transition:'all .2s',
          background: tab==='eksper' ? `linear-gradient(135deg, ${C.accent}22, ${C.accent}11)` : C.bgCard,
          border: tab==='eksper' ? `2px solid ${C.accent}` : `1px solid ${C.border}`,
          boxShadow: tab==='eksper' ? `0 4px 14px ${C.accent}33` : '0 1px 3px rgba(0,0,0,0.04)'}},
        React.createElement('div', {style:{display:'flex',alignItems:'center',gap:12}},
          React.createElement('div', {style:{width:48,height:48,borderRadius:10,background:tab==='eksper'?`${C.accent}22`:`${C.accent}08`,display:'flex',alignItems:'center',justifyContent:'center'}},
            React.createElement(LIcon, {name:'Search', size:24, color: tab==='eksper'?C.accent:C.textMuted})
          ),
          React.createElement('div', null,
            React.createElement('div', {style:{fontSize:16,fontWeight:800,color:tab==='eksper'?C.accent:C.text,letterSpacing:0.5}}, 'EKSPER FİRMALARI'),
            React.createElement('div', {style:{fontSize:11,color:C.textMuted,marginTop:2}}, 'Eksperler & iletişim bilgileri')
          )
        )
      ),
      React.createElement('div', {onClick:()=>setTab('sigorta'),
        style:{padding:18,borderRadius:12,cursor:'pointer',transition:'all .2s',
          background: tab==='sigorta' ? `linear-gradient(135deg, ${C.success}22, ${C.success}11)` : C.bgCard,
          border: tab==='sigorta' ? `2px solid ${C.success}` : `1px solid ${C.border}`,
          boxShadow: tab==='sigorta' ? `0 4px 14px ${C.success}33` : '0 1px 3px rgba(0,0,0,0.04)'}},
        React.createElement('div', {style:{display:'flex',alignItems:'center',gap:12}},
          React.createElement('div', {style:{width:48,height:48,borderRadius:10,background:tab==='sigorta'?`${C.success}22`:`${C.success}08`,display:'flex',alignItems:'center',justifyContent:'center'}},
            React.createElement(LIcon, {name:'Shield', size:24, color: tab==='sigorta'?C.success:C.textMuted})
          ),
          React.createElement('div', null,
            React.createElement('div', {style:{fontSize:16,fontWeight:800,color:tab==='sigorta'?C.success:C.text,letterSpacing:0.5}}, 'SİGORTA ŞİRKETLERİ'),
            React.createElement('div', {style:{fontSize:11,color:C.textMuted,marginTop:2}}, 'Şirket & hasar e-posta bilgileri')
          )
        )
      )
    ),
    /* SEKME İÇERİĞİ */
    tab === 'eksper'
      ? React.createElement(MR.EksperFirmaListesi, {user})
      : React.createElement(MR.SigortaSirketListesi, {user})
  );
};

/* ═══ EKSPER FİRMA LİSTESİ + EKLE/DÜZENLE/SİL ═══ */
MR.EksperFirmaListesi = ({user}) => {
  const {C, S, LIcon, FormGroup, Modal, api} = MR;
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [arama, setArama] = useState('');
  const [modal, setModal] = useState(null); // {mode: 'yeni'|'duzenle', data}
  const [silOnay, setSilOnay] = useState(null);
  const [mesaj, setMesaj] = useState(null);

  const tok = () => localStorage.getItem('mr_token') || localStorage.getItem('token') || localStorage.getItem('jwt') || '';
  const apiCall = async (path, options={}) => {
    const headers = {'Content-Type':'application/json', ...(options.headers||{})};
    const t = tok(); if (t) headers['Authorization'] = 'Bearer ' + t;
    try {
      const r = await fetch(path, {...options, headers, credentials:'include'});
      return await r.json();
    } catch(e) { return {success:false, error: e.message}; }
  };

  const yukle = async () => {
    setLoading(true);
    const q = arama ? '&q=' + encodeURIComponent(arama) : '';
    const r = await apiCall('/api/v1/eksper/list.php?durum=aktif' + q);
    if (r?.success) setItems(r.data?.items || []);
    setLoading(false);
  };
  useEffect(() => { yukle(); }, []);
  useEffect(() => { const t = setTimeout(yukle, 300); return () => clearTimeout(t); }, [arama]);

  const kaydet = async (form) => {
    const path = form.id ? '/api/v1/eksper/update.php' : '/api/v1/eksper/create.php';
    const method = form.id ? 'PUT' : 'POST';
    const r = await apiCall(path, {method, body: JSON.stringify(form)});
    if (r?.success) {
      setMesaj({tip:'success', text: r.message});
      setModal(null);
      yukle();
      setTimeout(()=>setMesaj(null), 3000);
    } else {
      setMesaj({tip:'error', text: r?.error || 'Hata'});
    }
  };

  const sil = async (id) => {
    const r = await apiCall('/api/v1/eksper/delete.php?id=' + id, {method:'DELETE'});
    if (r?.success) {
      setMesaj({tip:'success', text: r.message});
      setSilOnay(null);
      yukle();
      setTimeout(()=>setMesaj(null), 3000);
    } else {
      setMesaj({tip:'error', text: r?.error || 'Hata'});
    }
  };

  return React.createElement('div', null,
    /* MESAJ */
    mesaj && React.createElement('div', {style:{padding:'10px 14px',marginBottom:12,borderRadius:8,fontSize:12,fontWeight:600,
      background: mesaj.tip==='error'?(C.danger+'22'):(C.success+'22'),
      color: mesaj.tip==='error'?C.danger:C.success}}, mesaj.text),

    /* ARAMA + EKLE */
    React.createElement('div', {style:{display:'flex',gap:10,marginBottom:14}},
      React.createElement('input', {type:'search', value:arama, onChange:e=>setArama(e.target.value),
        placeholder:'Eksper / firma / telefon / e-posta ara...',
        style:Object.assign({},S.input,{flex:1,padding:'10px 14px',fontSize:13})}),
      React.createElement('button', {onClick:()=>setModal({mode:'yeni',data:{durum:'aktif'}}),
        style:Object.assign({},S.btn,S.btnP,{padding:'10px 20px',fontSize:13})},
        React.createElement(LIcon,{name:'Plus',size:14,color:'#fff'}), ' YENİ EKSPER FİRMA'
      )
    ),

    /* TABLO */
    loading
      ? React.createElement('div', {style:{padding:40,textAlign:'center',color:C.textMuted}}, 'Yükleniyor...')
      : items.length === 0
        ? React.createElement('div', {style:{padding:40,textAlign:'center',color:C.textMuted,fontStyle:'italic'}}, 'Kayıt yok. Sağ üstten "YENİ" ile ekle.')
        : React.createElement('div', {style:Object.assign({},S.card,{overflow:'hidden'})},
          React.createElement('table', {style:{width:'100%',borderCollapse:'collapse',fontSize:12}},
            React.createElement('thead', null,
              React.createElement('tr', {style:{background:C.bgInput}},
                React.createElement('th', {style:thStyle(C)}, 'EKSPER ADI'),
                React.createElement('th', {style:thStyle(C)}, 'FİRMA'),
                React.createElement('th', {style:thStyle(C)}, 'EKSPER CEP'),
                React.createElement('th', {style:thStyle(C)}, 'SABİT TEL'),
                React.createElement('th', {style:thStyle(C)}, 'OFİS CEP'),
                React.createElement('th', {style:thStyle(C)}, 'E-POSTA'),
                React.createElement('th', {style:Object.assign({},thStyle(C),{textAlign:'center'})}, 'İŞLEM')
              )
            ),
            React.createElement('tbody', null,
              items.map(it => React.createElement('tr', {key:it.id, style:{borderBottom:`1px solid ${C.border}`}},
                React.createElement('td', {style:{padding:'10px 8px',fontWeight:700,color:C.text}}, it.eksper_adi),
                React.createElement('td', {style:{padding:'10px 8px',color:C.textSec}}, it.firma_adi),
                React.createElement('td', {style:{padding:'10px 8px',fontFamily:'monospace',fontSize:11}}, it.eksper_cep || '-'),
                React.createElement('td', {style:{padding:'10px 8px',fontFamily:'monospace',fontSize:11}}, it.sabit_telefon || '-'),
                React.createElement('td', {style:{padding:'10px 8px',fontFamily:'monospace',fontSize:11}}, it.ofis_cep || '-'),
                React.createElement('td', {style:{padding:'10px 8px',fontSize:11,color:C.accent}}, it.eposta || '-'),
                React.createElement('td', {style:{padding:'10px 8px',textAlign:'center',whiteSpace:'nowrap'}},
                  React.createElement('button', {onClick:()=>setModal({mode:'duzenle',data:it}),
                    style:{padding:'5px 10px',fontSize:10,background:C.accent,color:'#fff',border:0,borderRadius:4,cursor:'pointer',marginRight:4}}, 'DÜZENLE'),
                  user?.rol === 'admin' && React.createElement('button', {onClick:()=>setSilOnay(it),
                    style:{padding:'5px 10px',fontSize:10,background:C.danger,color:'#fff',border:0,borderRadius:4,cursor:'pointer'}}, 'SİL')
                )
              ))
            )
          )
        ),

    /* EKLE/DÜZENLE MODAL */
    modal && React.createElement(MR.EksperFormModal, {mode:modal.mode, data:modal.data, onKapat:()=>setModal(null), onKaydet:kaydet}),

    /* SİL ONAY */
    silOnay && React.createElement('div', {onClick:()=>setSilOnay(null),
      style:{position:'fixed',top:0,left:0,right:0,bottom:0,background:'rgba(0,0,0,0.6)',zIndex:9999,display:'flex',alignItems:'center',justifyContent:'center'}},
      React.createElement('div', {onClick:e=>e.stopPropagation(),
        style:{background:C.bgCard,padding:24,borderRadius:12,maxWidth:420}},
        React.createElement('div', {style:{fontSize:14,fontWeight:800,marginBottom:8,color:C.danger}}, 'EKSPER SİLİNECEK'),
        React.createElement('div', {style:{fontSize:12,color:C.textSec,marginBottom:16}},
          React.createElement('strong', null, silOnay.eksper_adi + ' (' + silOnay.firma_adi + ')'), ' silinecek. Bağlı dosya varsa pasif yapılır.'
        ),
        React.createElement('div', {style:{display:'flex',gap:8,justifyContent:'flex-end'}},
          React.createElement('button', {onClick:()=>setSilOnay(null),
            style:{padding:'8px 14px',fontSize:11,background:C.bgInput,color:C.text,border:`1px solid ${C.border}`,borderRadius:6,cursor:'pointer'}}, 'İPTAL'),
          React.createElement('button', {onClick:()=>sil(silOnay.id),
            style:{padding:'8px 14px',fontSize:11,fontWeight:700,background:C.danger,color:'#fff',border:0,borderRadius:6,cursor:'pointer'}}, 'EVET, SİL')
        )
      )
    )
  );
};

/* ═══ EKSPER FORM MODAL ═══ */
MR.EksperFormModal = ({mode, data, onKapat, onKaydet}) => {
  const {C, S, LIcon, FormGroup, Modal} = MR;
  const [form, setForm] = useState({
    id: data?.id || null,
    firma_adi: data?.firma_adi || '',
    eksper_adi: data?.eksper_adi || '',
    eksper_cep: data?.eksper_cep || '',
    sabit_telefon: data?.sabit_telefon || '',
    ofis_cep: data?.ofis_cep || '',
    eposta: data?.eposta || '',
    durum: data?.durum || 'aktif',
    notlar: data?.notlar || ''
  });
  const u = (k,v) => setForm(p => ({...p,[k]:v}));
  const [error, setError] = useState('');

  const submit = () => {
    if (!form.firma_adi.trim()) { setError('FİRMA ADI GEREKLİ'); return; }
    if (!form.eksper_adi.trim()) { setError('EKSPER ADI GEREKLİ'); return; }
    onKaydet(form);
  };

  return React.createElement(Modal, {open:true, onClose:onKapat, title: mode==='yeni' ? 'YENİ EKSPER FİRMA' : 'EKSPER DÜZENLE', width:'600px'},
    error && React.createElement('div', {style:{padding:8,background:`${C.danger}22`,borderRadius:6,marginBottom:10,fontSize:11,color:C.danger}}, error),
    React.createElement('div', {style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:10}},
      React.createElement(FormGroup, {label:'FİRMA ADI *'},
        React.createElement('input', {value:form.firma_adi, onChange:e=>u('firma_adi',e.target.value), style:Object.assign({},S.input,{padding:'8px 10px',fontSize:12})})),
      React.createElement(FormGroup, {label:'EKSPER ADI * (dosya formunda görünür)'},
        React.createElement('input', {value:form.eksper_adi, onChange:e=>u('eksper_adi',e.target.value), style:Object.assign({},S.input,{padding:'8px 10px',fontSize:12})})),
      React.createElement(FormGroup, {label:'EKSPER CEP TELEFON'},
        React.createElement('input', {value:form.eksper_cep, onChange:e=>u('eksper_cep',e.target.value), placeholder:'05XX XXX XX XX', style:Object.assign({},S.input,{padding:'8px 10px',fontSize:12})})),
      React.createElement(FormGroup, {label:'SABİT TELEFON'},
        React.createElement('input', {value:form.sabit_telefon, onChange:e=>u('sabit_telefon',e.target.value), placeholder:'0XXX XXX XX XX', style:Object.assign({},S.input,{padding:'8px 10px',fontSize:12})})),
      React.createElement(FormGroup, {label:'OFİS CEP TELEFON'},
        React.createElement('input', {value:form.ofis_cep, onChange:e=>u('ofis_cep',e.target.value), placeholder:'05XX XXX XX XX', style:Object.assign({},S.input,{padding:'8px 10px',fontSize:12})})),
      React.createElement(FormGroup, {label:'E-POSTA (mail otomasyonu için)'},
        React.createElement('input', {type:'email', value:form.eposta, onChange:e=>u('eposta',e.target.value), placeholder:'eksper@ornek.com', style:Object.assign({},S.input,{padding:'8px 10px',fontSize:12})})),
      React.createElement(FormGroup, {label:'DURUM'},
        React.createElement('select', {value:form.durum, onChange:e=>u('durum',e.target.value), style:Object.assign({},S.select,{padding:'8px 10px',fontSize:12})},
          React.createElement('option', {value:'aktif'}, 'AKTİF'),
          React.createElement('option', {value:'pasif'}, 'PASİF')
        ))
    ),
    React.createElement(FormGroup, {label:'NOTLAR'},
      React.createElement('textarea', {value:form.notlar, onChange:e=>u('notlar',e.target.value), rows:2, style:Object.assign({},S.input,{padding:'8px 10px',fontSize:12,resize:'vertical',width:'100%'})})),
    React.createElement('button', {onClick:submit,
      style:Object.assign({},S.btn,S.btnP,{justifyContent:'center',padding:12,width:'100%',fontSize:13,marginTop:6})},
      React.createElement(LIcon,{name:'Save',size:14,color:'#fff'}), ' KAYDET'
    )
  );
};

/* ═══ SİGORTA ŞİRKETİ LİSTESİ + EKLE/DÜZENLE/SİL ═══ */
MR.SigortaSirketListesi = ({user}) => {
  const {C, S, LIcon, FormGroup, Modal, api} = MR;
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [arama, setArama] = useState('');
  const [modal, setModal] = useState(null);
  const [silOnay, setSilOnay] = useState(null);
  const [mesaj, setMesaj] = useState(null);

  const tok = () => localStorage.getItem('mr_token') || localStorage.getItem('token') || localStorage.getItem('jwt') || '';
  const apiCall = async (path, options={}) => {
    const headers = {'Content-Type':'application/json', ...(options.headers||{})};
    const t = tok(); if (t) headers['Authorization'] = 'Bearer ' + t;
    try {
      const r = await fetch(path, {...options, headers, credentials:'include'});
      return await r.json();
    } catch(e) { return {success:false, error: e.message}; }
  };

  const yukle = async () => {
    setLoading(true);
    const q = arama ? '&q=' + encodeURIComponent(arama) : '';
    const r = await apiCall('/api/v1/sigorta/list.php?durum=aktif' + q);
    if (r?.success) setItems(r.data?.items || []);
    setLoading(false);
  };
  useEffect(() => { yukle(); }, []);
  useEffect(() => { const t = setTimeout(yukle, 300); return () => clearTimeout(t); }, [arama]);

  const kaydet = async (form) => {
    const path = form.id ? '/api/v1/sigorta/update.php' : '/api/v1/sigorta/create.php';
    const method = form.id ? 'PUT' : 'POST';
    const r = await apiCall(path, {method, body: JSON.stringify(form)});
    if (r?.success) { setMesaj({tip:'success', text:r.message}); setModal(null); yukle(); setTimeout(()=>setMesaj(null), 3000); }
    else setMesaj({tip:'error', text: r?.error || 'Hata'});
  };

  const sil = async (id) => {
    const r = await apiCall('/api/v1/sigorta/delete.php?id=' + id, {method:'DELETE'});
    if (r?.success) { setMesaj({tip:'success', text:r.message}); setSilOnay(null); yukle(); setTimeout(()=>setMesaj(null), 3000); }
    else setMesaj({tip:'error', text: r?.error || 'Hata'});
  };

  return React.createElement('div', null,
    mesaj && React.createElement('div', {style:{padding:'10px 14px',marginBottom:12,borderRadius:8,fontSize:12,fontWeight:600,
      background: mesaj.tip==='error'?(C.danger+'22'):(C.success+'22'),
      color: mesaj.tip==='error'?C.danger:C.success}}, mesaj.text),
    React.createElement('div', {style:{display:'flex',gap:10,marginBottom:14}},
      React.createElement('input', {type:'search', value:arama, onChange:e=>setArama(e.target.value),
        placeholder:'Sigorta şirketi / e-posta ara...',
        style:Object.assign({},S.input,{flex:1,padding:'10px 14px',fontSize:13})}),
      React.createElement('button', {onClick:()=>setModal({mode:'yeni',data:{durum:'aktif'}}),
        style:Object.assign({},S.btn,S.btnS,{padding:'10px 20px',fontSize:13,background:C.success,color:'#fff'})},
        React.createElement(LIcon,{name:'Plus',size:14,color:'#fff'}), ' YENİ SİGORTA ŞİRKETİ'
      )
    ),
    loading
      ? React.createElement('div', {style:{padding:40,textAlign:'center',color:C.textMuted}}, 'Yükleniyor...')
      : items.length === 0
        ? React.createElement('div', {style:{padding:40,textAlign:'center',color:C.textMuted,fontStyle:'italic'}}, 'Kayıt yok')
        : React.createElement('div', {style:Object.assign({},S.card,{overflow:'hidden'})},
          React.createElement('table', {style:{width:'100%',borderCollapse:'collapse',fontSize:12}},
            React.createElement('thead', null,
              React.createElement('tr', {style:{background:C.bgInput}},
                React.createElement('th', {style:thStyle(C)}, 'ŞİRKET ADI'),
                React.createElement('th', {style:thStyle(C)}, 'İLETİŞİM NO'),
                React.createElement('th', {style:thStyle(C)}, 'HASAR E-POSTA'),
                React.createElement('th', {style:thStyle(C)}, 'WEB PORTAL'),
                React.createElement('th', {style:Object.assign({},thStyle(C),{textAlign:'center'})}, 'İŞLEM')
              )
            ),
            React.createElement('tbody', null,
              items.map(it => React.createElement('tr', {key:it.id, style:{borderBottom:`1px solid ${C.border}`}},
                React.createElement('td', {style:{padding:'10px 8px',fontWeight:700,color:C.text}}, it.sirket_adi),
                React.createElement('td', {style:{padding:'10px 8px',fontFamily:'monospace',fontSize:11}}, it.iletisim_no || '-'),
                React.createElement('td', {style:{padding:'10px 8px',fontSize:11,color:C.success}}, it.hasar_eposta || '-'),
                React.createElement('td', {style:{padding:'10px 8px',fontSize:11,color:C.accent}},
                  it.web_portal ? React.createElement('a', {href:it.web_portal, target:'_blank', rel:'noopener', style:{color:C.accent,textDecoration:'underline'}}, '🔗 LINK') : '-'
                ),
                React.createElement('td', {style:{padding:'10px 8px',textAlign:'center',whiteSpace:'nowrap'}},
                  React.createElement('button', {onClick:()=>setModal({mode:'duzenle',data:it}),
                    style:{padding:'5px 10px',fontSize:10,background:C.accent,color:'#fff',border:0,borderRadius:4,cursor:'pointer',marginRight:4}}, 'DÜZENLE'),
                  user?.rol === 'admin' && React.createElement('button', {onClick:()=>setSilOnay(it),
                    style:{padding:'5px 10px',fontSize:10,background:C.danger,color:'#fff',border:0,borderRadius:4,cursor:'pointer'}}, 'SİL')
                )
              ))
            )
          )
        ),
    modal && React.createElement(MR.SigortaFormModal, {mode:modal.mode, data:modal.data, onKapat:()=>setModal(null), onKaydet:kaydet}),
    silOnay && React.createElement('div', {onClick:()=>setSilOnay(null),
      style:{position:'fixed',top:0,left:0,right:0,bottom:0,background:'rgba(0,0,0,0.6)',zIndex:9999,display:'flex',alignItems:'center',justifyContent:'center'}},
      React.createElement('div', {onClick:e=>e.stopPropagation(), style:{background:C.bgCard,padding:24,borderRadius:12,maxWidth:420}},
        React.createElement('div', {style:{fontSize:14,fontWeight:800,marginBottom:8,color:C.danger}}, 'SİGORTA SİLİNECEK'),
        React.createElement('div', {style:{fontSize:12,color:C.textSec,marginBottom:16}},
          React.createElement('strong', null, silOnay.sirket_adi), ' silinecek. Bağlı dosya varsa pasif yapılır.'
        ),
        React.createElement('div', {style:{display:'flex',gap:8,justifyContent:'flex-end'}},
          React.createElement('button', {onClick:()=>setSilOnay(null), style:{padding:'8px 14px',fontSize:11,background:C.bgInput,color:C.text,border:`1px solid ${C.border}`,borderRadius:6,cursor:'pointer'}}, 'İPTAL'),
          React.createElement('button', {onClick:()=>sil(silOnay.id), style:{padding:'8px 14px',fontSize:11,fontWeight:700,background:C.danger,color:'#fff',border:0,borderRadius:6,cursor:'pointer'}}, 'EVET, SİL')
        )
      )
    )
  );
};

/* ═══ SİGORTA FORM MODAL ═══ */
MR.SigortaFormModal = ({mode, data, onKapat, onKaydet}) => {
  const {C, S, LIcon, FormGroup, Modal} = MR;
  const [form, setForm] = useState({
    id: data?.id || null,
    sirket_adi: data?.sirket_adi || '',
    iletisim_no: data?.iletisim_no || '',
    hasar_eposta: data?.hasar_eposta || '',
    web_portal: data?.web_portal || '',
    durum: data?.durum || 'aktif',
    notlar: data?.notlar || ''
  });
  const u = (k,v) => setForm(p => ({...p,[k]:v}));
  const [error, setError] = useState('');

  const submit = () => {
    if (!form.sirket_adi.trim()) { setError('ŞİRKET ADI GEREKLİ'); return; }
    onKaydet(form);
  };

  return React.createElement(Modal, {open:true, onClose:onKapat, title: mode==='yeni' ? 'YENİ SİGORTA ŞİRKETİ' : 'SİGORTA DÜZENLE', width:'600px'},
    error && React.createElement('div', {style:{padding:8,background:`${C.danger}22`,borderRadius:6,marginBottom:10,fontSize:11,color:C.danger}}, error),
    React.createElement('div', {style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:10}},
      React.createElement(FormGroup, {label:'ŞİRKET ADI *'},
        React.createElement('input', {value:form.sirket_adi, onChange:e=>u('sirket_adi',e.target.value), style:Object.assign({},S.input,{padding:'8px 10px',fontSize:12})})),
      React.createElement(FormGroup, {label:'İLETİŞİM NUMARASI'},
        React.createElement('input', {value:form.iletisim_no, onChange:e=>u('iletisim_no',e.target.value), placeholder:'0XXX XXX XX XX', style:Object.assign({},S.input,{padding:'8px 10px',fontSize:12})})),
      React.createElement(FormGroup, {label:'HASAR E-POSTASI (otomatik mail için)'},
        React.createElement('input', {type:'email', value:form.hasar_eposta, onChange:e=>u('hasar_eposta',e.target.value), placeholder:'hasar@sirket.com', style:Object.assign({},S.input,{padding:'8px 10px',fontSize:12})})),
      React.createElement(FormGroup, {label:'WEB PORTAL URL'},
        React.createElement('input', {type:'url', value:form.web_portal, onChange:e=>u('web_portal',e.target.value), placeholder:'https://...', style:Object.assign({},S.input,{padding:'8px 10px',fontSize:12})})),
      React.createElement(FormGroup, {label:'DURUM'},
        React.createElement('select', {value:form.durum, onChange:e=>u('durum',e.target.value), style:Object.assign({},S.select,{padding:'8px 10px',fontSize:12})},
          React.createElement('option', {value:'aktif'}, 'AKTİF'),
          React.createElement('option', {value:'pasif'}, 'PASİF')
        ))
    ),
    React.createElement(FormGroup, {label:'NOTLAR'},
      React.createElement('textarea', {value:form.notlar, onChange:e=>u('notlar',e.target.value), rows:2, style:Object.assign({},S.input,{padding:'8px 10px',fontSize:12,resize:'vertical',width:'100%'})})),
    React.createElement('button', {onClick:submit,
      style:Object.assign({},S.btn,S.btnP,{justifyContent:'center',padding:12,width:'100%',fontSize:13,marginTop:6,background:C.success})},
      React.createElement(LIcon,{name:'Save',size:14,color:'#fff'}), ' KAYDET'
    )
  );
};

/* Yardımcı stil */
function thStyle(C) {
  return {padding:'10px 8px',textAlign:'left',fontSize:10,fontWeight:800,color:C.textSec,letterSpacing:0.5,borderBottom:`1px solid ${C.border}`};
}
