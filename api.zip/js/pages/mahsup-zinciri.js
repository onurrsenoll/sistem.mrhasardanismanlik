/* ═══════════════════════════════════════════════════════════════════
   MUHASEBE > MAHSUP ZİNCİRİ — 04.05.2026
   Bekleyen mahsupları listele + manuel uygulama (admin)
   ═══════════════════════════════════════════════════════════════════ */
const MR = window.MR || (window.MR = {});
const {useState, useEffect} = React;

MR.MahsupZinciriPage = ({setPage, user}) => {
  const {C, S, LIcon, SectionTitle, FormGroup, Modal, fmt} = MR;
  const [bekleyen, setBekleyen] = useState([]);
  const [secilenDosya, setSecilenDosya] = useState(null);
  const [zincir, setZincir] = useState(null);
  const [loading, setLoading] = useState(true);
  const [uygulamaModal, setUygulamaModal] = useState(null); // {kapanis_id, max}
  const [mesaj, setMesaj] = useState(null);

  const tok = () => localStorage.getItem('mr_token') || localStorage.getItem('token') || localStorage.getItem('jwt') || '';
  const apiCall = async (path, options={}) => {
    const headers = Object.assign({'Content-Type':'application/json'}, options.headers||{});
    const t = tok(); if (t) headers['Authorization'] = 'Bearer ' + t;
    try {
      const r = await fetch(path, Object.assign({}, options, {headers, credentials:'include'}));
      return await r.json();
    } catch(e) { return {success:false, error: e.message}; }
  };

  const yukle = async () => {
    setLoading(true);
    const r = await apiCall('/api/v1/dosya/mahsup-zinciri.php?bekleyen=1');
    if (r?.success) setBekleyen(r.data?.bekleyen_mahsuplar || []);
    setLoading(false);
  };
  useEffect(() => { yukle(); }, []);

  const dosyaZinciriAc = async (dosyaId) => {
    setSecilenDosya(dosyaId);
    const r = await apiCall('/api/v1/dosya/mahsup-zinciri.php?dosya_id=' + dosyaId);
    if (r?.success) setZincir(r.data);
  };

  const mahsupUygula = async (kapanisId, tutar) => {
    if (!tutar || tutar <= 0) return;
    const r = await apiCall('/api/v1/dosya/mahsup-zinciri.php', {
      method: 'POST',
      body: JSON.stringify({dosya_id: uygulamaModal.dosya_id, mahsup_uygulanan: parseFloat(tutar)})
    });
    if (r?.success) {
      setMesaj({tip:'success', text: r.message});
      setUygulamaModal(null);
      yukle();
      setTimeout(()=>setMesaj(null), 3000);
    } else {
      setMesaj({tip:'error', text: r?.error || 'Uygulama hatası'});
    }
  };

  const fmtTL = n => '₺' + (Math.abs(parseFloat(n)||0)).toLocaleString('tr-TR', {minimumFractionDigits: 2, maximumFractionDigits: 2});

  return React.createElement('div', {className:'fade-in'},
    React.createElement(SectionTitle, {icon:'ArrowLeftRight', title:'MAHSUP ZİNCİRİ', sub:'BEKLEYEN MAHSUP TUTARLARI VE ZİNCİRLEME UYGULAMA'}),

    /* MESAJ */
    mesaj && React.createElement('div', {style:{padding:'10px 14px',marginBottom:14,borderRadius:8,fontSize:12,fontWeight:600,
      background: mesaj.tip==='error' ? (C.danger+'22') : (C.success+'22'),
      color: mesaj.tip==='error' ? C.danger : C.success}}, mesaj.text),

    /* BİLGİ KARTI */
    React.createElement('div', {style:Object.assign({}, S.card, {marginBottom:14, padding:14, borderLeft:'4px solid '+C.purple})},
      React.createElement('div', {style:{display:'flex',alignItems:'center',gap:10,marginBottom:8}},
        React.createElement(LIcon, {name:'Info', size:14, color:C.purple}),
        React.createElement('span', {style:{fontSize:12,fontWeight:800,color:C.purple,letterSpacing:0.5}}, 'MAHSUP ZİNCİRİ NEDİR?')
      ),
      React.createElement('div', {style:{fontSize:11,color:C.textSec,lineHeight:1.6}},
        'Bir dosya kapatıldığında ', React.createElement('strong',null,'mahsup edilecek tutar'), ' bekler.', React.createElement('br'),
        'Sonraki kapanan dosyada bu tutar onur payından düşülerek mahsup uygulanır.', React.createElement('br'),
        'Aşağıda bekleyen mahsup tutarları + manuel uygulama imkânı yer alır.'
      )
    ),

    /* BEKLEYEN MAHSUPLAR LİSTESİ */
    React.createElement('div', {style:Object.assign({}, S.card, {overflow:'hidden'})},
      React.createElement('div', {style:{padding:'12px 16px',background:`${C.warning}11`,borderBottom:`1px solid ${C.border}`,display:'flex',alignItems:'center',justifyContent:'between',gap:10}},
        React.createElement('div', {style:{display:'flex',alignItems:'center',gap:8,flex:1}},
          React.createElement(LIcon, {name:'AlertCircle', size:14, color:C.warning}),
          React.createElement('span', {style:{fontSize:12,fontWeight:700}}, 'BEKLEYEN MAHSUPLAR (' + bekleyen.length + ' kayıt)')
        ),
        React.createElement('button', {onClick:yukle, style:{padding:'6px 12px',fontSize:10,background:C.accent,color:'#fff',border:0,borderRadius:4,cursor:'pointer'}},
          React.createElement(LIcon, {name:'RefreshCw', size:11, color:'#fff'}), ' YENİLE'
        )
      ),
      loading
        ? React.createElement('div', {style:{padding:40,textAlign:'center',color:C.textMuted}}, 'Yükleniyor...')
        : bekleyen.length === 0
          ? React.createElement('div', {style:{padding:40,textAlign:'center',color:C.textMuted,fontStyle:'italic'}},
              '✅ Bekleyen mahsup yok. Tüm zincirleme tamamlanmış.'
            )
          : React.createElement('table', {style:{width:'100%',borderCollapse:'collapse',fontSize:12}},
            React.createElement('thead', null,
              React.createElement('tr', {style:{background:C.bgInput}},
                React.createElement('th', {style:thStyle(C)}, 'DOSYA NO'),
                React.createElement('th', {style:thStyle(C)}, 'KAPATMA TARİHİ'),
                React.createElement('th', {style:Object.assign({}, thStyle(C), {textAlign:'right'})}, 'MAHSUP EDİLECEK'),
                React.createElement('th', {style:Object.assign({}, thStyle(C), {textAlign:'right'})}, 'UYGULANAN'),
                React.createElement('th', {style:Object.assign({}, thStyle(C), {textAlign:'right'})}, 'KALAN'),
                React.createElement('th', {style:Object.assign({}, thStyle(C), {textAlign:'center'})}, 'DURUM'),
                React.createElement('th', {style:Object.assign({}, thStyle(C), {textAlign:'center'})}, 'İŞLEM')
              )
            ),
            React.createElement('tbody', null,
              bekleyen.map(b => {
                const kalan = parseFloat(b.kalan) || 0;
                return React.createElement('tr', {key:b.id, style:{borderBottom:`1px solid ${C.border}`}},
                  React.createElement('td', {style:{padding:'10px 8px',fontWeight:700,fontFamily:'monospace'}}, b.dosya_no),
                  React.createElement('td', {style:{padding:'10px 8px',fontSize:11,color:C.textSec}}, b.kapatma_tarihi),
                  React.createElement('td', {style:{padding:'10px 8px',textAlign:'right',fontFamily:'monospace',color:C.warning,fontWeight:700}}, fmtTL(b.mahsup_edilecek)),
                  React.createElement('td', {style:{padding:'10px 8px',textAlign:'right',fontFamily:'monospace',color:C.success}}, fmtTL(b.mahsup_uygulanan)),
                  React.createElement('td', {style:{padding:'10px 8px',textAlign:'right',fontFamily:'monospace',color:C.danger,fontWeight:800}}, fmtTL(kalan)),
                  React.createElement('td', {style:{padding:'10px 8px',textAlign:'center'}},
                    React.createElement('span', {style:{padding:'3px 8px',borderRadius:4,fontSize:10,fontWeight:700,background: C.warning+'22',color: C.warning}},
                      'BEKLİYOR')
                  ),
                  React.createElement('td', {style:{padding:'10px 8px',textAlign:'center',whiteSpace:'nowrap'}},
                    React.createElement('button', {onClick:()=>dosyaZinciriAc(b.dosya_id),
                      style:{padding:'5px 10px',fontSize:10,background:C.accent,color:'#fff',border:0,borderRadius:4,cursor:'pointer',marginRight:4}}, 'ZİNCİR'),
                    user?.rol === 'admin' && React.createElement('button', {onClick:()=>setUygulamaModal({kapanis_id:b.id, dosya_id:b.dosya_id, max:kalan, dosya_no:b.dosya_no}),
                      style:{padding:'5px 10px',fontSize:10,background:C.purple,color:'#fff',border:0,borderRadius:4,cursor:'pointer'}}, 'UYGULA')
                  )
                );
              })
            )
          )
    ),

    /* DOSYA ZİNCİRİ DETAYI MODAL */
    secilenDosya && zincir && React.createElement('div', {onClick:()=>{setSecilenDosya(null); setZincir(null);},
      style:{position:'fixed',top:0,left:0,right:0,bottom:0,background:'rgba(0,0,0,0.6)',zIndex:9999,display:'flex',alignItems:'center',justifyContent:'center'}},
      React.createElement('div', {onClick:e=>e.stopPropagation(),
        style:{background:C.bgCard,padding:0,borderRadius:14,maxWidth:780,width:'90vw',maxHeight:'85vh',overflow:'hidden',display:'flex',flexDirection:'column'}},
        React.createElement('div', {style:{padding:'14px 20px',borderBottom:`1px solid ${C.border}`,display:'flex',alignItems:'center',justifyContent:'space-between',background:C.purple+'08'}},
          React.createElement('div', {style:{display:'flex',alignItems:'center',gap:8}},
            React.createElement(LIcon, {name:'ArrowLeftRight', size:16, color:C.purple}),
            React.createElement('span', {style:{fontSize:14,fontWeight:800}}, 'MAHSUP ZİNCİRİ — DOSYA #' + secilenDosya)
          ),
          React.createElement('button', {onClick:()=>{setSecilenDosya(null); setZincir(null);}, style:{background:'transparent',border:0,fontSize:20,cursor:'pointer',color:C.textMuted}}, '×')
        ),
        React.createElement('div', {style:{flex:1,overflow:'auto',padding:'18px 22px'}},
          /* MAHSUP KAYNAK */
          zincir.mahsup_kaynak && React.createElement('div', {style:{marginBottom:14,padding:12,background:C.warning+'08',borderRadius:8,border:`1px solid ${C.warning}33`}},
            React.createElement('div', {style:{fontSize:10,fontWeight:800,color:C.warning,marginBottom:6}}, '⬆️ KAYNAK DOSYA (mahsup buradan geliyor)'),
            React.createElement('div', {style:{fontSize:12}},
              React.createElement('strong',null, zincir.mahsup_kaynak.dosya_no), ' — ',
              'Tutar: ', fmtTL(zincir.mahsup_kaynak.mahsup_edilecek), ' / ',
              'Uygulanan: ', fmtTL(zincir.mahsup_kaynak.mahsup_uygulanan)
            )
          ),
          /* MEVCUT KAPANIŞ */
          zincir.kapanis && React.createElement('div', {style:{marginBottom:14,padding:12,background:C.accent+'08',borderRadius:8,border:`1px solid ${C.accent}33`}},
            React.createElement('div', {style:{fontSize:10,fontWeight:800,color:C.accent,marginBottom:6}}, '📌 BU DOSYA KAPANIŞI'),
            React.createElement('div', {style:{fontSize:11,lineHeight:1.6}},
              'Mahsup edilecek: ', React.createElement('strong',null, fmtTL(zincir.kapanis.mahsup_edilecek)), React.createElement('br'),
              'Uygulanan: ', React.createElement('strong',{style:{color:C.success}}, fmtTL(zincir.kapanis.mahsup_uygulanan)), React.createElement('br'),
              'Onur payı: ', React.createElement('strong',null, fmtTL(zincir.kapanis.onur_payi)), React.createElement('br'),
              'Avukat payı: ', React.createElement('strong',null, fmtTL(zincir.kapanis.avukat_payi))
            )
          ),
          /* MAHSUP HEDEFLERİ */
          zincir.mahsup_hedefler && zincir.mahsup_hedefler.length > 0 && React.createElement('div', {style:{padding:12,background:C.success+'08',borderRadius:8,border:`1px solid ${C.success}33`}},
            React.createElement('div', {style:{fontSize:10,fontWeight:800,color:C.success,marginBottom:6}}, '⬇️ HEDEF DOSYALAR (mahsup uygulanmış)'),
            zincir.mahsup_hedefler.map((h,i) => React.createElement('div', {key:i, style:{fontSize:11,padding:'4px 0',borderBottom:i<zincir.mahsup_hedefler.length-1?`1px dashed ${C.border}`:'none'}},
              React.createElement('strong',null, h.dosya_no), ' — Uygulanan: ', fmtTL(h.mahsup_uygulanan)
            ))
          ),
          (!zincir.mahsup_hedefler || zincir.mahsup_hedefler.length === 0) && (!zincir.mahsup_kaynak) &&
            React.createElement('div', {style:{padding:20,textAlign:'center',color:C.textMuted,fontStyle:'italic'}}, 'Bu dosya için mahsup zinciri kaydı yok')
        )
      )
    ),

    /* UYGULAMA MODAL */
    uygulamaModal && React.createElement('div', {onClick:()=>setUygulamaModal(null),
      style:{position:'fixed',top:0,left:0,right:0,bottom:0,background:'rgba(0,0,0,0.6)',zIndex:10000,display:'flex',alignItems:'center',justifyContent:'center'}},
      React.createElement('div', {onClick:e=>e.stopPropagation(), style:{background:C.bgCard,padding:24,borderRadius:12,maxWidth:480,width:'90vw'}},
        React.createElement('div', {style:{fontSize:14,fontWeight:800,marginBottom:8,color:C.purple}}, 'MANUEL MAHSUP UYGULAMASI'),
        React.createElement('div', {style:{fontSize:12,color:C.textSec,marginBottom:12}},
          React.createElement('strong',null, uygulamaModal.dosya_no), ' dosyasından mahsup uygulanacak.', React.createElement('br'),
          'Kalan tutar: ', React.createElement('strong',{style:{color:C.danger}}, fmtTL(uygulamaModal.max))
        ),
        React.createElement(FormGroup, {label:'UYGULANACAK TUTAR (TL)'},
          React.createElement('input', {type:'number', id:'mahsup-tutar-input', max:uygulamaModal.max, defaultValue:uygulamaModal.max,
            style:Object.assign({}, S.input, {padding:'10px 12px',fontSize:13,fontWeight:700})})
        ),
        React.createElement('div', {style:{display:'flex',gap:8,justifyContent:'flex-end',marginTop:12}},
          React.createElement('button', {onClick:()=>setUygulamaModal(null),
            style:{padding:'8px 14px',fontSize:11,background:C.bgInput,color:C.text,border:`1px solid ${C.border}`,borderRadius:6,cursor:'pointer'}}, 'İPTAL'),
          React.createElement('button', {onClick:()=>{
            const v = document.getElementById('mahsup-tutar-input')?.value;
            mahsupUygula(uygulamaModal.kapanis_id, v);
          }, style:{padding:'8px 14px',fontSize:11,fontWeight:700,background:C.purple,color:'#fff',border:0,borderRadius:6,cursor:'pointer'}}, 'UYGULA')
        )
      )
    )
  );
};

function thStyle(C) {
  return {padding:'10px 8px',textAlign:'left',fontSize:10,fontWeight:800,color:C.textSec,letterSpacing:0.5,borderBottom:`1px solid ${C.border}`};
}
